import { 
  PaymentOptionInfo, 
  MerchantGatewayConfig, 
  PaymentRecord, 
  QuoteRecord, 
  InvoiceRecord, 
  ClientProject 
} from '../types';
import { PROCESS_STEPS } from './portalData';

export const UAE_BANK_DETAILS = {
  bankName: 'Emirates NBD PJSC',
  accountName: 'AIGAINX DIGITAL ARCHITECTURE FZ-LLC',
  accountNumber: '10482938472901',
  iban: 'AE29 0260 0001 0482 9384 7290 1',
  swift: 'EBILAEADXXX',
  branch: 'Dubai Main Branch, UAE',
  currency: 'AED (United Arab Emirates Dirham)',
  address: 'Emitac Building, Dubai, United Arab Emirates',
  referenceFormat: 'AIGX-REF-[ORDER_ID]',
  instructions: 'Please include your unique Payment Reference in your transfer description. Upload the official bank transfer receipt / swift slip for immediate verification and project kickoff.'
};

export const DEFAULT_MERCHANT_CONFIG: MerchantGatewayConfig = {
  activeMode: 'live',
  stripe: {
    enabled: true,
    status: 'connected',
    accountName: 'AIGAINX UAE (Stripe Connect)',
    publicKeyPrefix: 'pk_live_51P...aigainx',
    applePayEnabled: true,
    cardsEnabled: true
  },
  ziina: {
    enabled: true,
    status: 'connected',
    merchantId: 'aigainx-tech-ae',
    paymentLinkUrl: 'https://pay.ziina.com/aigainx'
  },
  uaeBank: {
    enabled: true,
    status: 'manual_active',
    bankName: UAE_BANK_DETAILS.bankName,
    accountName: UAE_BANK_DETAILS.accountName,
    iban: UAE_BANK_DETAILS.iban,
    swift: UAE_BANK_DETAILS.swift,
    branch: UAE_BANK_DETAILS.branch,
    currency: 'AED',
    address: UAE_BANK_DETAILS.address,
    manualVerificationRequired: true
  }
};

export const PAYMENT_OPTIONS_CATALOG: PaymentOptionInfo[] = [
  {
    id: 'apple_pay',
    name: 'Apple Pay',
    category: 'online',
    iconType: 'Apple',
    processor: 'Processed via Stripe / Ziina Gateway',
    status: 'connected',
    statusLabel: 'Active Gateway',
    description: 'Instant 1-touch biometric checkout for Safari & iOS devices via authorized payment processor.',
    processingFee: '0% Surcharge',
    settlementTime: 'Instant Confirmation',
    requiresMerchantAccount: true,
    isAvailable: true
  },
  {
    id: 'credit_card',
    name: 'Credit Card (Visa / Mastercard / AMEX)',
    category: 'online',
    iconType: 'CreditCard',
    processor: 'Processed via Stripe 3D Secure 2.0',
    status: 'connected',
    statusLabel: 'Active Gateway',
    description: 'Encrypted global credit card processing with 3DS fraud protection & instant digital receipt.',
    processingFee: '0% Surcharge',
    settlementTime: 'Instant Confirmation',
    requiresMerchantAccount: true,
    isAvailable: true
  },
  {
    id: 'debit_card',
    name: 'Debit Card (UAE & International)',
    category: 'online',
    iconType: 'CreditCard',
    processor: 'Processed via Stripe / Central Bank Network',
    status: 'connected',
    statusLabel: 'Active Gateway',
    description: 'Direct debit card payment with PIN/OTP banking authorization.',
    processingFee: '0% Surcharge',
    settlementTime: 'Instant Confirmation',
    requiresMerchantAccount: true,
    isAvailable: true
  },
  {
    id: 'stripe',
    name: 'Stripe Checkout',
    category: 'provider',
    iconType: 'Stripe',
    processor: 'Stripe Payments ME Limited (UAE Licensed)',
    status: 'connected',
    statusLabel: 'Merchant Connected',
    description: 'Official hosted Stripe invoice & checkout gateway for corporate accounts.',
    processingFee: 'Standard Gateway',
    settlementTime: 'Instant Webhook',
    requiresMerchantAccount: true,
    isAvailable: true
  },
  {
    id: 'ziina',
    name: 'Ziina Payment Gateway',
    category: 'provider',
    iconType: 'Ziina',
    processor: 'Ziina Payment Services (CBUAE Compliant)',
    status: 'connected',
    statusLabel: 'UAE Licensed',
    description: 'Leading UAE fintech payment gateway with instant QR codes, payment links & local cards.',
    processingFee: 'UAE Domestic Rates',
    settlementTime: 'Instant QR / Link',
    requiresMerchantAccount: true,
    isAvailable: true
  },
  {
    id: 'bank_transfer',
    name: 'Direct UAE Corporate Bank Transfer',
    category: 'bank',
    iconType: 'Building2',
    processor: 'Emirates NBD Corporate Banking (Emitac Building, Dubai)',
    status: 'manual_active',
    statusLabel: 'Manual Verification',
    description: 'Direct IBAN / Wire transfer with automated reference ID generation & proof slip upload verification.',
    processingFee: '0% Gateway Fee',
    settlementTime: 'Verified in 1–3 Hours',
    requiresMerchantAccount: false,
    isAvailable: true
  }
];

export const PACKAGE_PRICING_AED: Record<string, { baseAed: number; name: string; timeline: string }> = {
  starter: {
    baseAed: 4500,
    name: 'Starter System',
    timeline: '7–12 Business Days'
  },
  business: {
    baseAed: 8900,
    name: 'Business Performance System',
    timeline: '12–18 Business Days'
  },
  bespoke: {
    baseAed: 16500,
    name: 'Bespoke Enterprise / E-Commerce',
    timeline: '3–5 Weeks'
  },
  custom: {
    baseAed: 12500,
    name: 'Custom Engineered Scope',
    timeline: '15–20 Business Days'
  }
};

// Initial Seed Projects
export const CLIENT_PROJECTS_SEED: ClientProject[] = [
  {
    id: 'PRJ-2026-081',
    title: 'Apex Capital DIFC Institutional Portal',
    clientName: 'Tariq Al-Mansoor',
    companyName: 'Apex Capital Advisors',
    clientEmail: 'tariq@apexcapital.ae',
    packageName: 'Business Performance System',
    orderId: 'ORD-9824',
    status: 'development',
    currentStep: 6,
    totalSteps: 8,
    progressPercent: 75,
    kickoffDate: '2026-08-04',
    targetDeliveryDate: '2026-08-22',
    repositoryAccessGranted: true,
    assignedLead: 'Senior Digital Architect (Dubai Studio)',
    amountAed: 9345,
    paymentStatus: 'paid'
  },
  {
    id: 'PRJ-2026-082',
    title: 'Vanguard Luxury Off-Plan Funnel',
    clientName: 'Elena Rostova',
    companyName: 'Vanguard Luxury Properties',
    clientEmail: 'elena@vanguardproperties.ae',
    packageName: 'Bespoke Enterprise / E-Commerce',
    orderId: 'ORD-9831',
    status: 'ui_design',
    currentStep: 4,
    totalSteps: 8,
    progressPercent: 50,
    kickoffDate: '2026-08-11',
    targetDeliveryDate: '2026-09-02',
    repositoryAccessGranted: false,
    assignedLead: 'Lead UX Architect (Dubai Studio)',
    amountAed: 17325,
    paymentStatus: 'paid'
  },
  {
    id: 'PRJ-2026-083',
    title: 'Novacore Enterprise AI Landing Hub',
    clientName: 'Dr. Farhan Siddiqui',
    companyName: 'Novacore AI Solutions',
    clientEmail: 'farhan@novacore.ai',
    packageName: 'Starter System',
    orderId: 'ORD-9840',
    status: 'sitemap_wireframing',
    currentStep: 2,
    totalSteps: 8,
    progressPercent: 25,
    kickoffDate: '2026-08-17',
    targetDeliveryDate: '2026-08-28',
    repositoryAccessGranted: false,
    assignedLead: 'System Engineer (Dubai Studio)',
    amountAed: 4725,
    paymentStatus: 'manual_verification'
  }
];

// Initial Seed Quotes
export const QUOTES_SEED: QuoteRecord[] = [
  {
    id: 'QUO-2026-104',
    quoteNumber: 'AIGX-QUO-104',
    clientName: 'Tariq Al-Mansoor',
    companyName: 'Apex Capital Advisors',
    email: 'tariq@apexcapital.ae',
    phone: '+971 50 829 1122',
    projectType: 'Corporate & Business Websites',
    packageName: 'Business Performance System',
    deliverables: [
      '10 Custom Pages with Information Architecture',
      'DIFC Regulatory & Leadership Profiles',
      'Mobile-First Responsive Layout (< 0.8s Web Vitals)',
      '100% Repository Transfer & Video Walkthrough'
    ],
    items: [
      {
        description: 'Business Performance System Base Engineering',
        qty: 1,
        unitPriceAed: 8900,
        totalAed: 8900
      }
    ],
    subtotalAed: 8900,
    vatRate: 0.05,
    vatAed: 445,
    totalAed: 9345,
    status: 'paid',
    validUntil: '2026-09-01',
    createdAt: '2026-08-03',
    paymentTerms: '100% Milestone Lock / Standard 8-Step Delivery',
    timelineEstimate: '12–18 Business Days'
  },
  {
    id: 'QUO-2026-105',
    quoteNumber: 'AIGX-QUO-105',
    clientName: 'Elena Rostova',
    companyName: 'Vanguard Luxury Properties',
    email: 'elena@vanguardproperties.ae',
    phone: '+971 55 901 3344',
    projectType: 'High-Converting Landing Pages',
    packageName: 'Bespoke Enterprise / E-Commerce',
    deliverables: [
      'Off-Plan Development Showcase Suite',
      'Interactive Floorplan & Unit Filter Engine',
      'Direct WhatsApp VIP Broker Gateway',
      'Multi-Language (EN/AR) RTL Structure'
    ],
    items: [
      {
        description: 'Bespoke Enterprise Digital Platform Engineering',
        qty: 1,
        unitPriceAed: 16500,
        totalAed: 16500
      }
    ],
    subtotalAed: 16500,
    vatRate: 0.05,
    vatAed: 825,
    totalAed: 17325,
    status: 'paid',
    validUntil: '2026-09-10',
    createdAt: '2026-08-10',
    paymentTerms: '100% Milestone Lock / Full Code Handover',
    timelineEstimate: '3–5 Weeks'
  },
  {
    id: 'QUO-2026-106',
    quoteNumber: 'AIGX-QUO-106',
    clientName: 'Dr. Farhan Siddiqui',
    companyName: 'Novacore AI Solutions',
    email: 'farhan@novacore.ai',
    phone: '+971 52 441 9090',
    projectType: 'Corporate & Business Websites',
    packageName: 'Starter System',
    deliverables: [
      '5 Core Architectural Pages (Sitemap to Launch)',
      'Sub-Second Performance & Interactive Code Modules',
      'Technical SEO & OpenGraph Configuration',
      '30-Day Post-Launch SLA & Repository Transfer'
    ],
    items: [
      {
        description: 'Starter System Core Engineering',
        qty: 1,
        unitPriceAed: 4500,
        totalAed: 4500
      }
    ],
    subtotalAed: 4500,
    vatRate: 0.05,
    vatAed: 225,
    totalAed: 4725,
    status: 'accepted',
    validUntil: '2026-09-15',
    createdAt: '2026-08-16',
    paymentTerms: 'Direct UAE Corporate Bank Wire with Slip Verification',
    timelineEstimate: '7–12 Business Days'
  }
];

// Initial Seed Invoices
export const INVOICES_SEED: InvoiceRecord[] = [
  {
    id: 'INV-2026-001',
    invoiceNumber: 'AIGX-INV-2026-001',
    orderId: 'ORD-9824',
    quoteNumber: 'AIGX-QUO-104',
    paymentId: 'PAY-ST-8812',
    clientName: 'Tariq Al-Mansoor',
    companyName: 'Apex Capital Advisors',
    clientEmail: 'tariq@apexcapital.ae',
    clientAddress: 'Level 14, Al Fattan Currency House, DIFC, Dubai, UAE',
    clientTrn: '100482938400003',
    issueDate: '2026-08-04',
    dueDate: '2026-08-04',
    paidDate: '2026-08-04',
    items: [
      {
        description: 'Business Performance System Web Architecture (10 Pages, Sub-1s Vitals)',
        qty: 1,
        rateAed: 8900,
        amountAed: 8900
      }
    ],
    subtotalAed: 8900,
    vatAed: 445,
    totalAed: 9345,
    status: 'paid',
    paymentMethod: 'stripe',
    paymentReference: 'ch_3Pf8k2L91AigxStripe'
  },
  {
    id: 'INV-2026-002',
    invoiceNumber: 'AIGX-INV-2026-002',
    orderId: 'ORD-9831',
    quoteNumber: 'AIGX-QUO-105',
    paymentId: 'PAY-AP-8819',
    clientName: 'Elena Rostova',
    companyName: 'Vanguard Luxury Properties',
    clientEmail: 'elena@vanguardproperties.ae',
    clientAddress: 'Boulevard Plaza Tower 1, Downtown Dubai, UAE',
    clientTrn: '100938472900003',
    issueDate: '2026-08-11',
    dueDate: '2026-08-11',
    paidDate: '2026-08-11',
    items: [
      {
        description: 'Bespoke Enterprise Web & Off-Plan Platform (Figma System + EN/AR RTL)',
        qty: 1,
        rateAed: 16500,
        amountAed: 16500
      }
    ],
    subtotalAed: 16500,
    vatAed: 825,
    totalAed: 17325,
    status: 'paid',
    paymentMethod: 'apple_pay',
    paymentReference: 'ap_token_9948271aigainx'
  },
  {
    id: 'INV-2026-003',
    invoiceNumber: 'AIGX-INV-2026-003',
    orderId: 'ORD-9840',
    quoteNumber: 'AIGX-QUO-106',
    paymentId: 'PAY-BK-8825',
    clientName: 'Dr. Farhan Siddiqui',
    companyName: 'Novacore AI Solutions',
    clientEmail: 'farhan@novacore.ai',
    clientAddress: 'Building 03, Dubai Internet City, Dubai, UAE',
    clientTrn: '100293847500003',
    issueDate: '2026-08-17',
    dueDate: '2026-08-20',
    items: [
      {
        description: 'Starter System Core Web Engineering (5 Core Pages + SEO Schema)',
        qty: 1,
        rateAed: 4500,
        amountAed: 4500
      }
    ],
    subtotalAed: 4500,
    vatAed: 225,
    totalAed: 4725,
    status: 'under_review',
    paymentMethod: 'bank_transfer',
    paymentReference: 'AIGX-REF-ORD-9840'
  }
];

// Initial Seed Payments
export const PAYMENTS_SEED: PaymentRecord[] = [
  {
    id: 'PAY-ST-8812',
    orderId: 'ORD-9824',
    invoiceNumber: 'AIGX-INV-2026-001',
    quoteId: 'QUO-2026-104',
    clientName: 'Tariq Al-Mansoor',
    clientEmail: 'tariq@apexcapital.ae',
    clientPhone: '+971 50 829 1122',
    companyName: 'Apex Capital Advisors',
    projectName: 'Apex Capital DIFC Institutional Portal',
    packageId: 'business',
    packageName: 'Business Performance System',
    subtotalAed: 8900,
    vatAed: 445,
    amountAed: 9345,
    currency: 'AED',
    method: 'stripe',
    provider: 'Stripe',
    status: 'paid',
    referenceId: 'ch_3Pf8k2L91AigxStripe',
    paidAt: '2026-08-04T11:20:00Z',
    createdAt: '2026-08-04T11:15:00Z',
    verificationNotes: 'Automated 3D Secure Webhook verified via Stripe Connect ME.'
  },
  {
    id: 'PAY-AP-8819',
    orderId: 'ORD-9831',
    invoiceNumber: 'AIGX-INV-2026-002',
    quoteId: 'QUO-2026-105',
    clientName: 'Elena Rostova',
    clientEmail: 'elena@vanguardproperties.ae',
    clientPhone: '+971 55 901 3344',
    companyName: 'Vanguard Luxury Properties',
    projectName: 'Vanguard Luxury Off-Plan Funnel',
    packageId: 'bespoke',
    packageName: 'Bespoke Enterprise / E-Commerce',
    subtotalAed: 16500,
    vatAed: 825,
    amountAed: 17325,
    currency: 'AED',
    method: 'apple_pay',
    provider: 'Apple Pay via Stripe',
    status: 'paid',
    referenceId: 'ap_token_9948271aigainx',
    paidAt: '2026-08-11T14:45:00Z',
    createdAt: '2026-08-11T14:40:00Z',
    verificationNotes: 'Apple Pay biometric authentication token processed via Stripe gateway.'
  },
  {
    id: 'PAY-BK-8825',
    orderId: 'ORD-9840',
    invoiceNumber: 'AIGX-INV-2026-003',
    quoteId: 'QUO-2026-106',
    clientName: 'Dr. Farhan Siddiqui',
    clientEmail: 'farhan@novacore.ai',
    clientPhone: '+971 52 441 9090',
    companyName: 'Novacore AI Solutions',
    projectName: 'Novacore Enterprise AI Landing Hub',
    packageId: 'starter',
    packageName: 'Starter System',
    subtotalAed: 4500,
    vatAed: 225,
    amountAed: 4725,
    currency: 'AED',
    method: 'bank_transfer',
    provider: 'Direct UAE Bank',
    status: 'manual_verification',
    referenceId: 'AIGX-REF-ORD-9840',
    paymentProofName: 'EmiratesNBD_Wire_Slip_ORD9840.pdf',
    createdAt: '2026-08-17T09:12:00Z',
    verificationNotes: 'Emirates NBD Wire slip submitted. Pending Admin Finance Approval in Dubai Studio.'
  }
];

// LocalStorage Hydration Helpers
const STORAGE_KEYS = {
  PAYMENTS: 'aigainx_payments_store',
  QUOTES: 'aigainx_quotes_store',
  INVOICES: 'aigainx_invoices_store',
  PROJECTS: 'aigainx_projects_store',
  MERCHANT: 'aigainx_merchant_config'
};

export const getStoredPayments = (): PaymentRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PAYMENTS);
    if (!raw) return PAYMENTS_SEED;
    return JSON.parse(raw);
  } catch (e) {
    return PAYMENTS_SEED;
  }
};

export const savePaymentRecord = (payment: PaymentRecord) => {
  const current = getStoredPayments();
  const updated = [payment, ...current.filter((p) => p.id !== payment.id)];
  localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(updated));
  return updated;
};

export const updatePaymentStatusInStore = (
  paymentId: string, 
  status: PaymentRecord['status'], 
  notes?: string
): PaymentRecord[] => {
  const current = getStoredPayments();
  const updated = current.map((p) => {
    if (p.id === paymentId) {
      return {
        ...p,
        status,
        verificationNotes: notes || p.verificationNotes,
        paidAt: status === 'paid' ? new Date().toISOString() : p.paidAt
      };
    }
    return p;
  });
  localStorage.setItem(STORAGE_KEYS.PAYMENTS, JSON.stringify(updated));
  return updated;
};

export const getStoredQuotes = (): QuoteRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.QUOTES);
    if (!raw) return QUOTES_SEED;
    return JSON.parse(raw);
  } catch (e) {
    return QUOTES_SEED;
  }
};

export const saveQuoteRecord = (quote: QuoteRecord) => {
  const current = getStoredQuotes();
  const updated = [quote, ...current.filter((q) => q.id !== quote.id)];
  localStorage.setItem(STORAGE_KEYS.QUOTES, JSON.stringify(updated));
  return updated;
};

export const getStoredInvoices = (): InvoiceRecord[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.INVOICES);
    if (!raw) return INVOICES_SEED;
    return JSON.parse(raw);
  } catch (e) {
    return INVOICES_SEED;
  }
};

export const saveInvoiceRecord = (invoice: InvoiceRecord) => {
  const current = getStoredInvoices();
  const updated = [invoice, ...current.filter((i) => i.id !== invoice.id)];
  localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(updated));
  return updated;
};

export const getStoredProjects = (): ClientProject[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PROJECTS);
    if (!raw) return CLIENT_PROJECTS_SEED;
    return JSON.parse(raw);
  } catch (e) {
    return CLIENT_PROJECTS_SEED;
  }
};

export const saveProjectRecord = (project: ClientProject) => {
  const current = getStoredProjects();
  const updated = [project, ...current.filter((p) => p.id !== project.id)];
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(updated));
  return updated;
};

export const MILESTONE_UPDATE_EVENT = 'aigainx_project_milestone_updated';

// Helper to determine status and default progress percentage based on 8-step delivery
export const calculateMilestoneMeta = (stepNumber: number): { status: ClientProject['status']; progressPercent: number } => {
  const clampedStep = Math.min(8, Math.max(1, stepNumber));
  switch (clampedStep) {
    case 1:
      return { status: 'discovery', progressPercent: 12 };
    case 2:
      return { status: 'sitemap_wireframing', progressPercent: 25 };
    case 3:
      return { status: 'sitemap_wireframing', progressPercent: 38 };
    case 4:
      return { status: 'ui_design', progressPercent: 50 };
    case 5:
      return { status: 'development', progressPercent: 68 };
    case 6:
      return { status: 'qa_testing', progressPercent: 82 };
    case 7:
      return { status: 'launch_prep', progressPercent: 94 };
    case 8:
      return { status: 'delivered', progressPercent: 100 };
    default:
      return { status: 'discovery', progressPercent: 12 };
  }
};

export interface MilestoneUpdateDetail {
  project: ClientProject;
  previousStep: number;
  newStep: number;
  milestoneName: string;
  updatedAt: string;
  notes?: string;
}

export const updateProjectMilestoneInStore = (
  projectId: string,
  newStep: number,
  customStatus?: ClientProject['status'],
  notes?: string
): { updatedProjects: ClientProject[]; updatedProject: ClientProject | null; detail?: MilestoneUpdateDetail } => {
  const current = getStoredProjects();
  const targetProject = current.find((p) => p.id === projectId);

  if (!targetProject) {
    return { updatedProjects: current, updatedProject: null };
  }

  const previousStep = targetProject.currentStep;
  const meta = calculateMilestoneMeta(newStep);
  const milestoneName = PROCESS_STEPS[newStep - 1]?.title || `Step ${newStep}`;

  const updatedProject: ClientProject = {
    ...targetProject,
    currentStep: newStep,
    status: customStatus || meta.status,
    progressPercent: meta.progressPercent,
    repositoryAccessGranted: newStep >= 6 ? true : targetProject.repositoryAccessGranted
  };

  const updatedProjects = current.map((p) => (p.id === projectId ? updatedProject : p));
  localStorage.setItem(STORAGE_KEYS.PROJECTS, JSON.stringify(updatedProjects));

  const detail: MilestoneUpdateDetail = {
    project: updatedProject,
    previousStep,
    newStep,
    milestoneName,
    updatedAt: new Date().toISOString(),
    notes: notes || `Milestone advanced to Step ${newStep} (${milestoneName}) by AIGAINX Dubai Studio Engineering Team.`
  };

  // Dispatch real-time DOM Event for instant cross-component updates
  if (typeof window !== 'undefined') {
    try {
      const customEvt = new CustomEvent(MILESTONE_UPDATE_EVENT, { detail });
      window.dispatchEvent(customEvt);
    } catch (e) {
      console.warn('Failed to dispatch milestone custom event', e);
    }
  }

  return { updatedProjects, updatedProject, detail };
};

export const getStoredMerchantConfig = (): MerchantGatewayConfig => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.MERCHANT);
    if (!raw) return DEFAULT_MERCHANT_CONFIG;
    return JSON.parse(raw);
  } catch (e) {
    return DEFAULT_MERCHANT_CONFIG;
  }
};

export const saveMerchantConfig = (config: MerchantGatewayConfig) => {
  localStorage.setItem(STORAGE_KEYS.MERCHANT, JSON.stringify(config));
  return config;
};
