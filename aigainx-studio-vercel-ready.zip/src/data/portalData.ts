import { ProcessStep, ServiceItem, ConceptProject, PackageTier, TestimonialItem } from '../types';
import monogramLogo from '../assets/images/aigainx_monogram_1787180117316.jpg';
import bannerLogo from '../assets/images/aigainx_logo_banner_1787180130188.jpg';

export const BRAND_CONFIG = {
  name: 'AIGAINX Portal',
  brandFullName: 'AIGAINX',
  brandMeaning: 'Artificial Intelligence | Gain & Innovation',
  tagline: 'Professional Web Design for Modern Businesses',
  secondaryTagline: 'Websites Built Like a System, Not a Template',
  supportLine: 'From Sitemap to Launch — Done Right',
  location: 'Emitac Building, Dubai, UAE',
  addressDetailed: 'Emitac Building, Dubai, United Arab Emirates',
  studioType: 'Bespoke Web Design & Digital Architecture',
  deliveryModel: '8-Step Engineering System',
  monogramUrl: monogramLogo,
  bannerLogoUrl: bannerLogo,
  whatsappNumber: '+971585735099', // Dubai UAE standard format
  whatsappDisplay: '+971 58 573 5099',
  email: 'projects@aigainx.tech',
  heroStatement: 'AIGAINX Portal designs and builds mobile-first, conversion-focused websites for growing businesses — through a clear, structured process from discovery to launch.',
  voiceSummary: 'A senior project lead explaining exactly what you are getting and why it works — calm, specific, zero fluff.'
};

export const PROCESS_STEPS: ProcessStep[] = [
  {
    number: 1,
    title: 'Discovery & Strategy',
    subtitle: 'Understanding business goals and user pathways',
    description: 'We analyze your target market, competitors, service hierarchy, and conversion goals before drawing a single line. No guesswork or assumptions.',
    deliverables: [
      'Project Scope & Objectives Brief',
      'Target Audience & User Flow Map',
      'Technical Requirements & Stack Plan',
      'Milestone Schedule'
    ],
    duration: '2–4 Days',
    iconName: 'Compass',
    clientRole: 'Share business context, assets, and target objectives in a 45-min kickoff.'
  },
  {
    number: 2,
    title: 'Sitemap & Architecture',
    subtitle: 'Defining page hierarchy and navigation logic',
    description: 'We construct a structural blueprint of every page, sub-route, header structure, and user action funnel to ensure seamless navigation on mobile and desktop.',
    deliverables: [
      'Complete Information Architecture (IA)',
      'URL Routing & Page Hierarchy Schema',
      'Conversion Touchpoint Allocation',
      'SEO Content Hierarchy Outline'
    ],
    duration: '2–3 Days',
    iconName: 'Network',
    clientRole: 'Review and approve page inventory and primary conversion goals.'
  },
  {
    number: 3,
    title: 'Low-Fidelity Wireframes',
    subtitle: 'Content-first layout and conversion flow',
    description: 'We block out section anatomy, copywriting containers, CTA placements, and mobile scroll depth prior to visual styling.',
    deliverables: [
      'Desktop & Mobile Wireframe Screens',
      'Call-to-Action (CTA) Placement Mapping',
      'Content Density & Layout Structure',
      'Form & Lead Capture Blueprint'
    ],
    duration: '3–5 Days',
    iconName: 'LayoutGrid',
    clientRole: 'Validate layout pacing and content hierarchy before visual design begins.'
  },
  {
    number: 4,
    title: 'UI/UX Visual Design',
    subtitle: 'Polished typography, color systems & components',
    description: 'We establish a bespoke design system tailored to your industry — crafted for high readability, subtle interactions, and pristine brand alignment.',
    deliverables: [
      'Complete High-Fidelity Figma Designs',
      'Responsive Mobile, Tablet & Desktop Views',
      'Interactive Micro-Animations & State Specs',
      'Design Token System (Colors, Fonts, Spacing)'
    ],
    duration: '4–7 Days',
    iconName: 'Palette',
    clientRole: 'Final sign-off on look, feel, typography, and interactive components.'
  },
  {
    number: 5,
    title: 'Front-End Development',
    subtitle: 'Clean, semantic code engineered for performance',
    description: 'We code your website using modern, scalable frameworks with semantic markup, fast load times, and structured data for search engines.',
    deliverables: [
      'Modular, Component-Driven Codebase',
      'Mobile-First Responsive Layouts',
      'Interactive Forms & WhatsApp CTA Integration',
      'Technical SEO & OpenGraph Meta Config'
    ],
    duration: '5–10 Days',
    iconName: 'Code2',
    clientRole: 'Receive staging environment link for initial interactive review.'
  },
  {
    number: 6,
    title: 'Testing & Optimization',
    subtitle: 'Cross-device QA, speed & security audit',
    description: 'Rigorous quality assurance across Safari, Chrome, iOS, Android, and varying network speeds. We stress-test form submissions, link trees, and responsiveness.',
    deliverables: [
      'Cross-Browser & Multi-Device QA Report',
      'Google Core Web Vitals Optimization',
      'SSL, Security & Asset Minification',
      'Lead Capture & Notification Testing'
    ],
    duration: '2–4 Days',
    iconName: 'CheckCircle2',
    clientRole: 'Final acceptance testing on staging URL with your internal team.'
  },
  {
    number: 7,
    title: 'Production Launch',
    subtitle: 'Zero-downtime DNS deployment & live verification',
    description: 'We execute the go-live protocol: connecting your custom domain, setting up production SSL, configuring Google Search Console, and verifying live forms.',
    deliverables: [
      'DNS & Domain Record Configuration',
      'Live Production Deployment',
      'Google Search Console & Sitemap Submission',
      'Post-Launch Live Verification Run'
    ],
    duration: '1–2 Days',
    iconName: 'Rocket',
    clientRole: 'Provide DNS/Registrar access or apply DNS records provided by AIGAINX.'
  },
  {
    number: 8,
    title: 'Handover & Ownership',
    subtitle: 'Full codebase, asset transfer & video guidance',
    description: 'You receive 100% ownership of your website, code, design files, and credentials. We provide a tailored video walkthrough so you are never locked in.',
    deliverables: [
      'Full Repository & Source Code Transfer',
      'Figma Design Assets & Brand Tokens',
      'Personalized Video Walkthrough Guide',
      '30-Day Post-Launch Support Window'
    ],
    duration: 'Day 1 Post-Launch',
    iconName: 'KeyRound',
    clientRole: 'Receive all keys, logins, credentials, and full admin autonomy.'
  }
];

export const CORE_PILLARS = [
  {
    id: 'process',
    title: 'A Real Process, Not Guesswork',
    subtitle: 'Structured 8-step delivery',
    description: 'From discovery and sitemaps to high-fidelity code and handover, every milestone is systematically defined. You always know exactly what is next.',
    iconName: 'Cpu',
    tag: 'Process-Driven'
  },
  {
    id: 'mobile',
    title: 'Mobile-First by Default',
    subtitle: 'Designed for touch & instant response',
    description: 'Over 70% of UAE web traffic originates on mobile devices. Every layout is architected, tested, and optimized for mobile screens first, then scaled for desktop.',
    iconName: 'Smartphone',
    tag: 'Device Precision'
  },
  {
    id: 'conversion',
    title: 'Conversion-Focused Design',
    subtitle: 'Turning visitors into inquiries',
    description: 'Websites must do more than look pretty. We engineer visual paths, sticky mobile CTAs, frictionless WhatsApp links, and clear inquiry funnels that generate business.',
    iconName: 'Target',
    tag: 'Measurable Outcomes'
  },
  {
    id: 'engineering',
    title: 'Modern Architecture & Speed',
    subtitle: 'High-performance digital engineering',
    description: 'We engineer lightweight, modular front-ends built on modern web standards with sub-second load times, clean component architectures, and 90+ Core Web Vitals scores.',
    iconName: 'ShieldCheck',
    tag: 'Quality Standard'
  },
  {
    id: 'ownership',
    title: 'Clean Handover & 100% Ownership',
    subtitle: 'No locked-in black boxes',
    description: 'You walk away with full ownership of your code, design assets, and host accounts. No proprietary traps, no hostage fees, and no recurring handcuffs.',
    iconName: 'Unlock',
    tag: 'True Ownership'
  }
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'corporate-websites',
    title: 'Corporate & Business Websites',
    category: 'Multi-Page Architecture',
    tagline: 'Credible, structured online presence for established companies and firms.',
    targetAudience: 'Real estate agencies, DIFC consultancies, professional firms, B2B services, and Dubai logistics.',
    problem: 'Generic templates look cookie-cutter, load slowly, confuse mobile visitors, and fail to convey corporate authority or licensing credibility in the UAE market.',
    solution: 'We build structured multi-page platforms with clear service taxonomy, leadership profiles, case highlights, and seamless inquiry capture built for decision-makers.',
    features: [
      'Custom Information Architecture & Page Sitemap',
      'Bespoke Visual UI System tailored to your brand identity',
      'Fast Mobile-First Responsive layouts',
      'WhatsApp Business & Direct Phone Floating CTAs',
      'SEO-ready structure, meta headers, and schema markup',
      'Full Source Code transfer & CMS integration options'
    ],
    processSummary: [
      'Stakeholder Discovery & Brand Positioning',
      'Sitemap & Content Taxonomy Mapping',
      'High-Fidelity Desktop & Mobile UI',
      'Performance-Tuned Front-End Build',
      'DNS Deployment & Video Walkthrough'
    ],
    deliverableSnippet: '5 to 15+ Custom Designed Pages, Source Repository, Figma System, SEO Schema, Video Admin Guide.',
    faqs: [
      {
        question: 'Can we update our team or news articles after launch?',
        answer: 'Yes. We build clean, modular components or configure headless content management so your team can edit text and images effortlessly.'
      },
      {
        question: 'Do you configure bilingual English and Arabic layouts?',
        answer: 'Yes, we can architect clean RTL (Right-to-Left) Arabic layouts paired with standard LTR English setups.'
      }
    ]
  },
  {
    id: 'landing-pages',
    title: 'High-Converting Landing Pages',
    category: 'Campaign & Lead Funnels',
    tagline: 'Laser-focused single-page funnels engineered for ad traffic and launches.',
    targetAudience: 'Product releases, real estate off-plan promotions, UAE event registrations, paid Google/Meta ad campaigns.',
    problem: 'Sending paid traffic to a sprawling corporate homepage wastes marketing spend. Visitors get distracted, bounce, and fail to submit inquiries.',
    solution: 'We craft high-impact, single-goal landing pages with structured hero proof points, objection handling, interactive calculators, and high-converting forms.',
    features: [
      'Hero section optimized for sub-3-second value proposition clarity',
      'Benefit-driven layout with visual hierarchy and trust anchors',
      'Frictionless lead forms and direct-to-WhatsApp conversion pathways',
      'Lightweight bundle size for 90+ Google PageSpeed score',
      'Pixel tracking setup (Meta Pixel, Google Tag Manager, GA4)',
      'A/B test ready structure for campaign iteration'
    ],
    processSummary: [
      'Offer & Campaign Objective Alignment',
      'Conversion Wireframing & CTA Staging',
      'High-Energy Visual Design & Social Proof Blocks',
      'Speed Optimization & Tracking Tag Validation',
      'Go-Live with Ad Campaign Sync'
    ],
    deliverableSnippet: 'Dedicated Landing Page, Tracking Tags Configured, Responsive Mobile Optimization, Campaign Ready.',
    faqs: [
      {
        question: 'How quickly can a campaign landing page be designed and launched?',
        answer: 'Typically within 7 to 10 working days through our structured 8-step sprint model.'
      }
    ]
  },
  {
    id: 'ecommerce-catalog',
    title: 'E-Commerce & Digital Catalogues',
    category: 'Product & Commerce Systems',
    tagline: 'Modern, frictionless product showcases designed for buying confidence.',
    targetAudience: 'Boutique UAE retailers, luxury goods, D2C brands, specialized catalogues, and bespoke manufacturers.',
    problem: 'Clunky e-commerce platforms with sluggish checkout flows lose mobile buyers and create customer service friction.',
    solution: 'Clean, elegant product grids with instant filters, high-resolution media galleries, clear UAE currency display (AED), and direct payment/WhatsApp ordering.',
    features: [
      'Structured Category & Product Page Architecture',
      'Smooth Mobile Cart & Checkout Experience',
      'Direct WhatsApp Ordering option for regional buyers',
      'Payment Gateway readiness (Stripe, Tabby, Apple Pay)',
      'Inventory & Product Attribute Management setup',
      'Speed-optimized image loading and lazy asset delivery'
    ],
    processSummary: [
      'Product Taxonomy & Catalog Mapping',
      'Checkout & Payment Flow UX Wireframing',
      'High-End Product Card & Detail Visual Design',
      'Cart & Storefront Engine Integration',
      'Payment Gateway Testing & Launch'
    ],
    deliverableSnippet: 'Catalog Storefront, Product Matrix, Cart/Checkout Integration, Admin Training Manual.',
    faqs: [
      {
        question: 'Can customers order directly via WhatsApp?',
        answer: 'Yes. We can generate auto-filled WhatsApp messages with the selected product title, SKU, and customer inquiry.'
      }
    ]
  },
  {
    id: 'web-replatforming',
    title: 'Performance Redesign & Modernization',
    category: 'Legacy Transformation',
    tagline: 'Upgrading slow, outdated websites into fast, modern systems.',
    targetAudience: 'Businesses with legacy WordPress/builder websites that feel clunky, score poorly on mobile, or fail to convert.',
    problem: 'Outdated websites suffer from plugin bloat, sluggish 6+ second load times, broken mobile menus, and outdated branding that hurts company credibility.',
    solution: 'We audit your existing content, discard bloated plugins, and rebuild the site on a modern, ultra-fast codebase while preserving your SEO rankings.',
    features: [
      'Full Content & SEO Audit of current URLs and rankings',
      'Clean 301 Redirect Mapping to prevent broken links',
      'Modern UI overhaul maintaining established brand recognition',
      'Core Web Vitals acceleration (sub-1-second mobile rendering)',
      'Security hardening with zero legacy plugin vulnerabilities',
      'Full Source Code transfer and DNS cutover with zero downtime'
    ],
    processSummary: [
      'Current Performance & SEO Ranking Audit',
      'Content Migration & URL Redirect Map',
      'Modernized Component Design System',
      'Zero-Bloat Rebuild & Staging Review',
      'Seamless DNS Switch & Live Verification'
    ],
    deliverableSnippet: 'Modernized Codebase, 301 Redirect Mapping, Core Web Vitals Report, Live Migration.',
    faqs: [
      {
        question: 'Will our existing Google rankings be protected during redesign?',
        answer: 'Yes. We create strict 301 redirect maps and preserve key title tags, heading hierarchies, and metadata structures.'
      }
    ]
  }
];

export const CONCEPT_PROJECTS: ConceptProject[] = [
  {
    id: 'mirage-real-estate',
    title: 'Mirage Luxury Residences',
    industry: 'Dubai Real Estate & Off-Plan',
    tagline: 'High-ticket architectural property showcase with floorplan viewer & instant broker inquiry flow.',
    description: 'Designed as a demonstration of high-ticket real estate presentation. Features immersive typography, interactive property attribute filters, floorplan preview drawers, and direct broker WhatsApp routing.',
    isConcept: true,
    keyFeatures: [
      'Property Matrix with AED Price Filters',
      'Interactive Masterplan & Floorplan Drawer',
      'Direct WhatsApp VIP Agent Contact',
      'Mobile-Optimized Virtual Tour Integration'
    ],
    colorTheme: {
      primary: '#0ea5e9',
      accent: '#38bdf8',
      bg: '#0f172a'
    },
    metrics: {
      pageLoad: '0.8s',
      mobileScore: '98/100',
      conversionFocus: 'Broker Inquiries'
    },
    wireframeHighlight: 'Three-tiered layout: Hero Value → Visual Gallery → Specification Matrix → Sticky Mobile Contact Bar.',
    screens: {
      heroTitle: 'Ultra-Luxury Waterfront Living at Palm Jumeirah',
      heroSubtitle: 'Limited collection of 4 & 5-bedroom private residences overlooking the Arabian Gulf.',
      ctaText: 'Request VIP Brochure & Floorplans',
      sampleElements: ['Private Pool', 'Direct Beach Access', '4,850 Sq Ft', 'Handover Q4 2026']
    }
  },
  {
    id: 'the-palm-atelier',
    title: 'The Palm Atelier',
    industry: 'Hospitality & Fine Dining',
    tagline: 'Atmospheric culinary experience with digital tasting menu & streamlined table reservation system.',
    description: 'Demonstrating how a luxury Dubai hospitality brand balances sensory visual elegance with fast, accessible mobile reservations and multi-course menu navigation.',
    isConcept: true,
    keyFeatures: [
      'Interactive Chef Tasting Menu with Dietary Badges',
      'Integrated Table Reservation & Private Dining Form',
      'Curated Photo Journal & Sommelier Highlights',
      'Smooth RTL / Arabic Typography Readiness'
    ],
    colorTheme: {
      primary: '#eab308',
      accent: '#fde047',
      bg: '#18181b'
    },
    metrics: {
      pageLoad: '0.9s',
      mobileScore: '96/100',
      conversionFocus: 'Table Bookings'
    },
    wireframeHighlight: 'Atmospheric typography paired with floating reservation anchor that never leaves the viewport.',
    screens: {
      heroTitle: 'Contemporary Mediterranean Mastery in Downtown Dubai',
      heroSubtitle: 'An intentional culinary narrative crafted with seasonal heritage ingredients.',
      ctaText: 'Reserve an Evening Table',
      sampleElements: ['Degustation Menu', 'Private Dining Room', 'Valet Available', 'Michelin-Selected Chef']
    }
  },
  {
    id: 'kite-coast',
    title: 'Kite & Coast Goods',
    industry: 'UAE Retail & Lifestyle D2C',
    tagline: 'Mobile-first apparel showcase with AED currency switching, instant sizing guides & fast checkout.',
    description: 'A concept e-commerce system built for modern UAE lifestyle brands. Prioritizes thumb-zone navigation, clean product cards, and instant WhatsApp ordering for customers on the go.',
    isConcept: true,
    keyFeatures: [
      'Sub-second Category Navigation & Filters',
      'Quick-View Drawer with AED Price Calculation',
      'One-Tap WhatsApp Order Assistant',
      'Same-Day Dubai Delivery Banner Logic'
    ],
    colorTheme: {
      primary: '#10b981',
      accent: '#34d399',
      bg: '#064e3b'
    },
    metrics: {
      pageLoad: '0.7s',
      mobileScore: '99/100',
      conversionFocus: 'Mobile Cart Additions'
    },
    wireframeHighlight: 'Two-column mobile product grid with sticky bottom bar showing cart total and checkout progress.',
    screens: {
      heroTitle: 'Performance Linen & Coastal Essentials for UAE Living',
      heroSubtitle: 'Breathable, sustainable fabrics tailored for year-round warmth.',
      ctaText: 'Explore New Arrivals',
      sampleElements: ['100% French Linen', 'Same-Day Dubai Delivery', 'Free UAE Returns', 'Tabby 4-Split Available']
    }
  },
  {
    id: 'aura-capital',
    title: 'Aura Capital Partners',
    industry: 'DIFC Professional Services & Wealth',
    tagline: 'High-trust corporate authority site for asset managers, corporate structuring, and family offices.',
    description: 'Engineered for credibility, compliance, and clarity. Demonstrates structured advisory taxonomy, partner biographies, deal tombstone timelines, and confidential inquiry routing.',
    isConcept: true,
    keyFeatures: [
      'Structured Advisory & Family Office Taxonomy',
      'Partner Profiles with Verification Credentials',
      'Secure Consultation Request Funnel',
      'Bilingual Arabic / English Framework'
    ],
    colorTheme: {
      primary: '#6366f1',
      accent: '#818cf8',
      bg: '#1e1b4b'
    },
    metrics: {
      pageLoad: '0.8s',
      mobileScore: '97/100',
      conversionFocus: 'Corporate Inquiries'
    },
    wireframeHighlight: 'Clean grid architecture emphasizing track record data points and regulatory transparency.',
    screens: {
      heroTitle: 'Strategic Capital & Advisory for Middle East Growth',
      heroSubtitle: 'Institutional guidance for family enterprises, private equity, and cross-border transactions.',
      ctaText: 'Schedule Confidential Briefing',
      sampleElements: ['DIFC Registered', 'Cross-Border M&A', 'Family Office Governance', 'Asset Structuring']
    }
  }
];

export const PACKAGES: PackageTier[] = [
  {
    id: 'starter',
    name: 'Starter System',
    tagline: 'Ideal for launching a modern, professional digital presence with zero compromise on quality.',
    idealFor: 'Emerging Dubai businesses, single-location practices, or focused service providers needing credibility.',
    timeline: '7–12 Business Days',
    deliverables: [
      'Up to 5 Custom-Designed Core Pages (Home, About, Services, Contact, Terms)',
      'Full 8-Step Structured Process from Sitemap to Launch',
      'Mobile-First Responsive Layout with Cross-Device QA',
      'WhatsApp Floating Lead Button & Custom Contact Form',
      'Technical SEO Structure & Meta Header Configuration',
      '100% Code & Asset Handover + 30-Day Support'
    ],
    processHighlights: [
      'Discovery Kickoff Call',
      'Sitemap & Wireframe Blueprint',
      'High-Fidelity UI Design',
      'Staging Link for Testing',
      'Live DNS Launch'
    ],
    popular: false
  },
  {
    id: 'business',
    name: 'Business Performance System',
    badge: 'Most Popular',
    tagline: 'Comprehensive web architecture engineered for growing companies that demand conversion volume.',
    idealFor: 'Real estate firms, consultancies, B2B services, and multi-service companies competing in the UAE.',
    timeline: '12–18 Business Days',
    deliverables: [
      'Up to 10–12 Custom Structured Pages (Comprehensive Service Sub-Pages, Case Studies, Team)',
      'Bespoke Figma Design System with Custom Micro-Interactions',
      'Integrated Content Management (CMS) for Easy Updates',
      'Lead Capture Funnels with Email & CRM Webhook Routing',
      'Performance Optimization (< 1s Mobile Core Web Vitals)',
      'English & Arabic (RTL) Layout Readiness (optional add-on)',
      '100% Source Code Transfer + Video Walkthrough Guide'
    ],
    processHighlights: [
      'Comprehensive Competitor & Flow Discovery',
      'Information Architecture & Conversion Mapping',
      'Complete Desktop & Mobile Figma Suite',
      'Modular Codebase & Security Hardening',
      'Full Admin Onboarding Walkthrough'
    ],
    popular: true
  },
  {
    id: 'bespoke',
    name: 'Bespoke Enterprise / E-Commerce',
    tagline: 'Tailored digital platforms for high-volume catalogs, multi-branch brands, or complex workflows.',
    idealFor: 'Retail brands, luxury developments, multi-entity groups, and custom digital portals.',
    timeline: '3–5 Weeks',
    deliverables: [
      'Unlimited Architectural Scope & Custom Funnel Routing',
      'Advanced Product Catalog / Filter System or Booking Flow',
      'Payment Gateway Integration (Stripe, UAE Gateways, Tabby)',
      'Multi-Language (EN/AR) Full Localization Architecture',
      'Advanced Analytics & Event Tracking (GA4, Meta, Tag Manager)',
      'Priority Post-Launch 60-Day Dedicated Support & SLA'
    ],
    processHighlights: [
      'Deep Architecture & Database Planning',
      'Multi-Breakpoint Design Prototypes',
      'Full-Stack Component Engineering',
      'End-to-End Stress & Payment Testing',
      'Complete Infrastructure Handover'
    ],
    popular: false
  }
];

export const FAQS = [
  {
    q: 'How does AIGAINX Portal differ from freelance designers or generic builders?',
    a: 'Freelancers often improvise as they go, leading to scope creep, delayed launches, and messy code. Generic site builders lock you into proprietary subscription traps. AIGAINX operates through a structured 8-step process with clear milestones, delivering clean code that you own 100% upon handover.'
  },
  {
    q: 'What technology stack and standards do you build with?',
    a: 'We build custom, ultra-fast web architectures using modern TypeScript, React, Next.js, and high-performance CSS frameworks. Every project is optimized for sub-second Core Web Vitals, clean semantic HTML, and multi-device responsiveness.'
  },
  {
    q: 'Do you use pre-made templates?',
    a: 'No. Every project is architected as a custom system starting from your specific sitemap, user flow, and conversion objectives. We build custom layouts tailored specifically to your industry and brand.'
  },
  {
    q: 'Who owns the website and code once completed?',
    a: 'You do. Step 8 of our process is full Handover & Ownership. You receive complete repository access, design files in Figma, credentials, and full admin autonomy. There are no hostage fees or forced lock-ins.'
  },
  {
    q: 'Can we integrate WhatsApp chat and UAE payment gateways?',
    a: 'Yes. Every project includes mobile-optimized floating WhatsApp triggers and custom contact funnels. For e-commerce and booking projects, we integrate standard UAE payment gateways, Apple Pay, and local checkout options.'
  },
  {
    q: 'How long does a typical project take from discovery to launch?',
    a: 'Because of our 8-step structured process, most Starter Systems launch within 7–12 business days, while Business Performance Systems take 12–18 business days. We set concrete milestones at kickoff and stick to them.'
  }
];

export const CLIENT_SUCCESS_STATS = [
  {
    metric: '100%',
    label: 'Client Source Ownership',
    detail: 'Full repository, design tokens & credentials transfer'
  },
  {
    metric: '< 0.8s',
    label: 'Average Core Web Vitals',
    detail: 'Lightweight, ultra-fast modular architecture'
  },
  {
    metric: '100%',
    label: 'Milestone Precision',
    detail: 'Strict 8-step adherence with zero scope creep'
  },
  {
    metric: '5.0 / 5',
    label: 'Client Satisfaction',
    detail: 'Verified feedback across UAE & regional deliveries'
  }
];

export const TESTIMONIALS_DATA: TestimonialItem[] = [
  {
    id: 'tariq-apex',
    clientName: 'Tariq Al-Mansoor',
    role: 'Managing Director',
    company: 'Apex Capital Advisors',
    industry: 'Corporate & Finance',
    location: 'Dubai DIFC, UAE',
    projectType: 'Institutional Authority Portal',
    quote: 'AIGAINX replaced our outdated template with a razor-sharp, ultra-fast institutional portal. The 8-step process kept our executive board informed at every milestone without ambiguity or timeline slippage.',
    keyOutcome: {
      metric: '+240%',
      label: 'Qualified Inbound Inquiries'
    },
    deliveryTimeframe: '14 Business Days',
    tags: ['8-Step Engineering', 'Sub-Second Vitals', '100% Handover'],
    rating: 5
  },
  {
    id: 'elena-vanguard',
    clientName: 'Elena Rostova',
    role: 'Head of Marketing',
    company: 'Vanguard Luxury Properties',
    industry: 'Real Estate & Luxury',
    location: 'Downtown Dubai, UAE',
    projectType: 'High-Conversion Off-Plan Showcase',
    quote: 'Our off-plan developments demand uncompromising visual prestige and instant mobile responsiveness. The custom WhatsApp funnel and floorplan visualizer doubled our broker lead conversion in month one.',
    keyOutcome: {
      metric: '3.4x',
      label: 'Mobile Lead Conversion'
    },
    deliveryTimeframe: '16 Business Days',
    tags: ['Luxury UI/UX', 'WhatsApp Funnel', 'Figma Tokens'],
    rating: 5
  },
  {
    id: 'farhan-novacore',
    clientName: 'Dr. Farhan Siddiqui',
    role: 'Founder & CEO',
    company: 'Novacore AI Solutions',
    industry: 'SaaS & Technology',
    location: 'Dubai Internet City, UAE',
    projectType: 'Enterprise Product & Demo Portal',
    quote: 'As a tech company, we could not settle for generic agency templates. AIGAINX built a high-performance React frontend that scores 98 on Core Web Vitals and communicates our enterprise value instantly.',
    keyOutcome: {
      metric: '0.6s',
      label: 'Average Web Vitals Load'
    },
    deliveryTimeframe: '11 Business Days',
    tags: ['Modern React/TS', 'Dark Architectural UI', 'Technical SEO'],
    rating: 5
  },
  {
    id: 'kareem-aura',
    clientName: 'Kareem El-Sayed',
    role: 'Operations Director',
    company: 'Aura Dining Group',
    industry: 'Hospitality & Dining',
    location: 'Jumeirah, Dubai, UAE',
    projectType: 'Multi-Venue Reservation & Experience Hub',
    quote: 'Managing 4 distinct hospitality venues under one unified digital system seemed daunting. AIGAINX structured the navigation logic flawlessly — our direct table bookings increased within days of deployment.',
    keyOutcome: {
      metric: '+165%',
      label: 'Direct Online Bookings'
    },
    deliveryTimeframe: '12 Business Days',
    tags: ['Multi-Venue IA', 'Direct Booking Integration', 'Mobile-First'],
    rating: 5
  },
  {
    id: 'zahra-lumiere',
    clientName: 'Zahra Al-Husseini',
    role: 'Creative Director',
    company: 'Lumière Haute Horlogerie',
    industry: 'Luxury Retail & E-Commerce',
    location: 'Dubai Mall Fashion Ave, UAE',
    projectType: 'Bespoke Private Client Catalog',
    quote: 'Every interaction feels weighted and intentional. The bespoke design system and lightning-fast product filtering elevated our private watch collection for VIP clients across the GCC.',
    keyOutcome: {
      metric: '99.4%',
      label: 'Mobile Speed Score'
    },
    deliveryTimeframe: '18 Business Days',
    tags: ['Custom Catalog', 'VIP Inquiry Gateway', 'Clean Architecture'],
    rating: 5
  },
  {
    id: 'marcus-stratos',
    clientName: 'Marcus Vance',
    role: 'Managing Partner',
    company: 'Stratos Logistics Group',
    industry: 'Logistics & Infrastructure',
    location: 'Dubai South / DWC, UAE',
    projectType: 'Corporate Fleet & Regional Portal',
    quote: 'No buzzwords, no bloated agency retainers. The code handover was completely transparent with full GitHub repository transfer and a video guide our internal team appreciated.',
    keyOutcome: {
      metric: '100%',
      label: 'On-Time Milestone Delivery'
    },
    deliveryTimeframe: '10 Business Days',
    tags: ['Zero-Downtime Launch', 'Clean Semantic Code', 'Full Repository Transfer'],
    rating: 5
  }
];

