import { ProjectAsset, ClientProject } from '../types';

export const ASSETS_STORAGE_KEY = 'aigainx_project_assets_store';

export const INITIAL_PROJECT_ASSETS: ProjectAsset[] = [
  // ==========================================
  // APEX CAPITAL ADVISORS (PRJ-2026-081)
  // ==========================================
  {
    id: 'AST-APEX-001',
    projectId: 'PRJ-2026-081',
    projectTitle: 'Apex Capital DIFC Advisory Hub',
    title: 'Executive Information Architecture & Sitemap Spec',
    category: 'architecture',
    format: 'sitemap',
    version: 'v2.4 (Approved)',
    fileSize: '2.4 MB',
    updatedAt: '2026-08-16',
    author: 'Principal IA Architect (Dubai Studio)',
    status: 'approved',
    description: 'Comprehensive 10-page structural hierarchy mapping DIFC regulatory disclosure, leadership taxonomy, and mobile routing trees.',
    tags: ['Sitemap', 'Navigation', 'DIFC Compliance', 'Mobile Route'],
    thumbnailGradient: 'from-blue-600 to-cyan-700',
    previewContent: {
      summary: 'Structured routing blueprint for Apex Capital DIFC. Configured for sub-0.5s navigation speed with full breadcrumb schema and SEO metadata.',
      metaDetails: [
        { label: 'Total Pages', value: '10 Core Routes' },
        { label: 'Routing Framework', value: 'React Router / SPA' },
        { label: 'SEO Schema', value: 'FinancialService / Organization' },
        { label: 'DIFC License Spec', value: 'Regulatory Notice #F004812' }
      ],
      sitemapNodes: [
        {
          id: 'sm-1',
          page: 'Home / Executive Gateway',
          route: '/',
          status: 'approved',
          description: 'High-contrast institutional landing with real-time fund performance metrics & Dubai skyline visual.',
          componentsCount: 8,
          children: [
            { page: 'Hero Portfolio Viewport', route: '/#overview', description: 'Dual CTA for Private Wealth & Institutional desks' },
            { page: 'Capital Strategy Grid', route: '/#strategies', description: 'Structured tier comparison with DIFC disclosures' }
          ]
        },
        {
          id: 'sm-2',
          page: 'Advisory Solutions',
          route: '/solutions',
          status: 'approved',
          description: 'Specialized wealth management, M&A syndication, and sovereign advisory pillars.',
          componentsCount: 6,
          children: [
            { page: 'Institutional Advisory', route: '/solutions/institutional', description: 'Fund management & cross-border structuring' },
            { page: 'Family Office Custody', route: '/solutions/family-office', description: 'Multi-generational governance' }
          ]
        },
        {
          id: 'sm-3',
          page: 'DIFC Regulatory & Leadership',
          route: '/governance',
          status: 'approved',
          description: 'Executive bio cards, statutory compliance attestations, and audit committee records.',
          componentsCount: 5
        },
        {
          id: 'sm-4',
          page: 'Private Client Portal Gateway',
          route: '/portal',
          status: 'approved',
          description: 'Secure 2FA login gateway connecting to custodial reporting feeds.',
          componentsCount: 4
        },
        {
          id: 'sm-5',
          page: 'Direct Advisory Consultation',
          route: '/contact',
          status: 'approved',
          description: 'Interactive consultation request form with WhatsApp desk routing and Emirates Towers office map.',
          componentsCount: 3
        }
      ]
    }
  },
  {
    id: 'AST-APEX-002',
    projectId: 'PRJ-2026-081',
    projectTitle: 'Apex Capital DIFC Advisory Hub',
    title: 'High-Fidelity Figma Design System & Tokens',
    category: 'design',
    format: 'figma',
    version: 'v3.1 (Handover Ready)',
    fileSize: '48.6 MB',
    updatedAt: '2026-08-19',
    author: 'Lead Design Architect (Dubai Studio)',
    status: 'ready',
    description: 'Precision typography hierarchy, deep slate navy palette, gold metallic micro-accents, and 44px+ mobile touch target UI library.',
    tags: ['Figma', 'Design System', 'Tokens', 'Auto-Layout'],
    thumbnailGradient: 'from-indigo-600 to-purple-800',
    previewContent: {
      summary: 'Complete institutional UI token kit with dark & light viewport variables, accessible 7:1 contrast ratios, and modular bento layout cards.',
      metaDetails: [
        { label: 'Design Tool', value: 'Figma Auto-Layout v5' },
        { label: 'Color Space', value: 'Display P3 & sRGB' },
        { label: 'Typography Pairing', value: 'Outfit & Plus Jakarta Sans' },
        { label: 'Responsive Breakpoints', value: '375px, 768px, 1280px, 1536px' }
      ],
      designTokens: [
        { name: '--color-navy-primary', category: 'color', value: '#0a0f1d', description: 'Institutional canvas background' },
        { name: '--color-navy-surface', category: 'color', value: '#111827', description: 'Card elevation surface' },
        { name: '--color-gold-accent', category: 'color', value: '#d4af37', description: 'Tier highlight & button gradient stop' },
        { name: '--color-emerald-success', category: 'color', value: '#10b981', description: 'Positive fund yield indicator' },
        { name: '--font-heading', category: 'typography', value: 'Outfit, sans-serif (800 Extrabold)', description: 'Primary display font' },
        { name: '--font-body', category: 'typography', value: 'Plus Jakarta Sans, sans-serif (400/500)', description: 'Editorial reading baseline' },
        { name: '--radius-card', category: 'radius', value: '16px (Outer) / 10px (Inner)', description: 'Consistent corner geometry' },
        { name: '--shadow-elevation-3', category: 'shadow', value: '0 20px 40px -15px rgba(0,0,0,0.6)', description: 'Floating modal and sheet depth' }
      ],
      figmaFrames: [
        { name: '01_Desktop_Homepage_Dark', type: 'Desktop 1440px', dimensions: '1440 × 3840', description: 'Hero with animated yield counter & leadership cards' },
        { name: '02_Mobile_Homepage_390', type: 'Mobile iOS 390px', dimensions: '390 × 4200', description: 'Sticky bottom inquiry bar & thumb-friendly menu' },
        { name: '03_Governance_Profiles', type: 'Desktop 1440px', dimensions: '1440 × 2400', description: 'Grid of managing partners with verified credentials' },
        { name: '04_Components_Library', type: 'Master Kit', dimensions: '3200 × 2800', description: 'Buttons, pills, dialogs, form inputs & graph bars' }
      ]
    }
  },
  {
    id: 'AST-APEX-003',
    projectId: 'PRJ-2026-081',
    projectTitle: 'Apex Capital DIFC Advisory Hub',
    title: 'Source Code Repository & Cloudflare Deploy Spec',
    category: 'code',
    format: 'typescript',
    version: 'Release v1.0.0-rc3',
    fileSize: '14.2 MB',
    updatedAt: '2026-08-20',
    author: 'Principal Fullstack Engineer (Dubai Studio)',
    status: 'ready',
    description: 'Clean TypeScript codebase with React 19, zero unnecessary dependencies, and Cloudflare Pages Edge deployment configuration.',
    tags: ['TypeScript', 'Git Repository', 'Cloudflare Pages', 'Tailwind CSS'],
    thumbnailGradient: 'from-emerald-600 to-teal-800',
    previewContent: {
      summary: 'Production-ready web application with automated GitHub Actions CI/CD pipeline, SSL TLS 1.3, and sub-30ms global edge caching.',
      metaDetails: [
        { label: 'Language', value: 'TypeScript v5.6 (Strict Mode)' },
        { label: 'Frontend Engine', value: 'React 19 + Vite 6' },
        { label: 'Bundle Size', value: '64 KB gzipped (Zero Bloat)' },
        { label: 'Edge Network', value: 'Cloudflare Pages Enterprise CDN' }
      ],
      codeSnippets: [
        {
          filename: 'src/config/apexConfig.ts',
          language: 'typescript',
          description: 'Institutional metadata and regulatory notice constants',
          code: `export const APEX_CONFIG = {
  entityName: 'Apex Capital Advisors DIFC Ltd',
  licenseNo: 'DIFC-RN-4812',
  jurisdiction: 'Dubai International Financial Centre (DIFC)',
  primaryAddress: 'Gate Precinct 4, Level 5, DIFC, Dubai, UAE',
  security: {
    enforceHttps: true,
    hstsMaxAge: 31536000,
    contentSecurityPolicy: "default-src 'self' https://api.apexcapital.ae;"
  },
  performanceTarget: {
    maxLcpMs: 800,
    minPageSpeed: 98
  }
} as const;`
        },
        {
          filename: 'wrangler.toml',
          language: 'toml',
          description: 'Cloudflare Edge CDN configuration with UAE routing preference',
          code: `name = "apex-capital-web"
pages_build_output_dir = "dist"
compatibility_date = "2026-08-01"

[env.production]
routes = [
  { pattern = "apexcapital.ae/*", zone_name = "apexcapital.ae" },
  { pattern = "www.apexcapital.ae/*", zone_name = "apexcapital.ae" }
]

[env.production.vars]
NODE_ENV = "production"
ENABLE_EDGE_CACHE = "true"
CACHE_CONTROL = "public, max-age=31536000, immutable"`
        }
      ]
    }
  },
  {
    id: 'AST-APEX-004',
    projectId: 'PRJ-2026-081',
    projectTitle: 'Apex Capital DIFC Advisory Hub',
    title: 'Signed Master Services Agreement & IP Assignment',
    category: 'document',
    format: 'pdf',
    version: 'Executed Contract',
    fileSize: '1.8 MB',
    updatedAt: '2026-08-04',
    author: 'Legal & Compliance (AIGAINX Studio)',
    status: 'approved',
    description: 'Bilingual UAE commercial agreement, VAT compliance registration, and complete intellectual property ownership assignment.',
    tags: ['Contract', 'IP Transfer', 'VAT Compliant', 'Dubai DED'],
    thumbnailGradient: 'from-amber-600 to-orange-800',
    previewContent: {
      summary: 'Binding commercial contract governed by UAE Federal Decree-Law No. 32 of 2021. Confirms 100% unconditional transfer of all code, assets, and copyrights upon milestone completion.',
      metaDetails: [
        { label: 'Contract Reference', value: 'AIGX-MSA-2026-081' },
        { label: 'Studio Licence', value: 'DED #1646775 (Web-Design 722903)' },
        { label: 'Client Entity', value: 'Apex Capital Advisors DIFC Ltd' },
        { label: 'Total Consideration', value: 'AED 9,345 (VAT Inclusive)' }
      ],
      docSections: [
        {
          title: '1. Scope of Deliverables & Performance Milestones',
          paragraphs: [
            'AIGAINX agrees to architect, design, build, and deploy the Apex Capital DIFC Advisory Hub comprising 10 custom pages, mobile-first responsive interfaces, and DIFC regulatory compliance sections.',
            'All development shall strictly adhere to Google Core Web Vitals targets with PageSpeed performance score exceeding 95 on mobile networks.'
          ]
        },
        {
          title: '2. Unconditional Intellectual Property (IP) Transfer',
          paragraphs: [
            'Upon settlement of the final milestone payment, AIGAINX unconditionally and irrevocably assigns and transfers to Apex Capital Advisors all rights, title, copyright, and interest in and to the software code, graphics, layouts, and repository assets.',
            'Apex Capital Advisors retains unrestricted rights to host, modify, license, or self-maintain the application indefinitely without recurring proprietary lock-in fees.'
          ],
          callout: '100% Source Code & Figma Tokens transferred to client upon launch.'
        },
        {
          title: '3. Jurisdiction & Dispute Resolution',
          paragraphs: [
            'This Agreement is executed under and governed by the laws of the Emirate of Dubai and the applicable Federal Laws of the United Arab Emirates. Any dispute shall be referred to the Dubai Courts or DIFC Courts.'
          ]
        }
      ]
    }
  },

  // ==========================================
  // VANGUARD LUXURY PROPERTIES (PRJ-2026-082)
  // ==========================================
  {
    id: 'AST-VANG-001',
    projectId: 'PRJ-2026-082',
    projectTitle: 'Vanguard Luxury Off-Plan Funnel',
    title: 'Off-Plan Property Lead Flow Wireframes & UX Blueprint',
    category: 'wireframe',
    format: 'wireframe',
    version: 'v2.0 (In Review)',
    fileSize: '3.8 MB',
    updatedAt: '2026-08-18',
    author: 'Senior UX Strategist (Dubai Studio)',
    status: 'in_review',
    description: 'Wireframe schematics for Palm Jumeirah and Downtown Dubai ultra-luxury off-plan penthouse lead capture and brochure dispatch flow.',
    tags: ['Wireframes', 'Lead Funnel', 'Real Estate', 'Palm Jumeirah'],
    thumbnailGradient: 'from-amber-500 to-rose-700',
    previewContent: {
      summary: 'Conversion-engineered wireframes featuring 3-step high-intent buyer qualification (Budget bracket, Citizenship, Investment Horizon) and instant VIP WhatsApp handover.',
      metaDetails: [
        { label: 'Primary Target', value: 'HNW International Investors' },
        { label: 'Key Conversion CTA', value: 'Request Private Off-Plan Lookbook' },
        { label: 'Form Completion Goal', value: '< 25 Seconds on Mobile' },
        { label: 'Integrations', value: 'WhatsApp Business API + CRM Webhook' }
      ],
      interactiveHotspots: [
        { label: 'Floating 1-Tap WhatsApp Dial', x: 88, y: 92, description: 'Direct connection to senior property broker within 60 seconds.' },
        { label: 'Interactive Floor Plan Zoom', x: 50, y: 45, description: 'Vector SVG floor plans with high-res penthouse specs.' },
        { label: 'ROI & Payment Plan Calculator', x: 25, y: 65, description: 'Dynamic 60/40 and 70/30 post-handover payment plan simulator.' }
      ],
      sitemapNodes: [
        {
          id: 'vg-1',
          page: 'Hero Video Showcase',
          route: '/#properties',
          status: 'approved',
          description: 'Cinematic full-bleed showcase of Palm Jumeirah branded villas.',
          componentsCount: 4
        },
        {
          id: 'vg-2',
          page: 'Dynamic Unit Selector & ROI',
          route: '/#units',
          status: 'in_progress',
          description: 'Filter by bedroom count, private pool availability, and estimated rental yield.',
          componentsCount: 6
        },
        {
          id: 'vg-3',
          page: 'VIP Lookbook Download Gate',
          route: '/#download',
          status: 'approved',
          description: 'Lead capture form validating phone numbers with country code autocomplete.',
          componentsCount: 3
        }
      ]
    }
  },
  {
    id: 'AST-VANG-002',
    projectId: 'PRJ-2026-082',
    projectTitle: 'Vanguard Luxury Off-Plan Funnel',
    title: 'Brand Identity & Vector Asset Kit',
    category: 'brand',
    format: 'svg',
    version: 'v1.2 (Approved)',
    fileSize: '8.4 MB',
    updatedAt: '2026-08-14',
    author: 'Brand Design Lead (Dubai Studio)',
    status: 'approved',
    description: 'Monogram marks, gold luxury gradient SVG emblems, high-resolution favicon package, and typography usage guidelines.',
    tags: ['Brand Kit', 'SVG Assets', 'Gold Foil Vector', 'Logomark'],
    thumbnailGradient: 'from-amber-600 to-yellow-700',
    previewContent: {
      summary: 'Complete vector identity system tailored for ultra-prime Dubai real estate marketing across 4K displays and mobile retina screens.',
      metaDetails: [
        { label: 'Primary Brand Color', value: '#C6A867 (Desert Champagne Gold)' },
        { label: 'Secondary Background', value: '#080B10 (Obsidian Black)' },
        { label: 'Logotype Font', value: 'Cinzel Decorative / Outfit' },
        { label: 'Asset Formats', value: 'SVG, PNG 4K, WebP, PDF Vector' }
      ],
      designTokens: [
        { name: '--color-gold-champagne', category: 'color', value: '#c6a867', description: 'Primary foil logo metallic finish' },
        { name: '--color-gold-glow', category: 'color', value: 'rgba(198, 168, 103, 0.25)', description: 'Ambient lighting & border glow' },
        { name: '--color-obsidian-dark', category: 'color', value: '#080b10', description: 'Deep contrast background canvas' },
        { name: '--font-serif-luxury', category: 'typography', value: 'Cinzel, Georgia, serif', description: 'Hero property headline typography' }
      ]
    }
  },

  // ==========================================
  // NOVACORE AI SOLUTIONS (PRJ-2026-083)
  // ==========================================
  {
    id: 'AST-NOVA-001',
    projectId: 'PRJ-2026-083',
    projectTitle: 'Novacore Enterprise AI Landing Hub',
    title: 'Technical Discovery Document & API Architecture',
    category: 'document',
    format: 'markdown',
    version: 'v1.0 (Draft)',
    fileSize: '1.2 MB',
    updatedAt: '2026-08-17',
    author: 'Lead Solutions Architect (Dubai Studio)',
    status: 'in_review',
    description: 'Architecture blueprint detailing AI model integration points, edge caching strategy, and latency benchmarks.',
    tags: ['Technical Spec', 'AI Architecture', 'Discovery', 'Edge CDN'],
    thumbnailGradient: 'from-violet-600 to-indigo-900',
    previewContent: {
      summary: 'Discovery roadmap defining technical scope, Gemini 2.5 API integration proxies, serverless edge routing, and bilingual English/Arabic interface requirements.',
      metaDetails: [
        { label: 'Target Launch', value: '2026-08-28' },
        { label: 'API Architecture', value: 'Serverless REST / Node.js' },
        { label: 'Localization', value: 'English (LTR) + Arabic (RTL)' },
        { label: 'Estimated Page Count', value: '5 Fast Landing Sections' }
      ],
      docSections: [
        {
          title: 'Executive Objective',
          paragraphs: [
            'Novacore AI requires an authoritative, high-conversion technical product landing page showcasing enterprise automation agents to UAE government and commercial buyers.'
          ]
        },
        {
          title: 'Core Technical Requirements',
          paragraphs: [
            '1. Sub-0.7 second First Contentful Paint across UAE telecom networks (e& / du).',
            '2. Interactive AI Agent Workflow Simulator rendered entirely on client-side canvas without heavy WebGL dependencies.',
            '3. Secure enterprise demo booking flow connected directly to Google Calendar and HubSpot webhook.'
          ]
        }
      ]
    }
  }
];

export const getStoredProjectAssets = (): ProjectAsset[] => {
  try {
    const raw = localStorage.getItem(ASSETS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(ASSETS_STORAGE_KEY, JSON.stringify(INITIAL_PROJECT_ASSETS));
      return INITIAL_PROJECT_ASSETS;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse project assets from storage', e);
    return INITIAL_PROJECT_ASSETS;
  }
};

export const saveProjectAsset = (asset: ProjectAsset): ProjectAsset[] => {
  const current = getStoredProjectAssets();
  const index = current.findIndex(a => a.id === asset.id);
  let updated: ProjectAsset[];
  if (index >= 0) {
    updated = current.map(a => a.id === asset.id ? asset : a);
  } else {
    updated = [asset, ...current];
  }
  localStorage.setItem(ASSETS_STORAGE_KEY, JSON.stringify(updated));
  return updated;
};

// Generate initial placeholder asset bundle for any dynamically created project
export const createDefaultAssetsForProject = (project: ClientProject): ProjectAsset[] => {
  const baseAssets: ProjectAsset[] = [
    {
      id: `AST-${project.id}-001`,
      projectId: project.id,
      projectTitle: project.title,
      title: `${project.title} — Project Charter & Master Agreement`,
      category: 'document',
      format: 'pdf',
      version: 'v1.0 (Signed)',
      fileSize: '1.9 MB',
      updatedAt: project.kickoffDate || new Date().toISOString().split('T')[0],
      author: 'AIGAINX Studio Legal & Architecture',
      status: 'approved',
      description: `Official scope of work, timeline targets (${project.targetDeliveryDate}), and 100% intellectual property transfer assignment.`,
      tags: ['Contract', 'Scope Charter', 'VAT Compliant', 'DED Entity'],
      thumbnailGradient: 'from-blue-600 to-indigo-800',
      previewContent: {
        summary: `Commercial execution charter for ${project.title} (${project.companyName}). Outlines deterministic 8-step delivery milestones and repository handover.`,
        metaDetails: [
          { label: 'Project ID', value: project.id },
          { label: 'Company', value: project.companyName },
          { label: 'Package Tier', value: project.packageName },
          { label: 'Target Go-Live', value: project.targetDeliveryDate }
        ],
        docSections: [
          {
            title: '1. Project Scope & Architecture',
            paragraphs: [
              `AIGAINX will engineer the custom digital system for ${project.companyName} according to the ${project.packageName} specifications.`,
              'All development follows strict mobile-first design, semantic HTML, and Google Core Web Vitals optimization.'
            ]
          },
          {
            title: '2. Code & Repository Ownership',
            paragraphs: [
              'Upon completion, full GitHub repository rights and Figma assets are transferred directly to the client with zero recurring platform vendor lock-in.'
            ],
            callout: 'Full IP transfer confirmed under UAE commercial law.'
          }
        ]
      }
    },
    {
      id: `AST-${project.id}-002`,
      projectId: project.id,
      projectTitle: project.title,
      title: `${project.title} — Information Architecture & Route Tree`,
      category: 'architecture',
      format: 'sitemap',
      version: 'v1.1 (In Progress)',
      fileSize: '2.1 MB',
      updatedAt: new Date().toISOString().split('T')[0],
      author: 'Principal IA Architect',
      status: project.currentStep >= 2 ? 'approved' : 'in_review',
      description: 'Hierarchical navigation layout, touch targets, and conversion funnel routing.',
      tags: ['Sitemap', 'IA Spec', 'Conversion Funnel'],
      thumbnailGradient: 'from-cyan-600 to-blue-800',
      previewContent: {
        summary: `Information architecture and user journey schematic for ${project.title}.`,
        metaDetails: [
          { label: 'Status', value: project.currentStep >= 2 ? 'Approved by Client' : 'In Review' },
          { label: 'Assigned Lead', value: project.assignedLead },
          { label: 'Step Milestone', value: `Step ${project.currentStep} / 8` }
        ],
        sitemapNodes: [
          {
            id: 'sm-gen-1',
            page: 'Main Application Landing',
            route: '/',
            status: 'approved',
            description: 'Hero presentation, value proposition, and primary conversion call to action.',
            componentsCount: 6
          },
          {
            id: 'sm-gen-2',
            page: 'Services & Solutions',
            route: '/services',
            status: project.currentStep >= 3 ? 'approved' : 'in_progress',
            description: 'Structured breakdown of offerings with clear pricing & deliverable points.',
            componentsCount: 4
          },
          {
            id: 'sm-gen-3',
            page: 'Contact & Inquiry Hub',
            route: '/contact',
            status: 'approved',
            description: 'WhatsApp instant contact, inquiry booking form, and interactive map.',
            componentsCount: 3
          }
        ]
      }
    },
    {
      id: `AST-${project.id}-003`,
      projectId: project.id,
      projectTitle: project.title,
      title: `${project.title} — Figma UI Tokens & Master Design Kit`,
      category: 'design',
      format: 'figma',
      version: 'v1.0 (Draft)',
      fileSize: '32.4 MB',
      updatedAt: new Date().toISOString().split('T')[0],
      author: 'Senior UI/UX Designer',
      status: project.currentStep >= 4 ? 'ready' : 'in_review',
      description: 'Color palettes, accessible font hierarchies, responsive mobile cards, and UI components.',
      tags: ['Figma', 'UI Kit', 'Tokens', 'Components'],
      thumbnailGradient: 'from-purple-600 to-indigo-900',
      previewContent: {
        summary: `Visual design tokens and layout system crafted for ${project.title}.`,
        metaDetails: [
          { label: 'Figma Auto-Layout', value: 'Enabled v5' },
          { label: 'Mobile Optimized', value: 'Yes (390px base)' },
          { label: 'Color Accessibility', value: 'WCAG AAA (7:1 Contrast)' }
        ],
        designTokens: [
          { name: '--color-primary', category: 'color', value: '#1e40af', description: 'Primary brand accent' },
          { name: '--color-background', category: 'color', value: '#0b0f19', description: 'Dark high-contrast canvas' },
          { name: '--font-family-display', category: 'typography', value: 'Outfit, sans-serif', description: 'Main headlines' },
          { name: '--font-family-body', category: 'typography', value: 'Plus Jakarta Sans, sans-serif', description: 'Paragraphs' }
        ]
      }
    }
  ];

  return baseAssets;
};
