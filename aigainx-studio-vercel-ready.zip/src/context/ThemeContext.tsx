import React, { createContext, useContext, useState, useEffect } from 'react';

export type PortalTheme = 'dark' | 'blueprint';

interface ThemeContextType {
  theme: PortalTheme;
  toggleTheme: () => void;
  setTheme: (theme: PortalTheme) => void;
  isBlueprint: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<PortalTheme>(() => {
    try {
      const savedTheme = localStorage.getItem('aigainx_portal_theme');
      if (savedTheme === 'blueprint' || savedTheme === 'dark') {
        return savedTheme;
      }
    } catch (e) {
      // ignore storage errors
    }
    return 'dark';
  });

  const setTheme = (newTheme: PortalTheme) => {
    setThemeState(newTheme);
    try {
      localStorage.setItem('aigainx_portal_theme', newTheme);
    } catch (e) {
      // ignore
    }
  };

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'blueprint' : 'dark');
  };

  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    if (theme === 'blueprint') {
      root.classList.add('blueprint-mode');
      root.classList.remove('dark-mode');
    } else {
      root.classList.remove('blueprint-mode');
      root.classList.add('dark-mode');
    }
  }, [theme]);

  return (
    <ThemeContext.Provider
      value={{
        theme,
        toggleTheme,
        setTheme,
        isBlueprint: theme === 'blueprint'
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
