import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { TechTrustTicker } from './components/TechTrustTicker';
import { ProcessSection } from './components/ProcessSection';
import { WhyAigainx } from './components/WhyAigainx';
import { ServicesSection } from './components/ServicesSection';
import { ConceptShowcase } from './components/ConceptShowcase';
import { InteractiveScopeBuilder } from './components/InteractiveScopeBuilder';
import { PackagesSection } from './components/PackagesSection';
import { PaymentArchitectureSection } from './components/PaymentArchitectureSection';
import { ClientSuccessSection } from './components/ClientSuccessSection';
import { AboutLicenceSection } from './components/AboutLicenceSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CheckoutModal } from './components/CheckoutModal';
import { ClientDashboardModal } from './components/ClientDashboardModal';
import { AdminPortalModal } from './components/AdminPortalModal';
import { InvoiceReceiptModal } from './components/InvoiceReceiptModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { BRAND_CONFIG } from './data/portalData';
import { InvoiceRecord, PaymentRecord } from './types';
import { MessageSquare, ArrowUp } from 'lucide-react';

export default function App() {
  const [prefilledMessage, setPrefilledMessage] = useState<string>('');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [showBackToTop, setShowBackToTop] = useState(false);

  // Payment & Portal Modals
  const [showCheckout, setShowCheckout] = useState(false);
  const [checkoutPackageId, setCheckoutPackageId] = useState<string>('business');
  const [checkoutCustomScope, setCheckoutCustomScope] = useState<string>('');
  const [showClientDashboard, setShowClientDashboard] = useState(false);
  const [showAdminPortal, setShowAdminPortal] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState<InvoiceRecord | null>(null);
  const [viewingPayment, setViewingPayment] = useState<PaymentRecord | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowBackToTop(true);
      } else {
        setShowBackToTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const addToast = (title: string, description: string, type: 'success' | 'info' = 'success') => {
    const newToast: ToastMessage = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      title,
      description,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setToasts((prev) => [...prev, newToast]);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const scrollToScopeBuilder = () => {
    const el = document.getElementById('scope-builder');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToProcess = () => {
    const el = document.getElementById('process');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToContact = (customPrefill?: string) => {
    if (customPrefill) {
      setPrefilledMessage(customPrefill);
    }
    const el = document.getElementById('contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const openCheckoutWithPackage = (packageId?: string, customScope?: string) => {
    setCheckoutPackageId(packageId || 'business');
    setCheckoutCustomScope(customScope || '');
    setShowCheckout(true);
  };

  const handleFloatingWhatsApp = () => {
    const message = encodeURIComponent(
      `Hello AIGAINX Portal! I am interested in web design services for my UAE business.`
    );
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#090b10] text-[#e2e8f0] flex flex-col relative selection:bg-blue-600 selection:text-white">
      
      {/* Top Fixed Header */}
      <Navbar 
        onOpenScopeBuilder={scrollToScopeBuilder}
        onOpenCheckout={(pkgId) => openCheckoutWithPackage(pkgId)}
        onOpenClientDashboard={() => setShowClientDashboard(true)}
        onOpenAdminPortal={() => setShowAdminPortal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* 1. Hero Section with Positioning Statement and Interactive Blueprint */}
        <Hero 
          onStartProject={() => openCheckoutWithPackage('business')}
          onExploreProcess={scrollToProcess}
        />

        {/* 1.5 Real-time Enterprise Tech Stack & Trust Ticker */}
        <TechTrustTicker />

        {/* 2. The 8-Step Structured Delivery System */}
        <ProcessSection />

        {/* 3. Why AIGAINX (Core Pillars) */}
        <WhyAigainx />

        {/* 4. Services Deep-Dive (Hero -> Problem -> Solution -> Features -> Process -> FAQ -> CTA) */}
        <ServicesSection 
          onRequestServiceQuote={(serviceName) => scrollToContact(`I am interested in requesting a proposal for: ${serviceName}.`)}
        />

        {/* 5. Industry Concept Demonstrations (Strictly Labeled Concept / Demo Project) */}
        <ConceptShowcase 
          onSelectConceptToQuote={(conceptName) => scrollToContact(`I saw your ${conceptName} concept and want a similar architecture for my industry.`)}
        />

        {/* 6. Interactive Scope Configurator */}
        <InteractiveScopeBuilder 
          onDirectQuoteSubmit={(scopeSummary) => {
            openCheckoutWithPackage('custom', scopeSummary.features?.join(', '));
            addToast('Scope Configured', 'Redirecting to your commercial checkout & tax invoice generation.');
          }}
          onShowToast={(title, description) => addToast(title, description)}
        />

        {/* 7. Structured Package Systems (Starter / Business / Bespoke) */}
        <PackagesSection 
          onRequestPackageQuote={(packageName) => scrollToContact(`I would like to request an official quote for the ${packageName}.`)}
          onOpenCheckout={(pkgId) => openCheckoutWithPackage(pkgId)}
        />

        {/* 8. AIGAINX High-Level Payment Architecture System */}
        <PaymentArchitectureSection 
          onOpenCheckout={(pkgId) => openCheckoutWithPackage(pkgId)}
          onOpenClientDashboard={() => setShowClientDashboard(true)}
          onOpenAdminPortal={() => setShowAdminPortal(true)}
        />

        {/* 9. Client Success & Social Proof Testimonials */}
        <ClientSuccessSection 
          onSelectProjectScope={(projectType) => scrollToContact(`I saw your client results for ${projectType} and would like to discuss a similar scope for my business.`)}
          onOpenScopeBuilder={scrollToScopeBuilder}
        />

        {/* 10. About & Mission Section + Studio Digital Architecture Card */}
        <AboutLicenceSection 
          onOpenScopeBuilder={scrollToScopeBuilder}
        />

        {/* 11. FAQs Section */}
        <FaqSection />

        {/* 12. Contact & Project Kickoff Form */}
        <ContactSection 
          prefilledScope={prefilledMessage}
          onShowToast={(title, description) => addToast(title, description)}
        />
      </main>

      {/* Footer with Navigation & Sitemaps */}
      <Footer 
        onOpenScopeBuilder={scrollToScopeBuilder}
      />

      {/* Floating Action Buttons Container */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-none">
        
        {/* Floating Back to Top Button */}
        {showBackToTop && (
          <button
            id="back-to-top-btn"
            onClick={scrollToTop}
            className="pointer-events-auto p-3 rounded-full bg-slate-900/90 hover:bg-blue-600 text-slate-300 hover:text-white shadow-xl shadow-black/80 border border-slate-700/80 hover:border-blue-400/50 flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-95 animate-in fade-in slide-in-from-bottom-3 backdrop-blur-md cursor-pointer group"
            title="Back to top"
            aria-label="Back to top of page"
          >
            <ArrowUp className="w-4 h-4 transition-transform group-hover:-translate-y-0.5" />
          </button>
        )}

        {/* Floating WhatsApp Quick Action Button */}
        <button
          id="floating-whatsapp-btn"
          onClick={handleFloatingWhatsApp}
          className="pointer-events-auto p-3.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white shadow-xl shadow-emerald-950/80 border border-emerald-400/40 flex items-center gap-2 group cursor-pointer transition-all hover:scale-105 active:scale-95"
          title="Chat with AIGAINX on WhatsApp (+971)"
        >
          <MessageSquare className="w-5 h-5" />
          <span className="max-w-0 overflow-hidden whitespace-nowrap group-hover:max-w-xs transition-all duration-300 ease-in-out text-xs font-bold pl-0 group-hover:pl-1">
            Chat on WhatsApp
          </span>
        </button>
      </div>

      {/* Checkout Modal Flow */}
      {showCheckout && (
        <CheckoutModal 
          initialPackageId={checkoutPackageId}
          initialCustomScope={checkoutCustomScope}
          onClose={() => setShowCheckout(false)}
          onPaymentSuccess={(invoice, payment) => {
            addToast('Transaction Registered', `Order ${invoice.orderId} successfully initiated.`);
            setViewingInvoice(invoice);
            setViewingPayment(payment);
          }}
        />
      )}

      {/* Client Area Modal */}
      {showClientDashboard && (
        <ClientDashboardModal 
          onClose={() => setShowClientDashboard(false)}
          onOpenCheckout={(pkgId) => {
            setShowClientDashboard(false);
            openCheckoutWithPackage(pkgId);
          }}
          onViewInvoice={(invoice) => setViewingInvoice(invoice)}
          onShowToast={(title, desc, type) => addToast(title, desc, type)}
        />
      )}

      {/* Admin Management & Verification Queue Modal */}
      {showAdminPortal && (
        <AdminPortalModal 
          onClose={() => setShowAdminPortal(false)}
          onViewInvoice={(invoice) => setViewingInvoice(invoice)}
          onShowToast={(title, desc, type) => addToast(title, desc, type)}
        />
      )}

      {/* Tax Invoice & Printable Receipt Modal */}
      {viewingInvoice && (
        <InvoiceReceiptModal 
          invoice={viewingInvoice}
          payment={viewingPayment}
          onClose={() => {
            setViewingInvoice(null);
            setViewingPayment(null);
          }}
        />
      )}

      {/* Real-time Toast Notifications */}
      <ToastContainer 
        toasts={toasts}
        onDismiss={removeToast}
      />

    </div>
  );
}
