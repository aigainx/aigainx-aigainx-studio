import React, { useState, useMemo } from 'react';
import { 
  SlidersHorizontal, 
  Check, 
  ArrowRight, 
  MessageSquare, 
  FileText, 
  Layers, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  Copy, 
  Sparkles, 
  Building2,
  Calculator,
  Coins,
  Info,
  CalendarCheck2
} from 'lucide-react';
import { BRAND_CONFIG } from '../data/portalData';

interface InteractiveScopeBuilderProps {
  onDirectQuoteSubmit?: (scopeSummary: any) => void;
  onShowToast?: (title: string, description: string) => void;
}

interface FeatureOption {
  id: string;
  label: string;
  category: string;
  costMinAed: number;
  costMaxAed: number;
  daysMin: number;
  daysMax: number;
}

export const InteractiveScopeBuilder: React.FC<InteractiveScopeBuilderProps> = ({ onDirectQuoteSubmit, onShowToast }) => {
  const [industry, setIndustry] = useState<string>('Real Estate / Property');
  const [pageScope, setPageScope] = useState<string>('5-7 Pages (Standard Business)');
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    'Mobile-First Responsive Layout',
    'WhatsApp Floating Lead Button',
    'Technical SEO & Schema Markup'
  ]);
  const [timelinePreference, setTimelinePreference] = useState<string>('Standard (2–3 Weeks)');
  const [copied, setCopied] = useState<boolean>(false);
  const [contactName, setContactName] = useState<string>('');
  const [contactEmail, setContactEmail] = useState<string>('');
  const [contactPhone, setContactPhone] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [currency, setCurrency] = useState<'AED' | 'USD'>('AED');

  const featureOptions: FeatureOption[] = [
    { id: 'mobile-first', label: 'Mobile-First Responsive Layout', category: 'Core', costMinAed: 0, costMaxAed: 0, daysMin: 0, daysMax: 0 },
    { id: 'whatsapp-cta', label: 'WhatsApp Floating Lead Button', category: 'Conversion', costMinAed: 0, costMaxAed: 0, daysMin: 0, daysMax: 0 },
    { id: 'seo-schema', label: 'Technical SEO & Schema Markup', category: 'Search', costMinAed: 500, costMaxAed: 800, daysMin: 1, daysMax: 1 },
    { id: 'cms-editor', label: 'Content Management System (CMS)', category: 'Admin', costMinAed: 1500, costMaxAed: 2200, daysMin: 2, daysMax: 3 },
    { id: 'arabic-rtl', label: 'Bilingual English & Arabic (RTL)', category: 'Localization', costMinAed: 2000, costMaxAed: 3000, daysMin: 3, daysMax: 4 },
    { id: 'payment-gateway', label: 'UAE Payment Gateway / Stripe', category: 'Commerce', costMinAed: 2200, costMaxAed: 3500, daysMin: 3, daysMax: 5 },
    { id: 'analytics-tag', label: 'GA4 + Meta Pixel Tracking Setup', category: 'Analytics', costMinAed: 600, costMaxAed: 1000, daysMin: 1, daysMax: 1 },
    { id: 'lead-webhook', label: 'CRM / Email Lead Webhook Routing', category: 'Automation', costMinAed: 800, costMaxAed: 1400, daysMin: 1, daysMax: 2 }
  ];

  const toggleFeature = (label: string) => {
    if (selectedFeatures.includes(label)) {
      setSelectedFeatures(selectedFeatures.filter(f => f !== label));
    } else {
      setSelectedFeatures([...selectedFeatures, label]);
    }
  };

  // Dynamic Estimation Calculations
  const estimate = useMemo(() => {
    let baseMinAed = 6500;
    let baseMaxAed = 9500;
    let baseMinDays = 10;
    let baseMaxDays = 14;

    if (pageScope.includes('Single-Page')) {
      baseMinAed = 3500;
      baseMaxAed = 5500;
      baseMinDays = 6;
      baseMaxDays = 9;
    } else if (pageScope.includes('5-7 Pages')) {
      baseMinAed = 6500;
      baseMaxAed = 9500;
      baseMinDays = 10;
      baseMaxDays = 14;
    } else if (pageScope.includes('8-15 Pages')) {
      baseMinAed = 11000;
      baseMaxAed = 15500;
      baseMinDays = 14;
      baseMaxDays = 20;
    } else if (pageScope.includes('Custom Catalog')) {
      baseMinAed = 16000;
      baseMaxAed = 23500;
      baseMinDays = 18;
      baseMaxDays = 26;
    }

    // Add feature deltas
    let featureMinAed = 0;
    let featureMaxAed = 0;
    let featureMinDays = 0;
    let featureMaxDays = 0;

    featureOptions.forEach(opt => {
      if (selectedFeatures.includes(opt.label)) {
        featureMinAed += opt.costMinAed;
        featureMaxAed += opt.costMaxAed;
        featureMinDays += opt.daysMin;
        featureMaxDays += opt.daysMax;
      }
    });

    let totalMinAed = baseMinAed + featureMinAed;
    let totalMaxAed = baseMaxAed + featureMaxAed;
    let totalMinDays = baseMinDays + Math.round(featureMinDays * 0.7); // concurrency overlap
    let totalMaxDays = baseMaxDays + Math.round(featureMaxDays * 0.8);

    // Fast-track adjustments
    if (timelinePreference.includes('Fast-Track')) {
      totalMinDays = Math.max(5, Math.round(totalMinDays * 0.65));
      totalMaxDays = Math.max(8, Math.round(totalMaxDays * 0.75));
      totalMinAed = Math.round(totalMinAed * 1.15);
      totalMaxAed = Math.round(totalMaxAed * 1.15);
    }

    const conversionRate = 0.272; // AED to USD approx (3.6725 AED = 1 USD)
    const totalMinUsd = Math.round(totalMinAed * conversionRate);
    const totalMaxUsd = Math.round(totalMaxAed * conversionRate);

    return {
      totalMinAed,
      totalMaxAed,
      totalMinUsd,
      totalMaxUsd,
      totalMinDays,
      totalMaxDays,
      baseMinAed,
      baseMaxAed,
      featureMinAed,
      featureMaxAed
    };
  }, [pageScope, selectedFeatures, timelinePreference]);

  const getEstimatedDuration = () => {
    return `${estimate.totalMinDays}–${estimate.totalMaxDays} Business Days`;
  };

  const formattedCost = useMemo(() => {
    if (currency === 'AED') {
      return `AED ${estimate.totalMinAed.toLocaleString()} – ${estimate.totalMaxAed.toLocaleString()}`;
    }
    return `$${estimate.totalMinUsd.toLocaleString()} – $${estimate.totalMaxUsd.toLocaleString()} USD`;
  }, [currency, estimate]);

  const handleCopyScope = () => {
    const text = `AIGAINX PORTAL — PROJECT SCOPE BRIEF & ESTIMATE
Industry: ${industry}
Page Scale: ${pageScope}
Features Required:
${selectedFeatures.map(f => `• ${f}`).join('\n')}
Timeline Preference: ${timelinePreference}
Est. Working Duration: ${getEstimatedDuration()}
Dynamic Investment Estimate: AED ${estimate.totalMinAed.toLocaleString()} – ${estimate.totalMaxAed.toLocaleString()} (~$${estimate.totalMinUsd.toLocaleString()} – $${estimate.totalMaxUsd.toLocaleString()} USD)
Delivery Model: AIGAINX 8-Step System (100% Client Handover & Source Ownership)`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    if (onShowToast) {
      onShowToast(
        'Project Scope Copied',
        'Your structured project brief with dynamic estimate has been copied to clipboard.'
      );
    }
    setTimeout(() => setCopied(false), 3000);
  };

  const handleSendWhatsApp = () => {
    const message = encodeURIComponent(
      `Hello AIGAINX Portal! I built a project scope with dynamic estimate:
• Industry: ${industry}
• Scope: ${pageScope}
• Key Features: ${selectedFeatures.slice(0, 3).join(', ')}${selectedFeatures.length > 3 ? '...' : ''}
• Timeline: ${timelinePreference} (${getEstimatedDuration()})
• Dynamic Range: AED ${estimate.totalMinAed.toLocaleString()} – ${estimate.totalMaxAed.toLocaleString()}
Please confirm availability for discovery kickoff.`
    );
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${message}`, '_blank');
  };

  const handleSubmitScope = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    if (onDirectQuoteSubmit) {
      onDirectQuoteSubmit({
        industry,
        pageScope,
        selectedFeatures,
        timelinePreference,
        estimatedDuration: getEstimatedDuration(),
        estimatedCostAed: `AED ${estimate.totalMinAed.toLocaleString()} – ${estimate.totalMaxAed.toLocaleString()}`,
        contactName,
        contactEmail,
        contactPhone
      });
    }
    if (onShowToast) {
      onShowToast(
        'Project Scope Blueprint Received',
        `Thank you, ${contactName || 'Valued Client'}. Your ${industry} scope (Est: ${formattedCost}) has been logged. We will prepare your official proposal within 4 business hours.`
      );
    }
  };

  return (
    <section 
      id="scope-builder"
      className="py-24 bg-[#090b10] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/60 border border-blue-800/60 text-blue-400 text-xs font-mono-code font-semibold mb-3">
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>INTERACTIVE SCOPE & ESTIMATE CONFIGURATOR</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Configure Your Project Scope & Estimate in Real Time.
          </h2>
          <p className="text-slate-300 text-base mt-2">
            No vague guesswork. Select your industry, scale, and required capabilities to generate a structured project blueprint with an instant time and cost range estimate.
          </p>
        </div>

        {/* 2-Column Layout: Controls on Left, Live Scope Blueprint on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive Scope Selectors */}
          <div className="lg:col-span-7 space-y-8 bg-[#0e131d] p-6 sm:p-8 rounded-2xl border border-slate-800/90 shadow-xl">
            
            {/* 1. Industry Selector */}
            <div className="space-y-3">
              <label className="text-xs font-mono-code uppercase font-semibold text-slate-300 flex items-center justify-between">
                <span>01. Select Your Business Industry</span>
                <span className="text-blue-400">Step 1/4</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  'Real Estate / Property',
                  'Hospitality & Dining',
                  'Retail & E-Commerce',
                  'DIFC / Professional Services',
                  'B2B Tech & Logistics',
                  'Healthcare & Wellness'
                ].map((ind) => (
                  <button
                    key={ind}
                    type="button"
                    onClick={() => setIndustry(ind)}
                    className={`p-3 rounded-xl text-xs font-medium text-left border transition-all cursor-pointer ${
                      industry === ind
                        ? 'bg-blue-600 border-blue-500 text-white font-semibold shadow-md'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-900 hover:border-slate-700'
                    }`}
                  >
                    {ind}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Scale & Page Architecture */}
            <div className="space-y-3">
              <label className="text-xs font-mono-code uppercase font-semibold text-slate-300 flex items-center justify-between">
                <span>02. Select Website Scale & Structure</span>
                <span className="text-blue-400">Step 2/4</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {[
                  { name: 'Single-Page Campaign Funnel', desc: 'Hero, Proof, Form & Sticky Mobile WhatsApp', tier: 'Base 3.5k–5.5k AED' },
                  { name: '5-7 Pages (Standard Business)', desc: 'Home, About, Services, Case Studies, Contact', tier: 'Base 6.5k–9.5k AED' },
                  { name: '8-15 Pages (Comprehensive)', desc: 'Full Taxonomy, Service Sub-Pages, CMS', tier: 'Base 11k–15.5k AED' },
                  { name: 'Custom Catalog / E-Commerce', desc: 'Storefront, Filters, Cart & Payment Gateway', tier: 'Base 16k–23.5k AED' }
                ].map((s) => (
                  <button
                    key={s.name}
                    type="button"
                    onClick={() => setPageScope(s.name)}
                    className={`p-3.5 rounded-xl text-left border transition-all cursor-pointer ${
                      pageScope === s.name
                        ? 'bg-blue-600/20 border-blue-500 text-white font-semibold'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-slate-100">
                      <span>{s.name}</span>
                      {pageScope === s.name && <Check className="w-4 h-4 text-blue-400" />}
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 font-normal">{s.desc}</p>
                    <span className="inline-block mt-2 text-[10px] font-mono-code text-blue-400 font-medium">
                      {s.tier}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* 3. Essential Capabilities & Add-ons */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-mono-code uppercase font-semibold text-slate-300">
                  03. Key Features & Integrations
                </label>
                <span className="text-blue-400 text-xs font-mono-code">Step 3/4</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {featureOptions.map((feat) => {
                  const isChecked = selectedFeatures.includes(feat.label);
                  return (
                    <button
                      key={feat.id}
                      type="button"
                      onClick={() => toggleFeature(feat.label)}
                      className={`p-3 rounded-xl text-left border flex items-center justify-between text-xs transition-all cursor-pointer ${
                        isChecked
                          ? 'bg-slate-800/90 border-blue-500/80 text-white'
                          : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className={`w-4 h-4 rounded flex items-center justify-center border ${
                          isChecked ? 'bg-blue-600 border-blue-500 text-white' : 'border-slate-700 bg-slate-950'
                        }`}>
                          {isChecked && <Check className="w-3 h-3" />}
                        </div>
                        <div>
                          <span className="text-xs font-medium block">{feat.label}</span>
                          {feat.costMaxAed > 0 && (
                            <span className="text-[10px] text-slate-400 font-mono-code">
                              +{feat.costMinAed}–{feat.costMaxAed} AED
                            </span>
                          )}
                        </div>
                      </div>
                      <span className="text-[10px] font-mono-code text-slate-500">
                        {feat.category}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Target Timeline */}
            <div className="space-y-3">
              <label className="text-xs font-mono-code uppercase font-semibold text-slate-300 flex items-center justify-between">
                <span>04. Timeline Preference</span>
                <span className="text-blue-400">Step 4/4</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  'Fast-Track Sprint (7–10 Days)',
                  'Standard (2–3 Weeks)',
                  'Flexible / Planned Launch'
                ].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTimelinePreference(t)}
                    className={`p-3 rounded-xl text-xs font-medium text-center border transition-all cursor-pointer ${
                      timelinePreference === t
                        ? 'bg-blue-600 border-blue-500 text-white font-semibold'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {t.split(' ')[0]} {t.split(' ')[1]}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Dynamic Project Scope Blueprint Card & Instant Dynamic Estimate */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="rounded-2xl bg-[#0e131d] border border-slate-800/90 shadow-2xl p-6 space-y-5 sticky top-24">
              
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-400" />
                  <div>
                    <h3 className="font-display text-base font-bold text-white">
                      Dynamic Scope Blueprint
                    </h3>
                    <p className="text-[11px] text-slate-400 font-mono-code">AIGAINX-SPEC-2026</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400 font-mono-code text-[10px]">
                  LIVE ESTIMATE
                </span>
              </div>

              {/* Dynamic Estimated Cost & Duration Highlight Box */}
              <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 via-blue-950/30 to-slate-900 border border-blue-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono-code uppercase font-semibold text-slate-300 flex items-center gap-1.5">
                    <Coins className="w-3.5 h-3.5 text-blue-400" />
                    <span>Estimated Investment Range</span>
                  </span>
                  {/* Currency Toggle */}
                  <div className="flex rounded-md bg-slate-950 p-0.5 border border-slate-800 text-[10px] font-mono-code font-bold">
                    <button
                      type="button"
                      onClick={() => setCurrency('AED')}
                      className={`px-2 py-0.5 rounded ${currency === 'AED' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                    >
                      AED
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrency('USD')}
                      className={`px-2 py-0.5 rounded ${currency === 'USD' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
                    >
                      USD
                    </button>
                  </div>
                </div>

                <div className="flex items-baseline justify-between gap-2">
                  <div className="font-display text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                    {formattedCost}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Clock className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 block font-mono-code">Est. Delivery</span>
                      <span className="font-semibold text-white">{getEstimatedDuration()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <CalendarCheck2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <div>
                      <span className="text-[10px] text-slate-400 block font-mono-code">Delivery Model</span>
                      <span className="font-semibold text-white">8-Step System</span>
                    </div>
                  </div>
                </div>

                {/* Non-Binding Legal / Process Disclaimer */}
                <div className="flex items-start gap-1.5 pt-1 text-[10px] text-slate-400 leading-tight">
                  <Info className="w-3 h-3 text-slate-400 shrink-0 mt-0.5" />
                  <span>
                    Non-binding indicative estimate. Official firm quote with milestone payment terms issued following brief review.
                  </span>
                </div>
              </div>

              {/* Dynamic Scope Summary Table */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">Target Industry:</span>
                  <span className="font-semibold text-white">{industry}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">Architecture Tier:</span>
                  <span className="font-semibold text-white">{pageScope.split(' ')[0]}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-slate-800/60">
                  <span className="text-slate-400">Client Code Handover:</span>
                  <span className="font-semibold text-emerald-400">100% Unlocked Ownership</span>
                </div>
              </div>

              {/* Features List Mini Pill */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-mono-code text-slate-400 uppercase tracking-wider block">
                  Included Capabilities ({selectedFeatures.length}):
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                  {selectedFeatures.map((f, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                      ✓ {f}
                    </span>
                  ))}
                </div>
              </div>

              {/* Quick Contact Form to Dispatch */}
              {!submitted ? (
                <form onSubmit={handleSubmitScope} className="space-y-3 pt-2 border-t border-slate-800">
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-400 font-medium">Your Name / Company</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Tariq Al Mansoor, Apex Real Estate"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-400 font-medium">Work Email</label>
                      <input 
                        type="email" 
                        required
                        placeholder="tariq@apex.ae"
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] text-slate-400 font-medium">Phone / WhatsApp</label>
                      <input 
                        type="tel" 
                        placeholder="+971 50..."
                        value={contactPhone}
                        onChange={(e) => setContactPhone(e.target.value)}
                        className="w-full px-3 py-2 text-xs rounded-lg bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <span>Request Official Project Proposal</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              ) : (
                <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800 text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                  <p className="text-xs font-bold text-white">Project Scope & Estimate Received</p>
                  <p className="text-[11px] text-slate-300">
                    A senior project lead from AIGAINX Portal will review your specifications ({formattedCost}) and send a formal proposal within 4 hours.
                  </p>
                </div>
              )}

              {/* Action Buttons: WhatsApp & Copy */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleSendWhatsApp}
                  className="py-2.5 px-3 rounded-lg bg-emerald-950/60 border border-emerald-800 hover:bg-emerald-900/60 text-emerald-300 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Send via WhatsApp</span>
                </button>

                <button
                  type="button"
                  onClick={handleCopyScope}
                  className="py-2.5 px-3 rounded-lg bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>{copied ? 'Copied Brief!' : 'Copy Scope & Estimate'}</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-500 font-mono-code pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Dubai Trader Licence 1646775 · Web-Design 722903</span>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
