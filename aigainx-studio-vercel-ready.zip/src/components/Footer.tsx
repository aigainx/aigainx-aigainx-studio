import React from 'react';
import { 
  Layers, 
  MessageSquare, 
  Mail, 
  MapPin, 
  Code2,
  CheckCircle2
} from 'lucide-react';
import { BRAND_CONFIG } from '../data/portalData';

interface FooterProps {
  onOpenScopeBuilder?: () => void;
}

export const Footer: React.FC<FooterProps> = () => {
  const handleWhatsApp = () => {
    const message = encodeURIComponent('Hello AIGAINX Portal, I would like to inquire about a website project.');
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${message}`, '_blank');
  };

  return (
    <footer className="bg-[#07090e] border-t border-slate-800/80 pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Col 1: Brand & Positioning */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl overflow-hidden bg-slate-950 border border-slate-700/80 shadow-md shrink-0">
                <img 
                  src={BRAND_CONFIG.monogramUrl} 
                  alt="AIGAINX Official Monogram" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-display text-lg font-extrabold tracking-tight text-white">
                    AIGAINX
                  </span>
                  <span className="text-[10px] uppercase tracking-widest text-blue-400 font-mono-code font-semibold px-1.5 py-0.5 rounded bg-blue-950/60 border border-blue-800/60">
                    PORTAL
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-mono-code uppercase tracking-wider">
                  {BRAND_CONFIG.brandMeaning}
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Emitac Building, Dubai — bespoke web design studio built on a structured 8-step engineering system, delivering high-performance, conversion-focused digital platforms for modern businesses.
            </p>

            {/* Studio Guarantee Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono-code">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Emitac Building, Dubai · 100% Code Handover</span>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono-code">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#process" className="hover:text-white transition-colors">8-Step System</a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">Services</a>
              </li>
              <li>
                <a href="#packages" className="hover:text-white transition-colors">Packages</a>
              </li>
              <li>
                <a href="#payments" className="hover:text-emerald-400 transition-colors text-emerald-400 font-medium">Payments & UAE Gateways</a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-white transition-colors">Client Success</a>
              </li>
              <li>
                <a href="#concepts" className="hover:text-white transition-colors">Industry Concepts</a>
              </li>
              <li>
                <a href="#scope-builder" className="hover:text-blue-400 transition-colors text-blue-400 font-medium">Scope Builder</a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">About Studio</a>
              </li>
            </ul>
          </div>

          {/* Col 3: Services Taxonomy */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono-code">
              Specialties
            </h4>
            <ul className="space-y-2 text-xs">
              <li>Corporate Websites</li>
              <li>Landing Page Funnels</li>
              <li>E-Commerce Catalogues</li>
              <li>Performance Redesigns</li>
              <li>Mobile-First UI/UX</li>
              <li>100% Code Handover</li>
            </ul>
          </div>

          {/* Col 4: Direct Studio Connection */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono-code">
              Direct Studio Contact
            </h4>
            <div className="space-y-2 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Emitac Building, Dubai, UAE</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-4 h-4 text-indigo-400 shrink-0" />
                <a href={`mailto:${BRAND_CONFIG.email}`} className="hover:text-blue-400 text-slate-200 transition-colors">
                  {BRAND_CONFIG.email}
                </a>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                <a 
                  href={`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}`}
                  target="_blank" 
                  rel="noreferrer"
                  className="hover:text-emerald-300 text-emerald-400 transition-colors"
                >
                  {BRAND_CONFIG.whatsappDisplay}
                </a>
              </div>
              <div className="pt-2">
                <button
                  onClick={handleWhatsApp}
                  className="w-full py-2 px-3 rounded-lg bg-emerald-950/60 border border-emerald-800 hover:bg-emerald-900/60 text-emerald-300 font-semibold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Chat on WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Copyright & Studio Statement */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-mono-code">
          <div>
            © {new Date().getFullYear()} {BRAND_CONFIG.name}. All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            <span>Dubai, UAE & Global Delivery</span>
            <span>•</span>
            <span className="text-slate-400">Websites Built Like a System</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
