import React from 'react';
import { 
  Cpu, 
  Smartphone, 
  Target, 
  ShieldCheck, 
  Unlock, 
  Sparkles,
  Layers
} from 'lucide-react';
import { CORE_PILLARS } from '../data/portalData';

interface WhyAigainxProps {
  onOpenScopeBuilder?: () => void;
}

export const WhyAigainx: React.FC<WhyAigainxProps> = () => {
  const getPillarIcon = (iconName: string) => {
    switch (iconName) {
      case 'Cpu': return <Cpu className="w-6 h-6 text-blue-400" />;
      case 'Smartphone': return <Smartphone className="w-6 h-6 text-emerald-400" />;
      case 'Target': return <Target className="w-6 h-6 text-amber-400" />;
      case 'ShieldCheck': return <ShieldCheck className="w-6 h-6 text-teal-400" />;
      case 'Unlock': return <Unlock className="w-6 h-6 text-indigo-400" />;
      default: return <Cpu className="w-6 h-6 text-blue-400" />;
    }
  };

  return (
    <section 
      id="why-aigainx"
      className="py-24 bg-[#0c1017] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono-code font-semibold mb-3">
              <span>CORE ARCHITECTURAL PILLARS</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Why Modern UAE Businesses Choose AIGAINX.
            </h2>
            <p className="text-slate-300 text-base mt-2">
              We treat web design as a structured engineering discipline — eliminating the uncertainty, hidden costs, and delays of generic agencies.
            </p>
          </div>

          <div className="shrink-0">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-200 text-xs font-mono-code">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>100% Quality & Code Ownership</span>
            </div>
          </div>
        </div>

        {/* 5 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CORE_PILLARS.map((pillar, index) => {
            const isWide = index === 0 || index === 3;
            return (
              <div
                key={pillar.id}
                className={`p-6 sm:p-8 rounded-2xl bg-[#0e131d] border border-slate-800/90 shadow-lg hover:border-slate-700 transition-all flex flex-col justify-between ${
                  index === 0 ? 'lg:col-span-2' : ''
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                      {getPillarIcon(pillar.iconName)}
                    </div>
                    <span className="text-[11px] font-mono-code uppercase px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-slate-400 font-semibold">
                      {pillar.tag}
                    </span>
                  </div>

                  <h3 className="font-display text-xl font-bold text-white mb-1">
                    {pillar.title}
                  </h3>
                  <p className="text-xs text-blue-400 font-mono-code font-medium mb-3">
                    {pillar.subtitle}
                  </p>
                  <p className="text-sm text-slate-300 leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-800/60 flex items-center justify-between text-xs text-slate-400 font-mono-code">
                  <span>Pillar 0{index + 1}</span>
                  <span className="text-emerald-400">Guaranteed Standard</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
