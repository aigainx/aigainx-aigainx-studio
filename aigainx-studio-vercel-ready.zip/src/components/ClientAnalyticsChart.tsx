import React, { useState, useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts';
import { 
  TrendingUp, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  Layers, 
  PieChart as PieIcon, 
  BarChart3, 
  Activity,
  ShieldCheck
} from 'lucide-react';
import { ClientProject, InvoiceRecord } from '../types';
import { PROCESS_STEPS } from '../data/portalData';

interface ClientAnalyticsChartProps {
  projects: ClientProject[];
  invoices: InvoiceRecord[];
  onSelectProject?: (projectId: string) => void;
}

export const ClientAnalyticsChart: React.FC<ClientAnalyticsChartProps> = ({
  projects,
  invoices,
  onSelectProject
}) => {
  const [viewMode, setViewMode] = useState<'milestones' | 'spend_vs_budget' | 'phase_breakdown'>('milestones');
  const [selectedProjectId, setSelectedProjectId] = useState<string>('all');

  // Aggregated Financial Metrics
  const totalBudgetAed = useMemo(() => {
    return projects.reduce((acc, p) => acc + (p.amountAed || 0), 0);
  }, [projects]);

  const totalSettledAed = useMemo(() => {
    return invoices
      .filter((inv) => inv.status === 'paid')
      .reduce((acc, inv) => acc + (inv.totalAed || 0), 0);
  }, [invoices]);

  const totalPendingAed = useMemo(() => {
    return Math.max(0, totalBudgetAed - totalSettledAed);
  }, [totalBudgetAed, totalSettledAed]);

  const averageProgress = useMemo(() => {
    if (projects.length === 0) return 0;
    const sum = projects.reduce((acc, p) => acc + p.progressPercent, 0);
    return Math.round(sum / projects.length);
  }, [projects]);

  // Active or filtered projects list
  const activeProjects = useMemo(() => {
    if (selectedProjectId === 'all') return projects;
    return projects.filter((p) => p.id === selectedProjectId);
  }, [projects, selectedProjectId]);

  // Data for Spend vs Budget Chart
  const spendVsBudgetData = useMemo(() => {
    return projects.map((p) => {
      // Find invoices for this project / order
      const relatedInvoices = invoices.filter(
        (inv) => inv.orderId === p.orderId || inv.clientName === p.clientName
      );
      const paidAmount = relatedInvoices
        .filter((inv) => inv.status === 'paid')
        .reduce((sum, inv) => sum + inv.totalAed, 0);
      const pendingAmount = Math.max(0, p.amountAed - paidAmount);

      return {
        id: p.id,
        shortName: p.title.length > 18 ? p.title.substring(0, 16) + '...' : p.title,
        fullName: p.title,
        budget: p.amountAed,
        paid: paidAmount > 0 ? paidAmount : (p.paymentStatus === 'paid' ? p.amountAed : 0),
        pending: pendingAmount,
        progress: p.progressPercent,
        currentStep: p.currentStep,
        stepName: PROCESS_STEPS[p.currentStep - 1]?.title || 'Development'
      };
    });
  }, [projects, invoices]);

  // Data for Milestone Progress Trajectory Chart
  const milestoneProgressData = useMemo(() => {
    return projects.map((p) => {
      const stepTitle = PROCESS_STEPS[p.currentStep - 1]?.title || `Step ${p.currentStep}`;
      return {
        id: p.id,
        name: p.title.length > 20 ? p.title.substring(0, 18) + '..' : p.title,
        fullTitle: p.title,
        progress: p.progressPercent,
        currentStep: p.currentStep,
        totalSteps: 8,
        stepTitle: stepTitle,
        targetDaysRemaining: p.paymentStatus === 'paid' ? 'On Schedule' : 'Pending Verification'
      };
    });
  }, [projects]);

  // 8-Step Studio System Milestone Distribution Data
  const studioStepsTrajectoryData = useMemo(() => {
    return PROCESS_STEPS.map((step, idx) => {
      const stepNumber = step.number || (idx + 1);
      const matchingProjects = projects.filter((p) => p.currentStep >= stepNumber);
      const activeAtThisStep = projects.filter((p) => p.currentStep === stepNumber);
      
      return {
        step: `Step ${stepNumber}`,
        title: step.title,
        expectedProgress: stepNumber * 12.5,
        completedProjectsCount: matchingProjects.length,
        activeProjectsCount: activeAtThisStep.length,
        deliverable: step.deliverables?.[0] || 'Deliverable handover'
      };
    });
  }, [projects]);

  // Phase Investment Allocation Breakdown
  const phaseBreakdownData = useMemo(() => {
    const total = totalBudgetAed || 1;
    return [
      { name: '1. Strategy & IA Wireframes', value: Math.round(total * 0.20), percent: '20%', color: '#3b82f6' },
      { name: '2. High-Fidelity UI Design', value: Math.round(total * 0.25), percent: '25%', color: '#6366f1' },
      { name: '3. Full-Stack Engineering', value: Math.round(total * 0.35), percent: '35%', color: '#10b981' },
      { name: '4. Mobile & Core Web Vitals', value: Math.round(total * 0.10), percent: '10%', color: '#f59e0b' },
      { name: '5. QA, Security & Handover', value: Math.round(total * 0.10), percent: '10%', color: '#06b6d4' }
    ];
  }, [totalBudgetAed]);

  // Custom Chart Tooltips with dark theme and UAE Dirham formatting
  const CustomBudgetTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-950 border border-slate-700 p-3 rounded-xl shadow-xl font-mono-code text-xs space-y-1.5 z-50">
          <p className="font-bold text-white text-sm">{data.fullName}</p>
          <div className="text-slate-400 text-[11px] pb-1 border-b border-slate-800">
            Project ID: <span className="text-blue-400">{data.id}</span> · Current: <span className="text-emerald-400">{data.stepName}</span>
          </div>
          <div className="flex items-center justify-between gap-4 pt-1">
            <span className="text-slate-400">Total Contract Budget:</span>
            <span className="text-white font-bold">AED {data.budget?.toLocaleString()}</span>
          </div>
          <div className="flex items-center justify-between gap-4 text-emerald-400">
            <span>Settled / Paid:</span>
            <span className="font-bold">AED {data.paid?.toLocaleString()}</span>
          </div>
          {data.pending > 0 && (
            <div className="flex items-center justify-between gap-4 text-amber-400">
              <span>Pending Balance:</span>
              <span className="font-bold">AED {data.pending?.toLocaleString()}</span>
            </div>
          )}
          <div className="flex items-center justify-between gap-4 text-blue-300 pt-1 border-t border-slate-800 text-[11px]">
            <span>Milestone Progress:</span>
            <span className="font-bold">{data.progress}% Complete</span>
          </div>
        </div>
      );
    }
    return null;
  };

  const CustomMilestoneTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-950 border border-slate-700 p-3 rounded-xl shadow-xl font-mono-code text-xs space-y-1 z-50">
          <p className="font-bold text-white text-sm">{data.fullTitle || data.title}</p>
          <p className="text-blue-400 text-[11px]">
            Milestone: Step {data.currentStep || data.step} ({data.stepTitle || data.deliverable})
          </p>
          <div className="flex items-center justify-between gap-4 pt-1 text-emerald-400">
            <span>Progress Completed:</span>
            <span className="font-bold">{data.progress || data.expectedProgress}%</span>
          </div>
          {data.targetDaysRemaining && (
            <div className="text-slate-400 text-[10px] pt-1 border-t border-slate-800">
              Delivery Track: <span className="text-slate-200">{data.targetDaysRemaining}</span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4">
      {/* Top Stat Summary Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 font-mono-code">
        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Total Project Value</span>
            <span className="text-base font-bold text-white">AED {totalBudgetAed.toLocaleString()}</span>
          </div>
          <div className="w-8 h-8 rounded-lg bg-blue-950 border border-blue-800 text-blue-400 flex items-center justify-center">
            <DollarSign className="w-4 h-4" />
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Settled Spend (AED)</span>
            <span className="text-base font-bold text-emerald-400">AED {totalSettledAed.toLocaleString()}</span>
          </div>
          <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Avg. Progress Rate</span>
            <span className="text-base font-bold text-blue-400">{averageProgress}% Complete</span>
          </div>
          <div className="w-8 h-8 rounded-lg bg-blue-950 border border-blue-800 text-blue-400 flex items-center justify-center">
            <Activity className="w-4 h-4" />
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Active Pipeline</span>
            <span className="text-base font-bold text-slate-200">{projects.length} Projects</span>
          </div>
          <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 flex items-center justify-center">
            <Layers className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Interactive Chart Container */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-slate-900/95 to-[#0b0e14] border border-slate-800 space-y-4">
        
        {/* Controls Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-blue-400" />
            <h4 className="text-xs font-bold font-mono-code text-white uppercase tracking-wider">
              Project Performance & Spend Analytics
            </h4>
          </div>

          {/* Toggle Modes */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 font-mono-code text-[11px]">
            <button
              onClick={() => setViewMode('milestones')}
              className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'milestones'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <TrendingUp className="w-3 h-3" />
              <span>Milestones Trajectory</span>
            </button>

            <button
              onClick={() => setViewMode('spend_vs_budget')}
              className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'spend_vs_budget'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <DollarSign className="w-3 h-3" />
              <span>Spend vs Budget</span>
            </button>

            <button
              onClick={() => setViewMode('phase_breakdown')}
              className={`px-2.5 py-1 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'phase_breakdown'
                  ? 'bg-blue-600 text-white font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <PieIcon className="w-3 h-3" />
              <span>Phase Allocation</span>
            </button>
          </div>
        </div>

        {/* Dynamic Chart Display Area */}
        <div className="w-full">
          {/* VIEW 1: MILESTONES TRAJECTORY */}
          {viewMode === 'milestones' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-400 font-mono-code gap-2">
                <span>Visualizing project execution progress across our 8-step delivery system.</span>
                <span className="text-blue-400">Target: 100% Code & Asset Handover</span>
              </div>

              <div className="h-64 sm:h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={milestoneProgressData}
                    margin={{ top: 10, right: 20, left: -10, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis 
                      dataKey="name" 
                      stroke="#64748b" 
                      fontSize={11} 
                      tickLine={false}
                      interval={0}
                    />
                    <YAxis 
                      stroke="#64748b" 
                      fontSize={11} 
                      domain={[0, 100]} 
                      tickFormatter={(val) => `${val}%`}
                    />
                    <Tooltip content={<CustomMilestoneTooltip />} />
                    <Legend 
                      wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace', paddingTop: '8px' }}
                    />
                    <Bar 
                      name="Current Milestone Progress (%)" 
                      dataKey="progress" 
                      fill="#3b82f6" 
                      radius={[6, 6, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Step Flow Mini Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-[11px] font-mono-code">
                {projects.map((p) => (
                  <div key={p.id} className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1">
                    <div className="flex justify-between text-slate-300">
                      <span className="font-bold text-white truncate max-w-[120px]">{p.title}</span>
                      <span className="text-emerald-400">{p.progressPercent}%</span>
                    </div>
                    <p className="text-[10px] text-slate-400 truncate">
                      Step {p.currentStep}: {PROCESS_STEPS[p.currentStep - 1]?.title || 'Development'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW 2: SPEND VS BUDGET */}
          {viewMode === 'spend_vs_budget' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-400 font-mono-code gap-2">
                <span>Contracted scope value vs settled payments (in UAE Dirhams).</span>
                <span className="text-emerald-400">Zero hidden fees · 5% UAE VAT itemized</span>
              </div>

              <div className="h-64 sm:h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={spendVsBudgetData}
                    margin={{ top: 10, right: 20, left: 10, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                    <XAxis 
                      dataKey="shortName" 
                      stroke="#64748b" 
                      fontSize={11} 
                      tickLine={false}
                    />
                    <YAxis 
                      stroke="#64748b" 
                      fontSize={11} 
                      tickFormatter={(val) => `AED ${val / 1000}k`}
                    />
                    <Tooltip content={<CustomBudgetTooltip />} />
                    <Legend 
                      wrapperStyle={{ fontSize: '11px', fontFamily: 'monospace', paddingTop: '8px' }}
                    />
                    <Bar 
                      name="Total Budget Scope (AED)" 
                      dataKey="budget" 
                      fill="#3b82f6" 
                      radius={[4, 4, 0, 0]} 
                    />
                    <Bar 
                      name="Settled Invoices (AED)" 
                      dataKey="paid" 
                      fill="#10b981" 
                      radius={[4, 4, 0, 0]} 
                    />
                    <Bar 
                      name="Open Balance (AED)" 
                      dataKey="pending" 
                      fill="#f59e0b" 
                      radius={[4, 4, 0, 0]} 
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Financial Balance Summary Callout */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs font-mono-code">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-slate-300">
                    Gross Settled: <strong className="text-emerald-400">AED {totalSettledAed.toLocaleString()}</strong>
                  </span>
                </div>
                <div className="text-slate-400">
                  Committed Budget: <strong className="text-white">AED {totalBudgetAed.toLocaleString()}</strong>
                </div>
                {totalPendingAed > 0 && (
                  <div className="text-amber-400">
                    Pending Milestone Settlement: <strong>AED {totalPendingAed.toLocaleString()}</strong>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* VIEW 3: PHASE ALLOCATION BREAKDOWN */}
          {viewMode === 'phase_breakdown' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs text-slate-400 font-mono-code gap-2">
                <span>Standard architectural resource and engineering allocation per project tier.</span>
                <span className="text-blue-400">Engineering Weighted Distribution</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                {/* Donut Pie Chart */}
                <div className="h-60 sm:h-64 w-full flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={phaseBreakdownData}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={85}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {phaseBreakdownData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(val: number) => [`AED ${val.toLocaleString()}`, 'Allocated Investment']}
                        contentStyle={{ 
                          backgroundColor: '#020617', 
                          borderColor: '#334155', 
                          borderRadius: '0.75rem',
                          fontFamily: 'monospace',
                          fontSize: '11px',
                          color: '#fff'
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Phase List with percentages */}
                <div className="space-y-2 font-mono-code text-xs">
                  {phaseBreakdownData.map((item, idx) => (
                    <div 
                      key={idx}
                      className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <div 
                          className="w-3 h-3 rounded-full shrink-0" 
                          style={{ backgroundColor: item.color }} 
                        />
                        <span className="text-slate-200 font-medium text-xs">{item.name}</span>
                      </div>

                      <div className="text-right">
                        <span className="text-white font-bold">{item.percent}</span>
                        <span className="text-[10px] text-slate-500 block">AED {item.value.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
