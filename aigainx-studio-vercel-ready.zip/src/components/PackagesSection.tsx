import React from 'react';
import { 
  Check, 
  ArrowRight, 
  Sparkles, 
  Clock, 
  ShieldCheck, 
  CreditCard 
} from 'lucide-react';
import { PACKAGES } from '../data/portalData';
import { PACKAGE_PRICING_AED } from '../data/paymentData';

interface PackagesSectionProps {
  onRequestPackageQuote: (packageName: string) => void;
  onOpenCheckout?: (packageId: string) => void;
}

export const PackagesSection: React.FC<PackagesSectionProps> = ({ 
  onRequestPackageQuote,
  onOpenCheckout 
}) => {
  return (
    <section 
      id="packages"
      className="py-24 bg-[#0c1017] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono-code font-semibold mb-3">
            <span>STRUCTURED TIERS & TRANSPARENT PRICING</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Tailored Web Design Systems.
          </h2>
          <p className="text-slate-300 text-base mt-2">
            Every package follows the exact same 8-step delivery system with 100% client ownership and dedicated project leadership.
          </p>
        </div>

        {/* 3 Tier Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PACKAGES.map((pkg) => {
            const pricing = PACKAGE_PRICING_AED[pkg.id] || { baseAed: 4500 };

            return (
              <div
                key={pkg.id}
                className={`rounded-2xl p-6 sm:p-8 flex flex-col justify-between transition-all relative ${
                  pkg.popular
                    ? 'bg-[#0f1624] border-2 border-blue-500 shadow-2xl shadow-blue-900/30'
                    : 'bg-[#0e131d] border border-slate-800/90 shadow-lg hover:border-slate-700'
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-blue-600 border border-blue-400 text-white font-mono-code text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-md">
                    <Sparkles className="w-3 h-3" />
                    <span>{pkg.badge || 'Most Selected'}</span>
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-display text-2xl font-bold text-white">
                      {pkg.name}
                    </h3>
                  </div>

                  {/* Price Tag */}
                  <div className="mb-4 font-mono-code">
                    <span className="text-2xl font-display font-extrabold text-white">
                      AED {pricing.baseAed.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-400 font-normal"> + 5% UAE VAT</span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mb-4 min-h-[36px]">
                    {pkg.tagline}
                  </p>

                  <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800/80 mb-6 space-y-1">
                    <span className="text-[10px] font-mono-code uppercase text-slate-400 font-semibold block">
                      Ideal For:
                    </span>
                    <p className="text-xs text-slate-200">
                      {pkg.idealFor}
                    </p>
                    <div className="pt-2 flex items-center gap-1.5 text-xs text-blue-400 font-mono-code">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Sprint Timeline: {pkg.timeline}</span>
                    </div>
                  </div>

                  {/* Deliverables List */}
                  <div className="space-y-3 mb-6">
                    <span className="text-xs font-semibold text-slate-300 font-mono-code uppercase tracking-wider block">
                      Included in this System:
                    </span>
                    <ul className="space-y-2.5">
                      {pkg.deliverables.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                          <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Process Milestones */}
                  <div className="pt-4 border-t border-slate-800/80 space-y-2 mb-6">
                    <span className="text-[11px] font-mono-code uppercase text-slate-400 block">
                      Key Milestones:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {pkg.processHighlights.map((hl, i) => (
                        <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                          {hl}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Buttons Action Group */}
                <div className="pt-4 space-y-2">
                  {onOpenCheckout && (
                    <button
                      onClick={() => onOpenCheckout(pkg.id)}
                      className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-emerald-600/30 cursor-pointer"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Lock Package & Checkout</span>
                    </button>
                  )}

                  <button
                    onClick={() => onRequestPackageQuote(pkg.name)}
                    className={`w-full py-2 px-4 rounded-xl font-medium text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      pkg.popular
                        ? 'bg-blue-600 hover:bg-blue-500 text-white'
                        : 'bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white'
                    }`}
                  >
                    <span>Request Custom Scope Proposal</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <div className="flex items-center justify-center gap-1 text-[10px] text-slate-500 font-mono-code pt-1">
                    <ShieldCheck className="w-3 h-3 text-emerald-400" />
                    <span>Includes 100% Code & Asset Handover</span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
