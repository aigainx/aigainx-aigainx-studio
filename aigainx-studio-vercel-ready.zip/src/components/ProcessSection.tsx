import React, { useState } from 'react';
import { 
  Compass, 
  Network, 
  LayoutGrid, 
  Palette, 
  Code2, 
  CheckCircle2, 
  Rocket, 
  KeyRound, 
  ArrowRight, 
  Check, 
  Clock, 
  UserCheck, 
  FileText 
} from 'lucide-react';
import { PROCESS_STEPS } from '../data/portalData';

export const ProcessSection: React.FC = () => {
  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass': return <Compass className="w-5 h-5" />;
      case 'Network': return <Network className="w-5 h-5" />;
      case 'LayoutGrid': return <LayoutGrid className="w-5 h-5" />;
      case 'Palette': return <Palette className="w-5 h-5" />;
      case 'Code2': return <Code2 className="w-5 h-5" />;
      case 'CheckCircle2': return <CheckCircle2 className="w-5 h-5" />;
      case 'Rocket': return <Rocket className="w-5 h-5" />;
      case 'KeyRound': return <KeyRound className="w-5 h-5" />;
      default: return <Compass className="w-5 h-5" />;
    }
  };

  const currentStep = PROCESS_STEPS[activeStepIndex];

  return (
    <section 
      id="process"
      className="py-24 bg-[#090b10] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/60 border border-blue-800/60 text-blue-400 text-xs font-mono-code font-semibold mb-3">
            <span>THE 8-STEP DELIVERY SYSTEM</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            From Sitemap to Launch — Done Right.
          </h2>
          <p className="text-slate-300 text-base mt-2 leading-relaxed">
            Every project runs through a clear, repeatable process so clients get a professional, mobile-first, conversion-focused website with no guesswork.
          </p>
        </div>

        {/* Horizontal Step Selector (Desktop & Tablet) */}
        <div className="hidden md:grid md:grid-cols-8 gap-2 mb-8 bg-slate-900/80 p-2 rounded-2xl border border-slate-800">
          {PROCESS_STEPS.map((step, idx) => {
            const isActive = idx === activeStepIndex;
            return (
              <button
                key={step.number}
                onClick={() => setActiveStepIndex(idx)}
                className={`p-3 rounded-xl flex flex-col items-center text-center transition-all cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-1.5 ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-300'
                }`}>
                  {getStepIcon(step.iconName)}
                </div>
                <span className="font-mono-code text-[10px] uppercase tracking-wider font-semibold">
                  Step 0{step.number}
                </span>
                <span className="text-[11px] font-medium truncate w-full mt-0.5">
                  {step.title.split(' ')[0]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Mobile Step Switcher */}
        <div className="flex md:hidden overflow-x-auto gap-2 pb-3 mb-6 no-scrollbar">
          {PROCESS_STEPS.map((step, idx) => (
            <button
              key={step.number}
              onClick={() => setActiveStepIndex(idx)}
              className={`shrink-0 px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 border ${
                idx === activeStepIndex
                  ? 'bg-blue-600 border-blue-500 text-white'
                  : 'bg-slate-900 border-slate-800 text-slate-300'
              }`}
            >
              <span>0{step.number}. {step.title.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Active Step Detailed Card */}
        <div className="rounded-2xl bg-[#0d1117] border border-slate-800/90 shadow-xl overflow-hidden">
          
          {/* Card Top Banner */}
          <div className="bg-slate-900/90 px-6 py-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 text-blue-400 flex items-center justify-center">
                {getStepIcon(currentStep.iconName)}
              </div>
              <div>
                <span className="font-mono-code text-xs text-blue-400 font-semibold uppercase tracking-wider">
                  Step 0{currentStep.number} of 08
                </span>
                <h3 className="font-display text-xl font-bold text-white">
                  {currentStep.title}
                </h3>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono-code">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>Duration: {currentStep.duration}</span>
              </div>
            </div>
          </div>

          {/* Card Body */}
          <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left: Description & Client Role */}
            <div className="lg:col-span-7 space-y-6">
              <div>
                <h4 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-2 font-mono-code">
                  Phase Overview
                </h4>
                <p className="text-base text-slate-200 leading-relaxed">
                  {currentStep.description}
                </p>
              </div>

              {/* Client Role Box */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex items-start gap-3">
                <UserCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-xs font-semibold text-emerald-300 font-mono-code uppercase">
                    Your Role in Step 0{currentStep.number}
                  </span>
                  <p className="text-xs text-slate-300 mt-0.5">
                    {currentStep.clientRole}
                  </p>
                </div>
              </div>
            </div>

            {/* Right: Concrete Deliverables Checklist */}
            <div className="lg:col-span-5 bg-slate-900/40 p-5 rounded-xl border border-slate-800/80 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300 font-mono-code uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-blue-400" />
                  <span>Concrete Deliverables</span>
                </span>
                <span className="text-[10px] text-emerald-400 font-mono-code">
                  100% Tangible
                </span>
              </div>

              <ul className="space-y-2.5">
                {currentStep.deliverables.map((del, i) => (
                  <li 
                    key={i}
                    className="flex items-start gap-2.5 text-xs text-slate-200 p-2 rounded-lg bg-slate-950/60 border border-slate-800/60"
                  >
                    <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{del}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

          {/* Card Footer Navigation Controls */}
          <div className="bg-slate-900/60 px-6 py-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <button
              onClick={() => setActiveStepIndex(prev => (prev > 0 ? prev - 1 : PROCESS_STEPS.length - 1))}
              className="text-slate-400 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <span>← Previous Step</span>
            </button>

            <span className="text-slate-500 font-mono-code">
              {activeStepIndex + 1} / {PROCESS_STEPS.length}
            </span>

            <button
              onClick={() => setActiveStepIndex(prev => (prev < PROCESS_STEPS.length - 1 ? prev + 1 : 0))}
              className="text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-blue-950/40 transition-colors cursor-pointer"
            >
              <span>Next Step →</span>
            </button>
          </div>

        </div>

      </div>
    </section>
  );
};
