import React, { useState } from 'react';
import { 
  Star, 
  Quote, 
  TrendingUp, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  Sparkles, 
  ArrowRight,
  Layers,
  Award,
  Building2
} from 'lucide-react';
import { TESTIMONIALS_DATA, CLIENT_SUCCESS_STATS, BRAND_CONFIG } from '../data/portalData';
import { TestimonialItem } from '../types';

interface ClientSuccessSectionProps {
  onSelectProjectScope?: (projectType: string) => void;
  onOpenScopeBuilder?: () => void;
}

export const ClientSuccessSection: React.FC<ClientSuccessSectionProps> = ({
  onSelectProjectScope,
  onOpenScopeBuilder
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = [
    'All',
    'Corporate & Finance',
    'Real Estate & Luxury',
    'SaaS & Technology',
    'Hospitality & Dining',
    'Luxury Retail & E-Commerce',
    'Logistics & Infrastructure'
  ];

  const filteredTestimonials = activeCategory === 'All'
    ? TESTIMONIALS_DATA
    : TESTIMONIALS_DATA.filter((item) => item.industry === activeCategory);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();
  };

  return (
    <section 
      id="testimonials" 
      className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-800/80 relative"
    >
      {/* Background Subtle Accent Glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Section Header */}
      <div className="space-y-4 max-w-3xl mb-12">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono-code font-semibold">
          <Award className="w-3.5 h-3.5 text-blue-400" />
          <span>CLIENT SUCCESS & TESTIMONIALS</span>
        </div>

        <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
          Engineered for Results. <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-blue-400 to-indigo-300 bg-clip-text text-transparent">
            Validated by Modern Businesses.
          </span>
        </h2>

        <p className="text-base sm:text-lg text-slate-300 font-normal leading-relaxed">
          Real feedback from founders, managing directors, and growth leads across Dubai and the GCC who switched from improvised templates to AIGAINX's structured 8-step engineering system.
        </p>
      </div>

      {/* Social Proof Stats Matrix */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
        {CLIENT_SUCCESS_STATS.map((stat, idx) => (
          <div 
            key={idx}
            className="p-5 rounded-2xl bg-gradient-to-b from-slate-900/90 to-[#0c1017] border border-slate-800/90 shadow-lg relative overflow-hidden group hover:border-slate-700 transition-colors"
          >
            <div className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
              <span className="text-blue-400">{stat.metric}</span>
            </div>
            <div className="text-xs sm:text-sm font-semibold text-slate-200 mt-1">
              {stat.label}
            </div>
            <div className="text-[11px] text-slate-400 font-mono-code mt-1 leading-snug">
              {stat.detail}
            </div>
          </div>
        ))}
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 no-scrollbar">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setActiveCategory(category)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-mono-code whitespace-nowrap transition-all cursor-pointer ${
              activeCategory === category
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/20 border border-blue-500'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800/80 border border-slate-800'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Testimonials Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTestimonials.map((item) => (
          <div
            key={item.id}
            className="rounded-2xl bg-gradient-to-b from-[#0e131d] to-[#0a0d14] border border-slate-800 p-6 flex flex-col justify-between hover:border-blue-500/40 hover:shadow-xl hover:shadow-blue-950/20 transition-all duration-300 relative group"
          >
            {/* Top Bar: Industry & Stars */}
            <div>
              <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-800/80">
                <span className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] font-mono-code text-blue-300 font-medium">
                  {item.industry}
                </span>

                <div className="flex items-center gap-1">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star 
                      key={i} 
                      className="w-3.5 h-3.5 fill-amber-400 text-amber-400" 
                    />
                  ))}
                </div>
              </div>

              {/* Project Type & Delivery Timeframe */}
              <div className="mt-4 flex items-center justify-between text-[11px] font-mono-code text-slate-400">
                <span className="text-slate-300 font-semibold truncate pr-2">
                  {item.projectType}
                </span>
                <span className="flex items-center gap-1 shrink-0 text-emerald-400">
                  <Clock className="w-3 h-3" />
                  {item.deliveryTimeframe}
                </span>
              </div>

              {/* Quote Block */}
              <div className="my-5 relative">
                <Quote className="w-7 h-7 text-slate-800 absolute -top-3 -left-1 pointer-events-none opacity-40" />
                <p className="text-sm text-slate-200 leading-relaxed italic relative z-10">
                  "{item.quote}"
                </p>
              </div>

              {/* Key Outcome Highlight Box */}
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/90 flex items-center justify-between gap-3 mb-5">
                <div>
                  <div className="text-[10px] uppercase tracking-wider font-mono-code text-slate-400">
                    Primary Impact
                  </div>
                  <div className="text-xs font-semibold text-slate-200 mt-0.5">
                    {item.keyOutcome.label}
                  </div>
                </div>
                <div className="text-base font-display font-extrabold text-emerald-400 font-mono-code bg-emerald-950/50 px-2.5 py-1 rounded border border-emerald-800/50 shrink-0">
                  {item.keyOutcome.metric}
                </div>
              </div>
            </div>

            {/* Bottom Client Meta & Tags */}
            <div className="pt-4 border-t border-slate-800/80 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-900 to-slate-900 border border-blue-500/30 flex items-center justify-center text-xs font-bold font-mono-code text-blue-300 shadow-inner shrink-0">
                  {getInitials(item.clientName)}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-bold text-white truncate">
                    {item.clientName}
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">
                    {item.role} · <span className="text-slate-300">{item.company}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono-code flex items-center gap-1 mt-0.5">
                    <MapPin className="w-2.5 h-2.5 text-blue-400 shrink-0" />
                    <span className="truncate">{item.location}</span>
                  </div>
                </div>
              </div>

              {/* Architectural Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {item.tags.map((tag, tIdx) => (
                  <span 
                    key={tIdx} 
                    className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-slate-900/90 border border-slate-800 text-slate-400"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Action Link */}
              {onSelectProjectScope && (
                <button
                  onClick={() => onSelectProjectScope(item.projectType)}
                  className="w-full mt-2 py-2 px-3 rounded-lg bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-mono-code flex items-center justify-center gap-1.5 transition-colors border border-slate-800/80 cursor-pointer"
                >
                  <span>Inquire for {item.industry.split('&')[0].trim()}</span>
                  <ArrowRight className="w-3 h-3 text-blue-400" />
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Conversion Prompt Banner */}
      <div className="mt-12 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0d131f] via-[#0e1626] to-[#0d131f] border border-blue-900/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="inline-flex items-center gap-2 text-xs font-mono-code text-blue-400 font-semibold">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>100% CODE HANDOVER · ZERO LOCK-IN</span>
          </div>
          <h3 className="font-display text-xl sm:text-2xl font-bold text-white tracking-tight">
            Ready for a website that functions as a predictable growth asset?
          </h3>
          <p className="text-xs sm:text-sm text-slate-300">
            Configure your technical scope in our interactive builder or start with a 45-minute architectural kickoff.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          {onOpenScopeBuilder && (
            <button
              onClick={onOpenScopeBuilder}
              className="py-2.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
            >
              <Layers className="w-4 h-4" />
              <span>Launch Scope Builder</span>
            </button>
          )}
          <a
            href={`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('Hello AIGAINX Portal, I would like to discuss a project scope for my business.')}`}
            target="_blank"
            rel="noreferrer"
            className="py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-2 transition-colors"
          >
            <span>WhatsApp Dispatch</span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
          </a>
        </div>
      </div>
    </section>
  );
};
