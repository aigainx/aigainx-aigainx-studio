import React, { useState } from 'react';
import { 
  Compass, 
  Network, 
  LayoutGrid, 
  Palette, 
  Code2, 
  CheckCircle2, 
  Rocket, 
  KeyRound, 
  ChevronDown, 
  ChevronUp, 
  Clock, 
  Sparkles, 
  FileCheck, 
  ExternalLink,
  ShieldCheck,
  Layers,
  ArrowRight,
  UserCheck
} from 'lucide-react';
import { ClientProject } from '../types';
import { PROCESS_STEPS, BRAND_CONFIG } from '../data/portalData';

interface ProjectProgressTrackerProps {
  project: ClientProject;
  defaultExpanded?: boolean;
}

export const ProjectProgressTracker: React.FC<ProjectProgressTrackerProps> = ({
  project,
  defaultExpanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [selectedStepNumber, setSelectedStepNumber] = useState<number>(project.currentStep);

  const getStepIcon = (iconName: string, className = "w-4 h-4") => {
    switch (iconName) {
      case 'Compass': return <Compass className={className} />;
      case 'Network': return <Network className={className} />;
      case 'LayoutGrid': return <LayoutGrid className={className} />;
      case 'Palette': return <Palette className={className} />;
      case 'Code2': return <Code2 className={className} />;
      case 'CheckCircle2': return <CheckCircle2 className={className} />;
      case 'Rocket': return <Rocket className={className} />;
      case 'KeyRound': return <KeyRound className={className} />;
      default: return <Compass className={className} />;
    }
  };

  const activeStepData = PROCESS_STEPS.find(s => s.number === selectedStepNumber) || PROCESS_STEPS[project.currentStep - 1] || PROCESS_STEPS[0];
  const isCurrentActiveStep = project.currentStep === selectedStepNumber;
  const isPastStep = selectedStepNumber < project.currentStep;
  const isFutureStep = selectedStepNumber > project.currentStep;

  // Status mapping for nice human-readable label
  const getStatusLabel = (status: ClientProject['status']) => {
    switch (status) {
      case 'discovery': return 'Discovery & Strategy';
      case 'sitemap_wireframing': return 'Sitemap & Wireframing';
      case 'ui_design': return 'UI/UX Visual Design';
      case 'development': return 'Front-End Development';
      case 'qa_testing': return 'QA & Performance Testing';
      case 'launch_prep': return 'Launch Preparation & DNS';
      case 'delivered': return '100% Handover Complete';
      default: return 'Active Engineering';
    }
  };

  return (
    <div className="rounded-xl bg-slate-950/70 border border-slate-800/90 overflow-hidden text-xs font-mono-code transition-all duration-200">
      
      {/* Header Bar with Live Step Summary */}
      <div className="p-3.5 bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-slate-950 border-b border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-950 border border-blue-800/80 text-blue-300 text-[11px] font-bold">
            <Layers className="w-3.5 h-3.5 text-blue-400" />
            <span>8-Step Delivery System</span>
          </div>

          <span className="text-slate-400">
            Phase: <strong className="text-white font-semibold">Step {project.currentStep} of 8 ({getStatusLabel(project.status)})</strong>
          </span>
        </div>

        <div className="flex items-center gap-3 self-end sm:self-auto">
          <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{project.progressPercent}% Velocity</span>
          </div>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/80 transition-colors cursor-pointer text-[11px]"
            aria-label={isExpanded ? "Collapse 8-step breakdown" : "Expand 8-step breakdown"}
          >
            <span>{isExpanded ? 'Hide Steps' : 'View 8 Steps'}</span>
            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Main Visual Stepper Pipeline Track */}
      <div className="p-3.5 sm:p-4 space-y-4">
        
        {/* Continuous 8-Step Nodes */}
        <div className="relative">
          {/* Background Connecting Rail */}
          <div className="absolute top-4 left-4 right-4 h-1 bg-slate-800 rounded-full hidden sm:block -z-0" />
          
          {/* Active Fill Rail */}
          <div 
            className="absolute top-4 left-4 h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 rounded-full hidden sm:block transition-all duration-500 -z-0"
            style={{ 
              width: `calc(${Math.min(100, Math.max(0, ((project.currentStep - 1) / 7) * 100))}% * 0.92)` 
            }}
          />

          {/* 8 Step Nodes Grid */}
          <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 relative z-10">
            {PROCESS_STEPS.map((step) => {
              const isDone = step.number < project.currentStep || project.progressPercent === 100;
              const isCurrent = step.number === project.currentStep && project.progressPercent < 100;
              const isPending = step.number > project.currentStep && project.progressPercent < 100;
              const isSelected = step.number === selectedStepNumber;

              return (
                <button
                  key={step.number}
                  onClick={() => {
                    setSelectedStepNumber(step.number);
                    if (!isExpanded) setIsExpanded(true);
                  }}
                  className={`group relative flex flex-col items-center text-center p-2 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-900/40 border-blue-400 shadow-md shadow-blue-950/40'
                      : isDone
                      ? 'bg-emerald-950/30 hover:bg-emerald-950/50 border-emerald-800/60 text-emerald-300'
                      : isCurrent
                      ? 'bg-blue-950/60 hover:bg-blue-950/80 border-blue-500 text-blue-200 ring-2 ring-blue-500/20'
                      : 'bg-slate-900/40 hover:bg-slate-900/70 border-slate-800/80 text-slate-400'
                  }`}
                >
                  {/* Step Bubble Icon */}
                  <div 
                    className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center font-bold text-xs transition-all ${
                      isDone
                        ? 'bg-emerald-500 text-slate-950 shadow-sm shadow-emerald-500/30'
                        : isCurrent
                        ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/40 ring-2 ring-blue-400/40 animate-pulse'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                    ) : (
                      <span>{step.number}</span>
                    )}
                  </div>

                  {/* Step Short Label */}
                  <div className="mt-1.5 w-full">
                    <span className={`text-[10px] font-semibold block truncate ${
                      isSelected ? 'text-blue-300 font-bold' : isDone ? 'text-emerald-400' : isCurrent ? 'text-white font-bold' : 'text-slate-400'
                    }`}>
                      {step.title.split(' ')[0]}
                    </span>
                    
                    <span className={`text-[9px] uppercase tracking-wider block font-mono-code ${
                      isDone ? 'text-emerald-400/80' : isCurrent ? 'text-blue-400' : 'text-slate-400'
                    }`}>
                      {isDone ? 'Done' : isCurrent ? 'Active' : 'Queued'}
                    </span>
                  </div>

                  {/* Active Indicator Glow Indicator */}
                  {isCurrent && (
                    <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-blue-500" />
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Detailed Step Inspector Drawer */}
        {isExpanded && activeStepData && (
          <div className="mt-3 p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3.5 animate-in fade-in duration-150">
            
            {/* Step Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-lg ${
                  isPastStep
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    : isCurrentActiveStep
                    ? 'bg-blue-950 text-blue-400 border border-blue-800'
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}>
                  {getStepIcon(activeStepData.iconName, "w-4 h-4")}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-display text-sm font-bold text-white">
                      Step {activeStepData.number}: {activeStepData.title}
                    </h4>
                    <span className={`text-[10px] px-2 py-0.2 rounded-full font-semibold ${
                      isPastStep
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                        : isCurrentActiveStep
                        ? 'bg-blue-950 text-blue-300 border border-blue-800'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}>
                      {isPastStep ? '✓ Completed & Approved' : isCurrentActiveStep ? '⚡ In Active Engineering' : '⌛ Scheduled Phase'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    {activeStepData.subtitle}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-400 self-start sm:self-auto">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                <span>Estimated Duration: <strong className="text-slate-200">{activeStepData.duration}</strong></span>
              </div>
            </div>

            {/* Description */}
            <p className="text-xs text-slate-300 leading-relaxed">
              {activeStepData.description}
            </p>

            {/* Deliverables Checklist Grid */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] uppercase text-slate-400 tracking-wider block font-bold">
                Phase Deliverables & Scope Checklist:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {activeStepData.deliverables.map((item, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2 p-2 rounded-lg bg-slate-950/80 border border-slate-800/80 text-[11px] text-slate-300"
                  >
                    <FileCheck className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                      isPastStep ? 'text-emerald-400' : isCurrentActiveStep ? 'text-blue-400' : 'text-slate-400'
                    }`} />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Client Action Requirement & Dubai Desk Dispatch */}
            <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-950/60 p-3 rounded-lg border border-slate-800/60">
              <div className="flex items-center gap-2 text-[11px] text-slate-300">
                <UserCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong className="text-white">Client Collaboration:</strong> {activeStepData.clientRole}
                </span>
              </div>

              <a
                href={`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello AIGAINX Studio, I am inquiring about Step ${activeStepData.number} (${activeStepData.title}) for Project ${project.id} (Order: ${project.orderId}).`)}`}
                target="_blank"
                rel="noreferrer"
                className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-600 text-white font-semibold text-[11px] transition-colors cursor-pointer shadow-sm"
              >
                <span>Consult Studio Lead</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

          </div>
        )}

      </div>

    </div>
  );
};
