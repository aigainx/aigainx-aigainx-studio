import React, { useState } from 'react';
import { 
  X, 
  Check, 
  ShieldCheck, 
  CreditCard, 
  Building2, 
  QrCode, 
  ArrowRight, 
  ArrowLeft, 
  Layers, 
  Clock, 
  UploadCloud, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Sparkles, 
  Lock,
  Smartphone,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { 
  PaymentMethodId, 
  PaymentRecord, 
  QuoteRecord, 
  InvoiceRecord, 
  ClientProject 
} from '../types';
import { 
  PAYMENT_OPTIONS_CATALOG, 
  UAE_BANK_DETAILS, 
  PACKAGE_PRICING_AED,
  savePaymentRecord,
  saveQuoteRecord,
  saveInvoiceRecord,
  saveProjectRecord
} from '../data/paymentData';
import { BRAND_CONFIG, SERVICES, PACKAGES } from '../data/portalData';

interface CheckoutModalProps {
  initialPackageId?: string;
  initialCustomScope?: string;
  onClose: () => void;
  onPaymentSuccess: (invoice: InvoiceRecord, payment: PaymentRecord) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  initialPackageId = 'business',
  initialCustomScope,
  onClose,
  onPaymentSuccess
}) => {
  // Step tracker: 1: Select Service & Package -> 2: Project Details -> 3: Quote Review -> 4: Payment -> 5: Complete
  const [currentStep, setCurrentStep] = useState<number>(1);
  
  // Step 1: Package & Service
  const [selectedServiceId, setSelectedServiceId] = useState<string>(SERVICES[0].id);
  const [selectedPackageId, setSelectedPackageId] = useState<string>(initialPackageId || 'business');
  
  // Step 2: Client Info
  const [clientName, setClientName] = useState<string>('');
  const [companyName, setCompanyName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [projectBrief, setProjectBrief] = useState<string>(initialCustomScope || '');

  // Step 4: Payment selection
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodId>('apple_pay');
  const [cardNumber, setCardNumber] = useState<string>('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState<string>('12/28');
  const [cardCvc, setCardCvc] = useState<string>('888');
  
  // Bank Slip Upload State
  const [uploadedSlipFile, setUploadedSlipFile] = useState<File | null>(null);
  const [uploadedSlipName, setUploadedSlipName] = useState<string>('');
  const [bankSenderName, setBankSenderName] = useState<string>('');

  // Processing & Feedback State
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStatusText, setProcessingStatusText] = useState<string>('');
  const [createdInvoice, setCreatedInvoice] = useState<InvoiceRecord | null>(null);
  const [createdPayment, setCreatedPayment] = useState<PaymentRecord | null>(null);

  // Price Calculation
  const currentPackageData = PACKAGE_PRICING_AED[selectedPackageId] || PACKAGE_PRICING_AED.business;
  const subtotalAed = currentPackageData.baseAed;
  const vatRate = 0.05;
  const vatAed = Math.round(subtotalAed * vatRate);
  const totalAed = subtotalAed + vatAed;

  const currentPackageInfo = PACKAGES.find((p) => p.id === selectedPackageId) || PACKAGES[1];
  const currentServiceInfo = SERVICES.find((s) => s.id === selectedServiceId) || SERVICES[0];

  // Random Generated Reference for session
  const [orderSessionId] = useState<string>(() => `ORD-${Math.floor(1000 + Math.random() * 9000)}`);
  const uniqueBankReference = `AIGX-REF-${orderSessionId}`;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedSlipFile(file);
      setUploadedSlipName(file.name);
    }
  };

  const handleExecutePayment = () => {
    setIsProcessing(true);

    const isBankTransfer = selectedMethod === 'bank_transfer';
    const initialStatus = isBankTransfer ? 'manual_verification' : 'paid';

    if (isBankTransfer) {
      setProcessingStatusText('Validating bank wire reference & uploading slip...');
    } else if (selectedMethod === 'apple_pay') {
      setProcessingStatusText('Requesting Apple Pay token from payment processor gateway...');
    } else if (selectedMethod === 'ziina') {
      setProcessingStatusText('Connecting to Ziina UAE Gateway session...');
    } else {
      setProcessingStatusText('Connecting to Stripe 3D Secure 2.0 gateway...');
    }

    setTimeout(() => {
      const now = new Date();
      const invoiceNo = `AIGX-INV-2026-${Math.floor(100 + Math.random() * 900)}`;
      const quoteNo = `AIGX-QUO-${Math.floor(200 + Math.random() * 800)}`;
      const paymentId = `PAY-${selectedMethod.slice(0, 2).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

      // 1. Create & Save Quote
      const newQuote: QuoteRecord = {
        id: quoteNo,
        quoteNumber: quoteNo,
        clientName: clientName || 'Commercial Client',
        companyName: companyName || 'Valued Business',
        email: email || 'client@business.ae',
        phone: phone || '+971 50 000 0000',
        projectType: currentServiceInfo.title,
        packageName: currentPackageInfo.name,
        deliverables: currentPackageInfo.deliverables,
        items: [
          {
            description: `${currentPackageInfo.name} Web Architecture (${currentServiceInfo.title})`,
            qty: 1,
            unitPriceAed: subtotalAed,
            totalAed: subtotalAed
          }
        ],
        subtotalAed,
        vatRate: 0.05,
        vatAed,
        totalAed,
        status: isBankTransfer ? 'accepted' : 'paid',
        validUntil: new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        createdAt: now.toISOString().split('T')[0],
        paymentTerms: isBankTransfer ? 'Direct UAE Bank Wire with Slip Verification' : 'Instant Gateway Milestone Lock',
        timelineEstimate: currentPackageInfo.timeline
      };
      saveQuoteRecord(newQuote);

      // 2. Create & Save Invoice
      const newInvoice: InvoiceRecord = {
        id: invoiceNo,
        invoiceNumber: invoiceNo,
        orderId: orderSessionId,
        quoteNumber: quoteNo,
        paymentId: paymentId,
        clientName: clientName || 'Commercial Client',
        companyName: companyName || 'Valued Business',
        clientEmail: email || 'client@business.ae',
        clientAddress: 'Dubai, United Arab Emirates',
        issueDate: now.toISOString().split('T')[0],
        dueDate: now.toISOString().split('T')[0],
        paidDate: isBankTransfer ? undefined : now.toISOString().split('T')[0],
        items: [
          {
            description: `${currentPackageInfo.name} (${currentServiceInfo.title}) - 8-Step System`,
            qty: 1,
            rateAed: subtotalAed,
            amountAed: subtotalAed
          }
        ],
        subtotalAed,
        vatAed,
        totalAed,
        status: isBankTransfer ? 'under_review' : 'paid',
        paymentMethod: selectedMethod,
        paymentReference: isBankTransfer ? uniqueBankReference : `gw_auth_${Math.random().toString(36).substring(2, 10)}`
      };
      saveInvoiceRecord(newInvoice);

      // 3. Create & Save Payment Record
      const providerMapping = {
        apple_pay: 'Apple Pay via Stripe' as const,
        credit_card: 'Stripe' as const,
        debit_card: 'Stripe' as const,
        stripe: 'Stripe' as const,
        ziina: 'Ziina' as const,
        bank_transfer: 'Direct UAE Bank' as const
      };

      const newPayment: PaymentRecord = {
        id: paymentId,
        orderId: orderSessionId,
        invoiceNumber: invoiceNo,
        quoteId: quoteNo,
        clientName: clientName || 'Commercial Client',
        clientEmail: email || 'client@business.ae',
        clientPhone: phone || '+971 50 000 0000',
        companyName: companyName || 'Valued Business',
        projectName: `${companyName || 'Enterprise'} Digital Platform`,
        packageId: selectedPackageId,
        packageName: currentPackageInfo.name,
        subtotalAed,
        vatAed,
        amountAed: totalAed,
        currency: 'AED',
        method: selectedMethod,
        provider: providerMapping[selectedMethod],
        status: initialStatus,
        referenceId: isBankTransfer ? uniqueBankReference : `tok_${Math.random().toString(36).substring(2, 12)}`,
        paymentProofName: isBankTransfer ? (uploadedSlipName || 'UAE_Bank_Transfer_Receipt.pdf') : undefined,
        paidAt: isBankTransfer ? undefined : now.toISOString(),
        createdAt: now.toISOString(),
        verificationNotes: isBankTransfer 
          ? `Wire transfer slip uploaded (${uploadedSlipName || 'Official PDF'}). Pending Admin review at Emitac Building Dubai.`
          : '3D-Secure verified via merchant gateway.'
      };
      savePaymentRecord(newPayment);

      // 4. Create Project in Client Area
      const newProject: ClientProject = {
        id: `PRJ-2026-${Math.floor(100 + Math.random() * 900)}`,
        title: `${companyName || 'Enterprise'} Digital Platform`,
        clientName: clientName || 'Commercial Client',
        companyName: companyName || 'Valued Business',
        clientEmail: email || 'client@business.ae',
        packageName: currentPackageInfo.name,
        orderId: orderSessionId,
        status: isBankTransfer ? 'discovery' : 'discovery',
        currentStep: 1,
        totalSteps: 8,
        progressPercent: 12.5,
        kickoffDate: now.toISOString().split('T')[0],
        targetDeliveryDate: new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        repositoryAccessGranted: false,
        assignedLead: 'Senior Project Lead (Dubai Studio)',
        amountAed: totalAed,
        paymentStatus: initialStatus
      };
      saveProjectRecord(newProject);

      setCreatedInvoice(newInvoice);
      setCreatedPayment(newPayment);
      setIsProcessing(false);
      setCurrentStep(5); // Show confirmation
      onPaymentSuccess(newInvoice, newPayment);
    }, 1600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl my-6 bg-[#0c1018] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-200 flex flex-col max-h-[90vh]">
        
        {/* Top Header & Progress Stepper */}
        <div className="p-5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display text-sm font-bold text-white tracking-wide">
                  AIGAINX SECURE CHECKOUT
                </span>
                <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-blue-950/80 border border-blue-800 text-blue-300">
                  Emitac Building, Dubai
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono-code">
                Order ID: <span className="text-blue-400">{orderSessionId}</span> · Currency: AED
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Flow Breadcrumb */}
        <div className="px-6 py-2.5 bg-[#090d14] border-b border-slate-800/80 flex items-center justify-between text-xs font-mono-code overflow-x-auto no-scrollbar shrink-0">
          <div className="flex items-center gap-4 min-w-max">
            <span className={`flex items-center gap-1.5 ${currentStep === 1 ? 'text-blue-400 font-bold' : currentStep > 1 ? 'text-emerald-400' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">1</span>
              <span>Select Service</span>
            </span>
            <span className="text-slate-700">→</span>

            <span className={`flex items-center gap-1.5 ${currentStep === 2 ? 'text-blue-400 font-bold' : currentStep > 2 ? 'text-emerald-400' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">2</span>
              <span>Project Details</span>
            </span>
            <span className="text-slate-700">→</span>

            <span className={`flex items-center gap-1.5 ${currentStep === 3 ? 'text-blue-400 font-bold' : currentStep > 3 ? 'text-emerald-400' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">3</span>
              <span>Quote Review</span>
            </span>
            <span className="text-slate-700">→</span>

            <span className={`flex items-center gap-1.5 ${currentStep === 4 ? 'text-blue-400 font-bold' : currentStep > 4 ? 'text-emerald-400' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">4</span>
              <span>Payment</span>
            </span>
            <span className="text-slate-700">→</span>

            <span className={`flex items-center gap-1.5 ${currentStep === 5 ? 'text-emerald-400 font-bold' : 'text-slate-500'}`}>
              <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-[10px]">5</span>
              <span>Confirmation</span>
            </span>
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* STEP 1: Select Service & Package */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-lg font-bold text-white">
                  Step 1: Select Architectural Service & Package Tier
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Choose the structural foundation for your project. All tiers follow our 8-step delivery model.
                </p>
              </div>

              {/* Service Category */}
              <div className="space-y-2">
                <label className="text-xs font-mono-code text-slate-300 font-semibold block">
                  Service Specialization:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {SERVICES.map((srv) => (
                    <button
                      key={srv.id}
                      type="button"
                      onClick={() => setSelectedServiceId(srv.id)}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        selectedServiceId === srv.id
                          ? 'bg-blue-950/40 border-blue-500 text-white shadow-md shadow-blue-950/50'
                          : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="text-xs font-bold text-white">{srv.title}</div>
                      <div className="text-[11px] text-slate-400 mt-1 leading-snug">{srv.category}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Package Tier Options */}
              <div className="space-y-3">
                <label className="text-xs font-mono-code text-slate-300 font-semibold block">
                  System Package Tier:
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {PACKAGES.map((pkg) => {
                    const priceInfo = PACKAGE_PRICING_AED[pkg.id] || { baseAed: 4500 };
                    const isSelected = selectedPackageId === pkg.id;

                    return (
                      <div
                        key={pkg.id}
                        onClick={() => setSelectedPackageId(pkg.id)}
                        className={`p-4 rounded-xl border flex flex-col justify-between transition-all cursor-pointer relative ${
                          isSelected
                            ? 'bg-gradient-to-b from-blue-950/60 to-[#0e131d] border-blue-500 shadow-lg shadow-blue-950/40'
                            : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {pkg.badge && (
                          <span className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-blue-600 text-white font-mono-code text-[10px] font-bold">
                            {pkg.badge}
                          </span>
                        )}

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <h4 className="font-bold text-white text-sm">{pkg.name}</h4>
                            <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${isSelected ? 'border-blue-400 bg-blue-500 text-white' : 'border-slate-600'}`}>
                              {isSelected && <Check className="w-3 h-3" />}
                            </div>
                          </div>

                          <div className="text-lg font-display font-extrabold text-white font-mono-code">
                            AED {priceInfo.baseAed.toLocaleString()}
                            <span className="text-[10px] text-slate-400 font-normal"> + 5% VAT</span>
                          </div>

                          <p className="text-[11px] text-slate-300 leading-snug line-clamp-2">
                            {pkg.tagline}
                          </p>

                          <div className="text-[10px] text-emerald-400 font-mono-code flex items-center gap-1 pt-1">
                            <Clock className="w-3 h-3" />
                            <span>Timeline: {pkg.timeline}</span>
                          </div>
                        </div>

                        <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 font-mono-code">
                          ✓ 100% Source Code Handover
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-slate-800">
                <button
                  onClick={() => setCurrentStep(2)}
                  className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
                >
                  <span>Continue to Project Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Project & Client Details */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-lg font-bold text-white">
                  Step 2: Client & Entity Information
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Required to generate your official commercial tax invoice and repository access.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-mono-code text-slate-300">
                    Full Name / Stakeholder Lead <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Tariq Al-Mansoor"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono-code text-slate-300">
                    Company / Entity Name <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Apex Capital Advisors"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono-code text-slate-300">
                    Official Work Email <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="tariq@apexcapital.ae"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-mono-code text-slate-300">
                    WhatsApp / Phone Number <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+971 58 573 5099"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-mono-code text-slate-300">
                  Project Brief & Specific Requirements (Optional)
                </label>
                <textarea
                  rows={3}
                  placeholder="Describe your current site, key objectives, reference domains, or any specific integrations..."
                  value={projectBrief}
                  onChange={(e) => setProjectBrief(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:border-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-mono-code flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    if (!clientName || !email) {
                      alert('Please provide at least your name and email.');
                      return;
                    }
                    setCurrentStep(3);
                  }}
                  className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
                >
                  <span>Generate Quote Breakdown</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Generated Official Quote Review */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-lg font-bold text-white">
                  Step 3: Official Commercial Quote & Scope Review
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Generated in accordance with UAE VAT regulations. Review the deliverables before proceeding to payment.
                </p>
              </div>

              {/* Quote Breakdown Box */}
              <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-800 text-xs font-mono-code gap-2">
                  <div>
                    <span className="text-slate-400">Target Project:</span>
                    <span className="text-white font-bold ml-1.5">{companyName || 'Enterprise'} Platform</span>
                  </div>
                  <div>
                    <span className="text-slate-400">Timeline:</span>
                    <span className="text-emerald-400 font-bold ml-1.5">{currentPackageInfo.timeline}</span>
                  </div>
                </div>

                {/* Deliverables Checklist */}
                <div className="space-y-2">
                  <span className="text-xs font-mono-code text-slate-300 font-semibold block">
                    Included Architectural Deliverables:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300">
                    {currentPackageInfo.deliverables.map((del, dIdx) => (
                      <div key={dIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                        <span className="text-[11px] leading-tight">{del}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Calculation Summary */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/90 font-mono-code text-xs space-y-2">
                  <div className="flex justify-between text-slate-300">
                    <span>{currentPackageInfo.name} Base Engineering:</span>
                    <span>AED {subtotalAed.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>UAE Federal VAT (5%):</span>
                    <span>AED {vatAed.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-800 text-sm font-bold text-white">
                    <span>Total Investment:</span>
                    <span className="text-emerald-400">AED {totalAed.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-mono-code flex items-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentStep(4)}
                  className="py-2.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                >
                  <span>Proceed to Payment Screen</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Choose Payment Method & Process */}
          {currentStep === 4 && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-lg font-bold text-white">
                  Step 4: Choose Payment Method
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Apple Pay and card payments are processed securely through payment processor gateway infrastructure.
                </p>
              </div>

              {/* Payment Methods Selector Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {PAYMENT_OPTIONS_CATALOG.map((opt) => {
                  const isSelected = selectedMethod === opt.id;

                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setSelectedMethod(opt.id)}
                      className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-gradient-to-b from-blue-950/70 to-[#0e131d] border-blue-500 shadow-md shadow-blue-950/50'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400'
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white flex items-center gap-1.5">
                            {opt.id === 'apple_pay' && '🍏 Apple Pay'}
                            {opt.id === 'credit_card' && '💳 Credit Card'}
                            {opt.id === 'debit_card' && '💳 Debit Card'}
                            {opt.id === 'stripe' && '🟣 Stripe'}
                            {opt.id === 'ziina' && '🟢 Ziina'}
                            {opt.id === 'bank_transfer' && '🏦 UAE Bank Transfer'}
                          </span>
                          <span className={`text-[9px] font-mono-code px-1.5 py-0.5 rounded ${
                            opt.status === 'connected' 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                              : 'bg-blue-950 text-blue-300 border border-blue-800'
                          }`}>
                            {opt.statusLabel}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-snug">
                          {opt.processor}
                        </p>
                      </div>

                      <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono-code">
                        <span className="text-slate-500">{opt.processingFee}</span>
                        <span className={isSelected ? 'text-blue-400 font-bold' : 'text-slate-400'}>
                          {isSelected ? '● Selected' : 'Select'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Dynamic Payment Method Execution Form */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800/90 space-y-4">
                
                {/* 1. Apple Pay Form */}
                {selectedMethod === 'apple_pay' && (
                  <div className="space-y-4 text-center py-2">
                    <div className="w-12 h-12 rounded-2xl bg-black border border-slate-700 flex items-center justify-center mx-auto text-white shadow-xl">
                      <Smartphone className="w-6 h-6 text-white" />
                    </div>
                    <div className="max-w-md mx-auto space-y-1">
                      <h4 className="text-sm font-bold text-white font-display">
                        Biometric Apple Pay via Gateway
                      </h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Authorized 1-touch payment on TouchID / FaceID device. Processed via connected merchant gateway.
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 inline-block font-mono-code text-xs text-slate-300">
                      Total Authorized Amount: <span className="text-emerald-400 font-bold">AED {totalAed.toLocaleString()}</span>
                    </div>
                  </div>
                )}

                {/* 2. Credit Card / Debit Card / Stripe Form */}
                {(selectedMethod === 'credit_card' || selectedMethod === 'debit_card' || selectedMethod === 'stripe') && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs font-mono-code text-slate-300 pb-2 border-b border-slate-800">
                      <span className="flex items-center gap-1.5">
                        <CreditCard className="w-4 h-4 text-blue-400" />
                        <span>Stripe 3DS 2.0 Encrypted Card Gateway</span>
                      </span>
                      <span className="text-emerald-400">256-Bit SSL Encrypted</span>
                    </div>

                    <div className="space-y-3">
                      <div className="space-y-1">
                        <label className="text-[11px] font-mono-code text-slate-400">Card Number</label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white font-mono-code text-xs focus:border-blue-500 focus:outline-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[11px] font-mono-code text-slate-400">Expiry (MM/YY)</label>
                          <input
                            type="text"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white font-mono-code text-xs focus:border-blue-500 focus:outline-none"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[11px] font-mono-code text-slate-400">CVC / CVV</label>
                          <input
                            type="text"
                            value={cardCvc}
                            onChange={(e) => setCardCvc(e.target.value)}
                            className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white font-mono-code text-xs focus:border-blue-500 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. Ziina Gateway Form */}
                {selectedMethod === 'ziina' && (
                  <div className="space-y-4 text-center py-2">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-950 border border-emerald-600/40 flex items-center justify-center mx-auto text-emerald-400 shadow-xl">
                      <QrCode className="w-6 h-6" />
                    </div>
                    <div className="max-w-md mx-auto space-y-1">
                      <h4 className="text-sm font-bold text-white font-display">
                        Ziina UAE Instant Payment Link & QR
                      </h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        CBUAE-compliant payment gateway for UAE cards, local fast payment rails, and instant QR checkout.
                      </p>
                    </div>

                    <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 inline-block font-mono-code text-xs text-slate-300">
                      Amount: <span className="text-emerald-400 font-bold">AED {totalAed.toLocaleString()}</span>
                    </div>
                  </div>
                )}

                {/* 4. Bank Transfer Form (Direct UAE Account + Slip Upload) */}
                {selectedMethod === 'bank_transfer' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-xs font-mono-code">
                      <span className="flex items-center gap-1.5 text-blue-400 font-bold">
                        <Building2 className="w-4 h-4" />
                        <span>Emirates NBD UAE Beneficiary Details</span>
                      </span>
                      <span className="text-amber-400 font-semibold">Manual Finance Verification</span>
                    </div>

                    {/* Bank Wire Details Box */}
                    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-mono-code space-y-1.5">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                        <p>Bank: <span className="text-white font-bold">{UAE_BANK_DETAILS.bankName}</span></p>
                        <p>Account: <span className="text-white font-bold">{UAE_BANK_DETAILS.accountName}</span></p>
                        <p>IBAN: <span className="text-blue-400 font-bold select-all">{UAE_BANK_DETAILS.iban}</span></p>
                        <p>SWIFT: <span className="text-white font-bold">{UAE_BANK_DETAILS.swift}</span></p>
                        <p>Branch: <span className="text-slate-300">{UAE_BANK_DETAILS.branch}</span></p>
                        <p>Address: <span className="text-slate-300">{UAE_BANK_DETAILS.address}</span></p>
                      </div>

                      {/* Required Payment Reference */}
                      <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between bg-blue-950/40 p-2.5 rounded-lg border border-blue-800/60">
                        <span className="text-[11px] text-slate-300">Mandatory Payment Reference:</span>
                        <span className="text-emerald-400 font-bold select-all">{uniqueBankReference}</span>
                      </div>
                    </div>

                    {/* Upload Proof Slip */}
                    <div className="space-y-2">
                      <label className="text-xs font-mono-code text-slate-300 font-semibold block">
                        Upload Transfer Slip / Receipt (PDF, PNG, JPG): <span className="text-rose-400">*</span>
                      </label>
                      <div className="p-4 rounded-xl bg-slate-900 border border-dashed border-slate-700 flex flex-col items-center justify-center text-center hover:border-blue-500 transition-colors">
                        <UploadCloud className="w-8 h-8 text-blue-400 mb-2" />
                        <label className="cursor-pointer">
                          <span className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-mono-code text-xs transition-colors">
                            {uploadedSlipName ? 'Change Transfer Slip' : 'Browse Receipt File'}
                          </span>
                          <input
                            type="file"
                            accept=".pdf,.png,.jpg,.jpeg"
                            onChange={handleFileUpload}
                            className="hidden"
                          />
                        </label>
                        <p className="text-[11px] text-slate-400 mt-2">
                          {uploadedSlipName ? (
                            <span className="text-emerald-400 font-bold font-mono-code">
                              ✓ Attached: {uploadedSlipName}
                            </span>
                          ) : (
                            'Upload official bank wire confirmation / swift advice slip'
                          )}
                        </p>
                      </div>
                    </div>
                  </div>
                )}

              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  disabled={isProcessing}
                  className="py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-mono-code flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>

                <button
                  type="button"
                  onClick={handleExecutePayment}
                  disabled={isProcessing}
                  className="py-3 px-8 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-xl shadow-emerald-600/30 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>{processingStatusText}</span>
                    </>
                  ) : (
                    <>
                      <ShieldCheck className="w-4 h-4" />
                      <span>
                        {selectedMethod === 'bank_transfer' 
                          ? `Submit Bank Transfer Slip (AED ${totalAed.toLocaleString()})`
                          : `Authorize Payment (AED ${totalAed.toLocaleString()})`
                        }
                      </span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 5: Payment Confirmation & Invoice Receipt */}
          {currentStep === 5 && createdInvoice && (
            <div className="space-y-6 text-center py-4 animate-in zoom-in-95 duration-200">
              <div className="w-16 h-16 rounded-full bg-emerald-950/90 border border-emerald-500/50 flex items-center justify-center mx-auto text-emerald-400 shadow-2xl shadow-emerald-950/80">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="max-w-md mx-auto space-y-2">
                <h3 className="font-display text-2xl font-extrabold text-white">
                  {selectedMethod === 'bank_transfer' 
                    ? 'Transfer Submitted for Verification!'
                    : 'Payment Confirmed & Verified!'
                  }
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {selectedMethod === 'bank_transfer'
                    ? `Thank you, ${clientName}. Your bank wire slip has been queued in our Dubai finance verification system. Your dedicated project architect will confirm onboarding within 1–3 business hours.`
                    : `Thank you, ${clientName}. Your milestone investment of AED ${totalAed.toLocaleString()} has been processed. Your official commercial tax invoice and repository kickoff are active.`
                  }
                </p>
              </div>

              {/* Reference Metadata Box */}
              <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 max-w-lg mx-auto text-xs font-mono-code space-y-2 text-left">
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Invoice Number:</span>
                  <span className="text-white font-bold">{createdInvoice.invoiceNumber}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Order ID:</span>
                  <span className="text-blue-400 font-bold">{orderSessionId}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Channel / Provider:</span>
                  <span className="text-emerald-400 capitalize">{selectedMethod.replace('_', ' ')}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="text-slate-400">Total Charged:</span>
                  <span className="text-white font-bold">AED {totalAed.toLocaleString()}</span>
                </div>
              </div>

              {/* Action Triggers */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="py-2.5 px-6 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs transition-colors cursor-pointer"
                >
                  Close & View Dashboard
                </button>

                <a
                  href={`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello AIGAINX Portal, I have initiated order ${orderSessionId} for ${companyName}. Please confirm our kickoff.`)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2.5 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>WhatsApp Project Kickoff</span>
                </a>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
