import React, { useState } from 'react';
import { 
  Laptop, 
  Tablet, 
  Smartphone, 
  SlidersHorizontal, 
  Sparkles, 
  Check, 
  ArrowRight, 
  Eye, 
  FileCode, 
  Layers 
} from 'lucide-react';
import { CONCEPT_PROJECTS } from '../data/portalData';

interface ConceptShowcaseProps {
  onSelectConceptToQuote: (conceptTitle: string) => void;
}

export const ConceptShowcase: React.FC<ConceptShowcaseProps> = ({ onSelectConceptToQuote }) => {
  const [selectedProjectId, setSelectedProjectId] = useState<string>(CONCEPT_PROJECTS[0].id);
  const [deviceView, setDeviceView] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [showWireframeMode, setShowWireframeMode] = useState<boolean>(false);

  const activeProject = CONCEPT_PROJECTS.find(p => p.id === selectedProjectId) || CONCEPT_PROJECTS[0];

  return (
    <section 
      id="concepts"
      className="py-24 bg-[#0c1017] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono-code font-semibold mb-3">
              <span>INDUSTRY ARCHITECTURES</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Concept Demonstrations by Industry.
            </h2>
            <p className="text-slate-300 text-base mt-2">
              Explore how our 8-step system adapts to real estate, hospitality, retail, and DIFC professional services.
            </p>
          </div>

          {/* Explicit Transparency Notice */}
          <div className="shrink-0 flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 text-xs font-mono-code">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Strictly Labeled: Concept / Demo Projects</span>
          </div>
        </div>

        {/* Concept Project Selector Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
          {CONCEPT_PROJECTS.map((proj) => {
            const isSelected = proj.id === selectedProjectId;
            return (
              <button
                key={proj.id}
                onClick={() => setSelectedProjectId(proj.id)}
                className={`p-4 rounded-xl text-left transition-all border cursor-pointer ${
                  isSelected
                    ? 'bg-slate-800/90 border-blue-500 shadow-md shadow-blue-900/30'
                    : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-900 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-slate-950 text-slate-400 border border-slate-800">
                    {proj.industry.split(' ')[0]}
                  </span>
                  <span className="text-[10px] font-mono-code text-amber-400 font-semibold">
                    Concept
                  </span>
                </div>
                <h3 className={`font-display text-sm font-bold ${
                  isSelected ? 'text-white' : 'text-slate-300'
                }`}>
                  {proj.title}
                </h3>
              </button>
            );
          })}
        </div>

        {/* Interactive Showcase Frame & Controls */}
        <div className="rounded-2xl bg-[#090b10] border border-slate-800 shadow-2xl overflow-hidden">
          
          {/* Top Control Bar: Viewport selector & Wireframe Mode toggle */}
          <div className="px-6 py-3.5 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
            
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 text-xs text-slate-300 font-mono-code">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                <span className="font-semibold text-white">{activeProject.title}</span>
                <span className="text-slate-500">({activeProject.industry})</span>
              </div>
            </div>

            {/* Viewport & Mode Buttons */}
            <div className="flex items-center gap-3">
              
              {/* Wireframe Toggle */}
              <button
                onClick={() => setShowWireframeMode(!showWireframeMode)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono-code flex items-center gap-1.5 border transition-all cursor-pointer ${
                  showWireframeMode
                    ? 'bg-blue-600 border-blue-400 text-white font-semibold'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{showWireframeMode ? 'Wireframe Mode: ON' : 'Toggle Wireframe Blueprint'}</span>
              </button>

              {/* Viewport Selectors */}
              <div className="hidden sm:flex bg-slate-950 p-1 rounded-lg border border-slate-800 gap-1">
                <button
                  onClick={() => setDeviceView('desktop')}
                  className={`p-1.5 rounded text-xs transition-all ${
                    deviceView === 'desktop' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Desktop View (16:9)"
                >
                  <Laptop className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDeviceView('tablet')}
                  className={`p-1.5 rounded text-xs transition-all ${
                    deviceView === 'tablet' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Tablet View (4:3)"
                >
                  <Tablet className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setDeviceView('mobile')}
                  className={`p-1.5 rounded text-xs transition-all ${
                    deviceView === 'mobile' ? 'bg-slate-800 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Mobile View (9:16)"
                >
                  <Smartphone className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>

          {/* Interactive Screen Preview Container */}
          <div className="p-6 sm:p-10 flex flex-col items-center justify-center bg-grid-pattern min-h-[460px]">
            
            {/* Dynamic Sized Simulated Viewport Frame */}
            <div 
              className={`transition-all duration-300 w-full rounded-xl border shadow-2xl overflow-hidden ${
                deviceView === 'desktop' 
                  ? 'max-w-4xl border-slate-700 bg-slate-950' 
                  : deviceView === 'tablet' 
                    ? 'max-w-xl border-slate-700 bg-slate-950' 
                    : 'max-w-sm border-slate-700 bg-slate-950'
              }`}
            >
              {/* Browser Address Bar Mock */}
              <div className="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between text-[11px] font-mono-code text-slate-400">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-slate-700" />
                  <div className="w-2 h-2 rounded-full bg-slate-700" />
                  <div className="w-2 h-2 rounded-full bg-slate-700" />
                </div>
                <div className="bg-slate-950 px-3 py-0.5 rounded text-slate-300 truncate max-w-[200px] border border-slate-800 text-[10px]">
                  https://demo.aigainx.ae/{activeProject.id}
                </div>
                <span className="text-[10px] text-emerald-400">SSL 256-bit</span>
              </div>

              {/* Screen Interior (Rendered vs Wireframe Mode) */}
              {showWireframeMode ? (
                /* Low-Fidelity Wireframe Mode */
                <div className="p-8 bg-[#090b10] font-mono-code text-slate-400 space-y-6">
                  <div className="border border-dashed border-slate-700 p-4 rounded-lg flex items-center justify-between bg-slate-900/30">
                    <span className="text-xs">[NAVIGATION CONTAINER: Brand Logo + Menu Taxonomy + Sticky CTA]</span>
                    <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-300">Z-Index 50</span>
                  </div>

                  <div className="border border-dashed border-blue-500/50 p-6 rounded-lg space-y-3 bg-blue-950/10">
                    <div className="inline-block border border-blue-400 px-2 py-0.5 text-[10px] text-blue-300">
                      [HERO VALUE PROPOSITION BLOCK]
                    </div>
                    <div className="h-6 bg-slate-800 rounded w-3/4 animate-pulse" />
                    <div className="h-4 bg-slate-800/60 rounded w-1/2" />
                    <div className="pt-2 flex gap-3">
                      <div className="h-8 w-32 bg-blue-600/40 border border-blue-400 rounded flex items-center justify-center text-[10px] text-white">
                        [PRIMARY CTA]
                      </div>
                      <div className="h-8 w-28 border border-slate-700 rounded flex items-center justify-center text-[10px]">
                        [WHATSAPP]
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {activeProject.screens.sampleElements.map((el, i) => (
                      <div key={i} className="border border-dashed border-slate-700 p-3 rounded text-[10px] text-center bg-slate-900/40">
                        [ATTR_0{i+1}: {el}]
                      </div>
                    ))}
                  </div>

                  <div className="text-[10px] text-blue-400 text-right">
                    Wireframe Spec #IA-0{activeProject.id.length} · Approved for Code
                  </div>
                </div>
              ) : (
                /* High-Fidelity UI Presentation Mode */
                <div 
                  className="p-8 sm:p-10 space-y-6 transition-all"
                  style={{
                    backgroundColor: '#0d1117'
                  }}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono-code font-bold uppercase tracking-wider text-blue-400">
                      {activeProject.industry}
                    </span>
                    <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                      AED Active Currency
                    </span>
                  </div>

                  <div className="space-y-3">
                    <h4 className="font-display text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                      {activeProject.screens.heroTitle}
                    </h4>
                    <p className="text-sm text-slate-300 max-w-xl">
                      {activeProject.screens.heroSubtitle}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 pt-1">
                    {activeProject.screens.sampleElements.map((item, idx) => (
                      <span 
                        key={idx}
                        className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-200"
                      >
                        ✓ {item}
                      </span>
                    ))}
                  </div>

                  <div className="pt-3 flex flex-wrap items-center gap-3">
                    <button 
                      onClick={() => onSelectConceptToQuote(activeProject.title)}
                      className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md flex items-center gap-2 cursor-pointer"
                    >
                      <span>{activeProject.screens.ctaText}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-xs text-slate-400 font-mono-code">
                      Engineered for High-Intent Lead Conversion
                    </span>
                  </div>
                </div>
              )}

            </div>

          </div>

          {/* Showcase Bottom Details Bar */}
          <div className="p-6 bg-slate-900/90 border-t border-slate-800 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            
            <div className="md:col-span-8 space-y-1">
              <span className="text-xs font-semibold text-slate-300 uppercase font-mono-code tracking-wider">
                Demonstration Focus:
              </span>
              <p className="text-xs text-slate-400 leading-relaxed">
                {activeProject.description}
              </p>
              <div className="text-[11px] text-blue-400 font-mono-code pt-1">
                Wireframe Architecture: {activeProject.wireframeHighlight}
              </div>
            </div>

            {/* Performance Badges */}
            <div className="md:col-span-4 flex items-center justify-start md:justify-end gap-3 font-mono-code text-xs">
              <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-500 block">Load Speed</span>
                <span className="font-bold text-emerald-400">{activeProject.metrics.pageLoad}</span>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-500 block">Mobile Score</span>
                <span className="font-bold text-blue-400">{activeProject.metrics.mobileScore}</span>
              </div>
              <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-center">
                <span className="text-[10px] text-slate-500 block">Focus</span>
                <span className="font-bold text-amber-300">{activeProject.metrics.conversionFocus}</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
