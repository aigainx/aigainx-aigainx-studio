import React from 'react';
import { 
  ShieldCheck, 
  Zap, 
  Cpu, 
  Lock, 
  Globe2, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  Layers,
  Terminal,
  Activity
} from 'lucide-react';

export const TechTrustTicker: React.FC = () => {
  const techStack = [
    { name: 'TypeScript', desc: 'Type-Safe Architecture', badge: 'Strict v5.6' },
    { name: 'React 19 & Vite', desc: 'Instant HMR & Speed', badge: 'Fast Refresh' },
    { name: 'Tailwind CSS', desc: 'Zero-Bloat Styling', badge: 'Modern v4' },
    { name: 'Cloudflare Edge', desc: 'Sub-30ms Global CDN', badge: 'Global Edge' },
    { name: 'Next.js / Node', desc: 'Full-Stack Capability', badge: 'SSR / SSG' },
    { name: 'PostgreSQL / Drizzle', desc: 'Relational Database', badge: 'Type-Safe' },
  ];

  const credentials = [
    { label: 'Dubai DED Licensed Entity', value: 'Licence #1646775', icon: ShieldCheck, color: 'text-blue-400' },
    { label: 'Core Web Vitals Benchmark', value: '99+ PageSpeed Score', icon: Zap, color: 'text-amber-400' },
    { label: 'Source Code & Assets', value: '100% Client IP Transfer', icon: Lock, color: 'text-emerald-400' },
    { label: 'Studio Response SLA', value: '< 4hr Engineering Turnaround', icon: Clock, color: 'text-cyan-400' },
  ];

  return (
    <div className="relative border-y border-slate-800/80 bg-[#07090e] overflow-hidden text-xs font-mono-code">
      {/* Ambient background light stripe */}
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/10 via-transparent to-indigo-900/10 pointer-events-none" />

      {/* Top Credentials & Studio Performance Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 divide-y md:divide-y-0 md:divide-x divide-slate-800/80">
          {credentials.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className={`flex items-center gap-3 ${idx > 0 ? 'md:pl-6' : ''} ${idx > 1 ? 'pt-3 md:pt-0' : ''}`}>
                <div className="w-9 h-9 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-center shrink-0 shadow-inner">
                  <Icon className={`w-4 h-4 ${item.color}`} />
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase tracking-wider">{item.label}</span>
                  <span className="font-semibold text-white text-xs block font-display tracking-tight mt-0.5">{item.value}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom Tech Frameworks Bar */}
      <div className="border-t border-slate-800/60 bg-slate-950/60 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-400 shrink-0">
            <Terminal className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-[11px] text-slate-300 font-semibold uppercase tracking-wider">
              Engineering Stack:
            </span>
          </div>

          {/* Tech Badges List */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto py-1 no-scrollbar justify-start md:justify-end">
            {techStack.map((tech, i) => (
              <div
                key={i}
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-colors shrink-0 shadow-xs"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
                <span className="font-semibold text-slate-200 text-[11px]">{tech.name}</span>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
                  {tech.badge}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
