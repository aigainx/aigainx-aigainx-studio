import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ArrowRight, 
  MessageSquare, 
  CheckCircle2, 
  Cpu, 
  Layout, 
  Zap, 
  Lock, 
  Unlock, 
  Smartphone, 
  FileCode, 
  Layers,
  Sparkles,
  ArrowUpRight,
  Activity,
  Terminal,
  Gauge,
  Check
} from 'lucide-react';
import { BRAND_CONFIG } from '../data/portalData';

interface HeroProps {
  onStartProject: () => void;
  onExploreProcess: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onStartProject, onExploreProcess }) => {
  const [activeTab, setActiveTab] = useState<'system' | 'audit' | 'template'>('system');

  const handleWhatsApp = () => {
    const message = encodeURIComponent(
      `Hello AIGAINX Portal, I'm interested in starting a web design project for my business.`
    );
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${message}`, '_blank');
  };

  return (
    <section 
      id="hero-section"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-grid-pattern"
    >
      {/* Ambient background glows & spotlight */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-blue-600/15 blur-[140px] pointer-events-none -z-10 rounded-full" />
      <div className="absolute top-1/3 right-10 w-[400px] h-[350px] bg-indigo-600/10 blur-[110px] pointer-events-none -z-10 rounded-full" />
      <div className="absolute -top-10 left-10 w-[300px] h-[300px] bg-emerald-500/10 blur-[100px] pointer-events-none -z-10 rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Core Positioning & CTAs */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Tagline Badge & Monogram Emblem */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 shadow-lg shadow-blue-900/20 backdrop-blur-md">
                <div className="w-5 h-5 rounded-md overflow-hidden bg-slate-950 border border-blue-500/40 shrink-0">
                  <img 
                    src={BRAND_CONFIG.monogramUrl} 
                    alt="AIGAINX Monogram" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="text-xs font-semibold text-slate-200 tracking-wide">
                  Websites Built Like a System, Not a Template
                </span>
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/70 border border-blue-800/60 text-[11px] font-mono-code text-blue-300 backdrop-blur-md">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Dubai DED Entity #1646775</span>
              </div>
            </div>

            {/* Main Headline with high-contrast display typography */}
            <h1 
              id="hero-main-title"
              className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-[1.08]"
            >
              Architected Web Systems for{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-200 to-cyan-300">
                Modern Businesses
              </span>
            </h1>

            {/* Sub-headline */}
            <p 
              id="hero-sub-title"
              className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl font-normal"
            >
              {BRAND_CONFIG.heroStatement}
            </p>

            {/* Process Highlights / Fast Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2 font-mono-code">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900/70 border border-slate-800/90 shadow-sm backdrop-blur-sm">
                <Cpu className="w-4 h-4 text-blue-400 shrink-0" />
                <span className="text-xs font-medium text-slate-200">8-Step Delivery</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900/70 border border-slate-800/90 shadow-sm backdrop-blur-sm">
                <Smartphone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-xs font-medium text-slate-200">Mobile-First UI</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-900/70 border border-slate-800/90 shadow-sm backdrop-blur-sm col-span-2 sm:col-span-1">
                <Unlock className="w-4 h-4 text-indigo-400 shrink-0" />
                <span className="text-xs font-medium text-slate-200">100% IP Transfer</span>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                id="hero-cta-primary"
                onClick={onStartProject}
                className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-blue-500 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2 transition-all hover:translate-y-[-1px] group cursor-pointer"
              >
                <span>Start Your Project</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
              </button>

              <button
                id="hero-cta-whatsapp"
                onClick={handleWhatsApp}
                className="px-6 py-3.5 rounded-xl bg-emerald-950/70 border border-emerald-700/80 hover:bg-emerald-900/80 text-emerald-200 font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer backdrop-blur-sm shadow-lg shadow-emerald-950/40"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>Chat on WhatsApp</span>
              </button>
            </div>

            {/* Trust Line */}
            <div 
              id="hero-trust-line"
              className="pt-2 flex items-center gap-2 text-xs text-slate-400 font-mono-code flex-wrap"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                Commercial Entity · Emitac Building, Dubai · Sub-1s Global Edge Latency · Zero-Lockin
              </span>
            </div>

          </div>

          {/* Right Column: Interactive System vs Template vs Audit Inspector */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-gradient-to-b from-slate-800/90 via-slate-900/95 to-[#0b0e14] p-1 border border-slate-700/80 shadow-2xl shadow-black/80">
              
              {/* Window Header / Mode Switcher */}
              <div className="bg-[#090c12] rounded-t-xl px-4 py-3 border-b border-slate-800/90 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  <span className="text-[11px] text-slate-300 font-mono-code ml-1 font-semibold">
                    studio_architecture.ts
                  </span>
                </div>

                {/* 3 View Tabs */}
                <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-[10px] font-mono-code">
                  <button
                    onClick={() => setActiveTab('system')}
                    className={`px-2 py-1 rounded transition-all cursor-pointer ${
                      activeTab === 'system' 
                        ? 'bg-blue-600 text-white font-semibold shadow-sm' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    System
                  </button>
                  <button
                    onClick={() => setActiveTab('audit')}
                    className={`px-2 py-1 rounded transition-all cursor-pointer ${
                      activeTab === 'audit' 
                        ? 'bg-emerald-600 text-white font-semibold shadow-sm' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Vitals
                  </button>
                  <button
                    onClick={() => setActiveTab('template')}
                    className={`px-2 py-1 rounded transition-all cursor-pointer ${
                      activeTab === 'template' 
                        ? 'bg-slate-800 text-slate-200 font-semibold' 
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Pitfalls
                  </button>
                </div>
              </div>

              {/* Inspector Content */}
              <div className="p-5 bg-[#0b0e14] rounded-b-xl space-y-4">
                
                {/* TAB 1: AIGAINX SYSTEM */}
                {activeTab === 'system' && (
                  <div className="space-y-4 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                          <Layers className="w-4 h-4 text-blue-400" />
                          <span>The AIGAINX 8-Step System</span>
                        </div>
                        <p className="text-[11px] text-slate-400">Deterministic process with zero guesswork</p>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-700/80 text-emerald-300 font-mono-code text-[10px] font-bold">
                        100% RELIABLE
                      </span>
                    </div>

                    {/* Step Flow Mini Bar */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px] text-slate-300 font-mono-code">
                        <span>1. IA / Wireframes</span>
                        <span>2. UI Figma</span>
                        <span>3. Code</span>
                        <span>4. Handover</span>
                      </div>
                      <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden flex border border-slate-800">
                        <div className="w-1/4 bg-blue-500 h-full border-r border-[#0b0e14]" />
                        <div className="w-1/4 bg-indigo-500 h-full border-r border-[#0b0e14]" />
                        <div className="w-1/4 bg-sky-400 h-full border-r border-[#0b0e14]" />
                        <div className="w-1/4 bg-emerald-400 h-full" />
                      </div>
                    </div>

                    {/* Feature Cards Matrix */}
                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800/90 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold text-white">Mobile-First Touch Architecture</span>
                          <p className="text-[11px] text-slate-400 mt-0.5">Thumb-zone CTAs, sub-second response, tested across iOS & Android devices.</p>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800/90 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold text-white">100% Unlocked Code Ownership</span>
                          <p className="text-[11px] text-slate-400 mt-0.5">Full Git repo & Figma design tokens transferred directly to your organization.</p>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800/90 flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-semibold text-white">Local Dubai Accountability</span>
                          <p className="text-[11px] text-slate-400 mt-0.5">Licensed Entity 1646775 · Activity 722903 Web-Design · VAT Compliant.</p>
                        </div>
                      </div>
                    </div>

                    {/* Fast Action */}
                    <button
                      onClick={onExploreProcess}
                      className="w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-blue-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <span>Explore the Full 8-Step System</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* TAB 2: PRODUCTION PERFORMANCE AUDIT */}
                {activeTab === 'audit' && (
                  <div className="space-y-4 animate-in fade-in duration-200 font-mono-code text-xs">
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                          <Gauge className="w-4 h-4 text-emerald-400" />
                          <span>Google Core Web Vitals Audit</span>
                        </div>
                        <p className="text-[11px] text-slate-400">Target metrics guaranteed on every deployment</p>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 font-bold text-[10px]">
                        99/100 SCORE
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block uppercase">Largest Contentful Paint (LCP)</span>
                        <span className="text-emerald-400 font-bold text-sm">0.6s (Instant)</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block uppercase">Cumulative Layout Shift (CLS)</span>
                        <span className="text-emerald-400 font-bold text-sm">0.00 (Zero Shift)</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block uppercase">First Input Delay (FID)</span>
                        <span className="text-emerald-400 font-bold text-sm">12ms (Native)</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                        <span className="text-[10px] text-slate-400 block uppercase">Mobile UX Accessibility</span>
                        <span className="text-blue-400 font-bold text-sm">100/100 Pass</span>
                      </div>
                    </div>

                    <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-[11px] flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Zero bloated visual page builders. Pure clean semantic code.</span>
                    </div>

                    <button
                      onClick={onStartProject}
                      className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md"
                    >
                      <span>Request High-Velocity Build</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* TAB 3: GENERIC TEMPLATE PITFALLS */}
                {activeTab === 'template' && (
                  <div className="space-y-4 animate-in fade-in duration-200">
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                          <Layout className="w-4 h-4 text-amber-400" />
                          <span>Generic Template / Freelancer Shortcuts</span>
                        </div>
                        <p className="text-[11px] text-slate-400">Common pitfalls in amateur web execution</p>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-red-950/80 border border-red-800/80 text-red-300 font-mono-code text-[10px] font-bold">
                        HIGH RISK
                      </span>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div className="p-2.5 rounded-xl bg-red-950/20 border border-red-900/40 flex items-start gap-2.5">
                        <span className="text-red-400 font-bold shrink-0">✕</span>
                        <div>
                          <span className="font-semibold text-red-200">Bloated Unused Plugins</span>
                          <p className="text-[11px] text-slate-400 mt-0.5">Slow 4-7s load speeds, failing Google Core Web Vitals on mobile networks.</p>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-red-950/20 border border-red-900/40 flex items-start gap-2.5">
                        <span className="text-red-400 font-bold shrink-0">✕</span>
                        <div>
                          <span className="font-semibold text-red-200">Locked-in Hostage Code</span>
                          <p className="text-[11px] text-slate-400 mt-0.5">No source code export, proprietary platform monthly lock-in fees.</p>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-red-950/20 border border-red-900/40 flex items-start gap-2.5">
                        <span className="text-red-400 font-bold shrink-0">✕</span>
                        <div>
                          <span className="font-semibold text-red-200">No Structured UAE Process</span>
                          <p className="text-[11px] text-slate-400 mt-0.5">Anonymous freelancer, no commercial licence, missing milestone deadlines.</p>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('system')}
                      className="w-full py-2.5 px-3 rounded-xl bg-blue-600/40 hover:bg-blue-600/60 border border-blue-500/50 text-blue-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <span>Switch to Structured System</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

