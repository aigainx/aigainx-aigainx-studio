import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Menu, 
  X, 
  ArrowRight, 
  MessageSquare, 
  Clock, 
  Layers, 
  ExternalLink,
  Sun,
  Moon,
  Compass
} from 'lucide-react';
import { BRAND_CONFIG } from '../data/portalData';
import { useTheme } from '../context/ThemeContext';

interface NavbarProps {
  onOpenScopeBuilder: () => void;
  onOpenCheckout?: (packageId?: string) => void;
  onOpenClientDashboard?: () => void;
  onOpenAdminPortal?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onOpenScopeBuilder,
  onOpenCheckout,
  onOpenClientDashboard,
  onOpenAdminPortal
}) => {
  const { theme, toggleTheme, isBlueprint } = useTheme();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [dubaiTime, setDubaiTime] = useState('');


  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const updateTime = () => {
      try {
        const now = new Date();
        const options: Intl.DateTimeFormatOptions = {
          timeZone: 'Asia/Dubai',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: false
        };
        const formatter = new Intl.DateTimeFormat('en-GB', options);
        setDubaiTime(formatter.format(now) + ' GST (UTC+4)');
      } catch (e) {
        setDubaiTime('Dubai, UAE');
      }
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleWhatsApp = () => {
    const message = encodeURIComponent(
      `Hello AIGAINX Portal team, I would like to discuss a web design project for my business.`
    );
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${message}`, '_blank');
  };

  return (
    <header 
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-[#090b10]/90 backdrop-blur-md border-b border-slate-800/80 shadow-lg shadow-black/40 py-3' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <a 
            href="#" 
            id="brand-logo-link"
            className="flex items-center gap-3 group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl overflow-hidden shadow-lg shadow-blue-500/20 border border-slate-700/80 group-hover:border-blue-500/60 group-hover:scale-105 transition-all bg-slate-900 shrink-0">
              <img 
                src={BRAND_CONFIG.monogramUrl} 
                alt="AIGAINX Official Monogram" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display text-xl font-extrabold tracking-tight text-white group-hover:text-blue-300 transition-colors">
                  AIGAINX
                </span>
                <span className="text-[10px] uppercase tracking-widest text-blue-400 font-mono-code font-semibold px-1.5 py-0.5 rounded bg-blue-950/60 border border-blue-800/60">
                  PORTAL
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium tracking-wide flex items-center gap-1">
                <span>Emitac Building, Dubai</span>
                <span className="text-slate-600">•</span>
                <span className="text-blue-400 font-mono-code">Gain & Innovation</span>
              </p>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 bg-slate-900/60 border border-slate-800/80 rounded-full px-4 py-1.5 backdrop-blur-sm">
            <a 
              href="#process" 
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800/60 transition-colors"
            >
              8-Step System
            </a>
            <a 
              href="#services" 
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800/60 transition-colors"
            >
              Services
            </a>
            <a 
              href="#concepts" 
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800/60 transition-colors"
            >
              Concepts
            </a>
            <a 
              href="#packages" 
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800/60 transition-colors"
            >
              Packages
            </a>
            <a 
              href="#payments" 
              className="text-xs font-medium text-emerald-400 hover:text-emerald-300 px-3 py-1.5 rounded-full hover:bg-emerald-950/40 transition-colors flex items-center gap-1"
            >
              <span>Payments</span>
            </a>
            <a 
              href="#testimonials" 
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800/60 transition-colors"
            >
              Success
            </a>
            <a 
              href="#scope-builder" 
              className="text-xs font-medium text-blue-400 hover:text-blue-300 px-3 py-1.5 rounded-full hover:bg-blue-950/40 transition-colors flex items-center gap-1"
            >
              Scope Builder
            </a>
            <a 
              href="#about" 
              className="text-xs font-medium text-slate-300 hover:text-white px-3 py-1.5 rounded-full hover:bg-slate-800/60 transition-colors"
            >
              About
            </a>
          </nav>

          {/* Right Header Actions */}
          <div className="hidden md:flex items-center gap-2.5">
            {/* Global Blueprint / Dark Theme Switcher */}
            <button
              id="header-theme-toggle-btn"
              onClick={toggleTheme}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-mono-code transition-all cursor-pointer ${
                isBlueprint
                  ? 'bg-blue-100/90 border-blue-300 text-blue-900 hover:bg-blue-200/90 shadow-sm'
                  : 'bg-slate-900/90 border-slate-700/80 hover:border-amber-400/60 text-slate-200 hover:text-white'
              }`}
              title={isBlueprint ? "Switch to Dark Architectural Slate" : "Switch to High-Contrast Blueprint/Light Mode (Presentation)"}
              aria-label="Toggle Blueprint / Dark theme"
            >
              {isBlueprint ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-600 fill-amber-500/20" />
                  <span className="font-semibold text-blue-950">Blueprint</span>
                  <span className="text-[10px] px-1 py-0.2 rounded bg-blue-200 text-blue-800 font-bold">Light</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-blue-400" />
                  <span>Theme</span>
                  <span className="text-[10px] px-1 py-0.2 rounded bg-slate-800 text-slate-400">Dark</span>
                </>
              )}
            </button>

            {/* Client Area Portal Button */}
            {onOpenClientDashboard && (
              <button
                id="header-client-area-btn"
                onClick={onOpenClientDashboard}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-700/80 hover:border-blue-500/60 text-slate-200 hover:text-white text-xs font-mono-code transition-all cursor-pointer"
                title="Open Client Area & Invoices"
              >
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                <span>Client Area</span>
              </button>
            )}

            {/* WhatsApp Quick CTA */}
            <button
              id="header-whatsapp-btn"
              onClick={handleWhatsApp}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-950/50 border border-emerald-800/60 hover:bg-emerald-900/60 text-emerald-300 hover:text-emerald-200 text-xs font-medium transition-colors cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>WhatsApp</span>
            </button>

            {/* Primary Action Button - Start Project Checkout */}
            <button
              id="header-start-project-btn"
              onClick={() => onOpenCheckout ? onOpenCheckout() : onOpenScopeBuilder()}
              className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md shadow-blue-600/30 transition-all hover:translate-y-[-1px] cursor-pointer"
            >
              <span>Start Project</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Menu & Theme Buttons */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              id="mobile-theme-toggle-btn"
              onClick={toggleTheme}
              className={`p-2 rounded-lg border text-xs transition-colors ${
                isBlueprint
                  ? 'bg-blue-100 border-blue-300 text-blue-900'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
              }`}
              title={isBlueprint ? "Switch to Dark Architectural Slate" : "Switch to High-Contrast Blueprint/Light Mode"}
              aria-label="Toggle Theme"
            >
              {isBlueprint ? <Sun className="w-5 h-5 text-amber-600" /> : <Moon className="w-5 h-5 text-blue-400" />}
            </button>

            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div 
          id="mobile-nav-panel"
          className="lg:hidden bg-[#0c1017] border-b border-slate-800 px-4 pt-3 pb-6 space-y-3 mt-3 animate-in fade-in duration-200"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800/80">
            <span>Emitac Building, Dubai, UAE</span>
            <span className="font-mono-code text-blue-400 flex items-center gap-1">
              <Layers className="w-3 h-3" /> 8-Step Studio System
            </span>
          </div>

          {/* Mobile Theme Toggle Row */}
          <button
            id="mobile-drawer-theme-toggle"
            onClick={toggleTheme}
            className={`w-full py-2 px-3.5 rounded-lg border text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
              isBlueprint
                ? 'bg-blue-50 border-blue-300 text-blue-900'
                : 'bg-slate-900 border-slate-700 text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {isBlueprint ? (
                <Sun className="w-4 h-4 text-amber-600" />
              ) : (
                <Moon className="w-4 h-4 text-blue-400" />
              )}
              <span>Theme Presentation Mode</span>
            </div>
            <span className={`text-[10px] px-2 py-0.5 rounded font-mono-code font-bold uppercase ${
              isBlueprint ? 'bg-blue-600 text-white' : 'bg-slate-800 text-blue-300'
            }`}>
              {isBlueprint ? 'Blueprint / Light' : 'Dark Slate'}
            </span>
          </button>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <a 
              href="#process" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-slate-300 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800"
            >
              8-Step System
            </a>
            <a 
              href="#services" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-slate-300 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800"
            >
              Services
            </a>
            <a 
              href="#packages" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-slate-300 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800"
            >
              Packages
            </a>
            <a 
              href="#payments" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-emerald-300 p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60"
            >
              Payments & Gateways
            </a>
            <a 
              href="#testimonials" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-slate-300 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800"
            >
              Client Success
            </a>
            <a 
              href="#concepts" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-slate-300 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800"
            >
              Concepts
            </a>
            <a 
              href="#scope-builder" 
              onClick={() => setMobileMenuOpen(false)}
              className="text-xs font-medium text-blue-400 p-2.5 rounded-lg bg-blue-950/40 border border-blue-800/50 col-span-2 flex items-center justify-between"
            >
              <span>Interactive Scope Builder</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            {onOpenClientDashboard && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenClientDashboard();
                }}
                className="w-full py-2.5 px-4 rounded-lg bg-slate-900 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
              >
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                <span>Open Client Area & Invoices</span>
              </button>
            )}

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                if (onOpenCheckout) {
                  onOpenCheckout();
                } else {
                  onOpenScopeBuilder();
                }
              }}
              className="w-full py-2.5 px-4 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Start Project & Checkout</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                handleWhatsApp();
              }}
              className="w-full py-2.5 px-4 rounded-lg bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs font-medium flex items-center justify-center gap-2 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>Chat on WhatsApp (+971)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
