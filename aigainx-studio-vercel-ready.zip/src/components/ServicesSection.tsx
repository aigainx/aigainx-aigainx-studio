import React, { useState } from 'react';
import { 
  Building2, 
  Zap, 
  ShoppingBag, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  HelpCircle, 
  Layers 
} from 'lucide-react';
import { SERVICES } from '../data/portalData';

interface ServicesSectionProps {
  onRequestServiceQuote: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onRequestServiceQuote }) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>(SERVICES[0].id);

  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'corporate-websites': return <Building2 className="w-5 h-5" />;
      case 'landing-pages': return <Zap className="w-5 h-5" />;
      case 'ecommerce-catalog': return <ShoppingBag className="w-5 h-5" />;
      case 'web-replatforming': return <RefreshCw className="w-5 h-5" />;
      default: return <Building2 className="w-5 h-5" />;
    }
  };

  const activeService = SERVICES.find(s => s.id === selectedServiceId) || SERVICES[0];

  return (
    <section 
      id="services"
      className="py-24 bg-[#090b10] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/60 border border-indigo-800/60 text-indigo-400 text-xs font-mono-code font-semibold mb-3">
            <span>LICENSED WEB-DESIGN SERVICES</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Specialized Web Solutions for Growing UAE Businesses.
          </h2>
          <p className="text-slate-300 text-base mt-2">
            Every service is engineered around business outcomes: turning mobile visitors into validated inquiries with fast, accessible code.
          </p>
        </div>

        {/* Service Navigation Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
          {SERVICES.map((service) => {
            const isSelected = service.id === selectedServiceId;
            return (
              <button
                key={service.id}
                onClick={() => setSelectedServiceId(service.id)}
                className={`p-4 rounded-xl text-left transition-all border cursor-pointer ${
                  isSelected
                    ? 'bg-blue-600/15 border-blue-500 shadow-md shadow-blue-900/20'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    isSelected ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {getServiceIcon(service.id)}
                  </div>
                  <span className="text-[10px] font-mono-code text-slate-400 uppercase">
                    {service.category.split(' ')[0]}
                  </span>
                </div>
                <h3 className={`font-display text-sm font-bold ${
                  isSelected ? 'text-white' : 'text-slate-300'
                }`}>
                  {service.title}
                </h3>
              </button>
            );
          })}
        </div>

        {/* Selected Service Deep-Dive View (Hero -> Problem -> Solution -> Features -> Process -> FAQ -> CTA) */}
        <div className="rounded-2xl bg-[#0e131d] border border-slate-800/90 shadow-2xl overflow-hidden p-6 sm:p-10 space-y-10">
          
          {/* 1. Service Hero & Category Header */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-8 border-b border-slate-800">
            <div className="space-y-2 max-w-3xl">
              <span className="text-xs font-mono-code uppercase text-blue-400 font-semibold px-2.5 py-1 rounded bg-blue-950/60 border border-blue-800/60">
                {activeService.category}
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                {activeService.title}
              </h3>
              <p className="text-base text-slate-300">
                {activeService.tagline}
              </p>
              <div className="text-xs text-slate-400 pt-1">
                <span className="font-semibold text-slate-300">Target Industry:</span> {activeService.targetAudience}
              </div>
            </div>

            <div className="shrink-0">
              <button
                onClick={() => onRequestServiceQuote(activeService.title)}
                className="px-5 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-lg shadow-blue-600/30 flex items-center gap-2 transition-all cursor-pointer"
              >
                <span>Request a Quote for this Service</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* 2. Problem vs Solution Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* The Problem */}
            <div className="p-6 rounded-xl bg-red-950/20 border border-red-900/40 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-mono-code uppercase font-semibold text-red-400">
                <AlertCircle className="w-4 h-4" />
                <span>The Common Problem</span>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                {activeService.problem}
              </p>
            </div>

            {/* The AIGAINX Solution */}
            <div className="p-6 rounded-xl bg-blue-950/30 border border-blue-800/50 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-mono-code uppercase font-semibold text-blue-400">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>The AIGAINX Solution</span>
              </div>
              <p className="text-sm text-slate-200 leading-relaxed">
                {activeService.solution}
              </p>
            </div>
          </div>

          {/* 3. Core Technical & UI Features */}
          <div className="space-y-4">
            <h4 className="font-display text-lg font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              <span>What is Built into this System</span>
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeService.features.map((feat, i) => (
                <div 
                  key={i}
                  className="flex items-start gap-3 p-3.5 rounded-xl bg-slate-900/70 border border-slate-800/80 text-xs text-slate-200"
                >
                  <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* 4. Process Sequence & Deliverables */}
          <div className="p-5 rounded-xl bg-slate-900/40 border border-slate-800/80 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-8 space-y-2">
              <span className="text-[11px] font-mono-code uppercase tracking-wider text-slate-400">
                System Execution Sequence
              </span>
              <div className="flex flex-wrap gap-2 text-xs font-medium text-slate-300">
                {activeService.processSummary.map((step, idx) => (
                  <span 
                    key={idx} 
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 border border-slate-700/60"
                  >
                    <span className="text-blue-400 font-mono-code text-[10px]">0{idx + 1}.</span>
                    <span>{step}</span>
                  </span>
                ))}
              </div>
            </div>

            <div className="lg:col-span-4 border-t lg:border-t-0 lg:border-l border-slate-800 pt-4 lg:pt-0 lg:pl-6 space-y-1">
              <span className="text-[11px] font-mono-code uppercase text-emerald-400 font-semibold">
                Client Deliverables
              </span>
              <p className="text-xs text-slate-300 leading-snug">
                {activeService.deliverableSnippet}
              </p>
            </div>
          </div>

          {/* 5. Service-Specific FAQs */}
          {activeService.faqs.length > 0 && (
            <div className="space-y-4 pt-2">
              <h4 className="text-sm font-semibold text-slate-300 font-mono-code uppercase tracking-wider flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-blue-400" />
                <span>Service Specific Questions</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeService.faqs.map((faq, i) => (
                  <div key={i} className="p-4 rounded-xl bg-slate-900/50 border border-slate-800/70 space-y-1.5">
                    <p className="text-xs font-semibold text-white">Q: {faq.question}</p>
                    <p className="text-xs text-slate-400 leading-relaxed">A: {faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
