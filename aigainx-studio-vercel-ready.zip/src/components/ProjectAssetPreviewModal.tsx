import React, { useState } from 'react';
import { 
  X, 
  Download, 
  ExternalLink, 
  FileText, 
  Figma, 
  Code2, 
  Layers, 
  ShieldCheck, 
  Copy, 
  Check, 
  Sparkles, 
  Layout, 
  Compass, 
  Cpu, 
  Maximize2, 
  Clock, 
  User, 
  FileCode, 
  CheckCircle2, 
  ArrowRight,
  Eye,
  Smartphone,
  Monitor,
  Palette
} from 'lucide-react';
import { ProjectAsset, SitemapNode, DesignTokenItem, CodeSnippetItem } from '../types';

interface ProjectAssetPreviewModalProps {
  asset: ProjectAsset | null;
  onClose: () => void;
  onShowToast?: (title: string, desc: string, type?: 'success' | 'info') => void;
}

export const ProjectAssetPreviewModal: React.FC<ProjectAssetPreviewModalProps> = ({
  asset,
  onClose,
  onShowToast
}) => {
  const [activeViewMode, setActiveViewMode] = useState<'preview' | 'specs' | 'code'>('preview');
  const [selectedSnippetIdx, setSelectedSnippetIdx] = useState(0);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const [devicePreviewMode, setDevicePreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  if (!asset) return null;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    if (onShowToast) {
      onShowToast('Copied to Clipboard', `${label}: ${text}`, 'info');
    }
  };

  const handleCopyToken = (tokenValue: string, tokenName: string) => {
    handleCopy(tokenValue, tokenName);
    setCopiedToken(tokenName);
    setTimeout(() => setCopiedToken(null), 2000);
  };

  const handleCopyCodeSnippet = (code: string) => {
    handleCopy(code, 'Code snippet');
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadAsset = () => {
    if (onShowToast) {
      onShowToast(
        'Asset Package Ready',
        `Preparing download for "${asset.title}" (${asset.fileSize}) with client IP certificate.`,
        'success'
      );
    }
  };

  const getFormatIcon = () => {
    switch (asset.format) {
      case 'figma':
        return <Figma className="w-4 h-4 text-purple-400" />;
      case 'sitemap':
        return <Compass className="w-4 h-4 text-cyan-400" />;
      case 'wireframe':
        return <Layout className="w-4 h-4 text-amber-400" />;
      case 'typescript':
        return <Code2 className="w-4 h-4 text-emerald-400" />;
      case 'pdf':
        return <FileText className="w-4 h-4 text-rose-400" />;
      case 'svg':
        return <Palette className="w-4 h-4 text-yellow-400" />;
      default:
        return <FileCode className="w-4 h-4 text-blue-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-5xl max-h-[92vh] flex flex-col rounded-2xl bg-[#0b0e14] border border-slate-700/90 shadow-2xl shadow-black text-slate-100 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header Bar */}
        <div className="px-5 py-4 bg-slate-900/90 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${asset.thumbnailGradient} p-0.5 flex items-center justify-center shadow-md shrink-0`}>
              <div className="w-full h-full bg-slate-950/80 rounded-[10px] flex items-center justify-center">
                {getFormatIcon()}
              </div>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-display font-bold text-white text-base truncate max-w-md">
                  {asset.title}
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase bg-blue-950 text-blue-300 border border-blue-800">
                  {asset.version}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase ${
                  asset.status === 'approved' 
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                    : asset.status === 'ready' 
                    ? 'bg-blue-950 text-blue-300 border border-blue-800'
                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  {asset.status.replace('_', ' ')}
                </span>
              </div>

              <div className="flex items-center gap-3 text-xs text-slate-400 font-mono-code mt-0.5">
                <span className="text-slate-300 font-semibold">{asset.projectTitle}</span>
                <span>·</span>
                <span>{asset.projectId}</span>
                <span>·</span>
                <span>Size: <strong className="text-slate-200">{asset.fileSize}</strong></span>
              </div>
            </div>
          </div>

          {/* Quick Actions & Close */}
          <div className="flex items-center gap-2 self-end sm:self-auto">
            {/* View Mode Switcher */}
            <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800 text-xs font-mono-code">
              <button
                onClick={() => setActiveViewMode('preview')}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  activeViewMode === 'preview' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Interactive Preview
              </button>
              <button
                onClick={() => setActiveViewMode('specs')}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  activeViewMode === 'specs' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Metadata & Specs
              </button>
              {asset.previewContent.codeSnippets && (
                <button
                  onClick={() => setActiveViewMode('code')}
                  className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                    activeViewMode === 'code' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Source Code
                </button>
              )}
            </div>

            <button
              onClick={handleDownloadAsset}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Download asset package with IP Certificate"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden md:inline font-mono-code">Export</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              aria-label="Close preview"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Container */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
          
          {/* TAB: INTERACTIVE PREVIEW */}
          {activeViewMode === 'preview' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Asset Description Summary Banner */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 font-mono-code text-xs">
                <div className="space-y-1 max-w-2xl">
                  <span className="text-[10px] text-blue-400 uppercase tracking-wider font-bold block">
                    Deliverable Overview:
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {asset.previewContent.summary}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {asset.tags.map((tag, i) => (
                    <span key={i} className="px-2 py-1 rounded bg-slate-950 border border-slate-800 text-slate-400 text-[11px]">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* 1. SITEMAP PREVIEW */}
              {asset.format === 'sitemap' && asset.previewContent.sitemapNodes && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display font-bold text-white text-sm flex items-center gap-2">
                      <Compass className="w-4 h-4 text-cyan-400" />
                      <span>Interactive Information Architecture Tree</span>
                    </h4>
                    <span className="text-xs text-slate-400 font-mono-code">
                      {asset.previewContent.sitemapNodes.length} Main Page Nodes
                    </span>
                  </div>

                  <div className="space-y-3 font-mono-code">
                    {asset.previewContent.sitemapNodes.map((node: SitemapNode, idx: number) => (
                      <div 
                        key={node.id}
                        className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/90 hover:border-cyan-500/40 transition-all space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="w-6 h-6 rounded-md bg-cyan-950/80 border border-cyan-700/80 text-cyan-300 font-bold text-xs flex items-center justify-center">
                              0{idx + 1}
                            </span>
                            <span className="font-bold text-white text-sm">{node.page}</span>
                            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyan-400 text-xs">
                              {node.route}
                            </span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-[11px] text-slate-400">
                              {node.componentsCount} Key UI Modules
                            </span>
                            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-950 text-emerald-400 border border-emerald-800">
                              {node.status}
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-slate-300">
                          {node.description}
                        </p>

                        {/* Child Sub-Routes */}
                        {node.children && node.children.length > 0 && (
                          <div className="pl-4 border-l-2 border-slate-800 space-y-2 pt-1">
                            <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">
                              Sub-Sections & Route Handlers:
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {node.children.map((child, cIdx) => (
                                <div key={cIdx} className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-850 text-xs">
                                  <div className="flex items-center justify-between">
                                    <span className="text-white font-semibold">{child.page}</span>
                                    <span className="text-blue-400 text-[11px]">{child.route}</span>
                                  </div>
                                  <p className="text-[11px] text-slate-400 mt-1">{child.description}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 2. FIGMA & DESIGN SYSTEM PREVIEW */}
              {asset.format === 'figma' && (
                <div className="space-y-6">
                  {/* Master Design Tokens Grid */}
                  {asset.previewContent.designTokens && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-display font-bold text-white text-sm flex items-center gap-2">
                          <Palette className="w-4 h-4 text-purple-400" />
                          <span>Design System Tokens & Palette Variables</span>
                        </h4>
                        <span className="text-xs text-slate-400 font-mono-code">
                          Click any token to copy value
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 font-mono-code text-xs">
                        {asset.previewContent.designTokens.map((token: DesignTokenItem, i: number) => {
                          const isCopied = copiedToken === token.name;
                          const isColor = token.category === 'color';

                          return (
                            <button
                              key={i}
                              onClick={() => handleCopyToken(token.value, token.name)}
                              className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-purple-500/50 text-left transition-all group cursor-pointer relative overflow-hidden"
                            >
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-[10px] text-purple-400 uppercase tracking-wider font-bold">
                                  {token.category}
                                </span>
                                {isCopied ? (
                                  <span className="text-emerald-400 text-[10px] flex items-center gap-1">
                                    <Check className="w-3 h-3" />
                                    <span>Copied</span>
                                  </span>
                                ) : (
                                  <Copy className="w-3 h-3 text-slate-500 group-hover:text-purple-400 transition-colors" />
                                )}
                              </div>

                              <div className="flex items-center gap-2.5 mb-1.5">
                                {isColor && (
                                  <div 
                                    className="w-5 h-5 rounded-md border border-white/20 shrink-0 shadow-inner"
                                    style={{ backgroundColor: token.value }}
                                  />
                                )}
                                <span className="text-white font-bold truncate text-xs">{token.value}</span>
                              </div>

                              <span className="text-[10px] text-slate-400 block truncate">{token.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* Figma Frames & Layout Specifications */}
                  {asset.previewContent.figmaFrames && (
                    <div className="space-y-3">
                      <h4 className="font-display font-bold text-white text-sm flex items-center gap-2">
                        <Figma className="w-4 h-4 text-purple-400" />
                        <span>Master Viewport Layout Frames</span>
                      </h4>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono-code text-xs">
                        {asset.previewContent.figmaFrames.map((frame, fIdx) => (
                          <div key={fIdx} className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-white text-sm">{frame.name}</span>
                              <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 text-[10px]">
                                {frame.dimensions}
                              </span>
                            </div>
                            <span className="text-slate-400 text-xs block">{frame.type}</span>
                            <p className="text-slate-300 text-xs">{frame.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 3. WIREFRAME & INTERACTIVE BLUEPRINT */}
              {asset.format === 'wireframe' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-display font-bold text-white text-sm flex items-center gap-2">
                      <Layout className="w-4 h-4 text-amber-400" />
                      <span>UX Flow & Interactive Hotspot Blueprint</span>
                    </h4>

                    {/* Viewport toggle */}
                    <div className="flex bg-slate-900 p-0.5 rounded-lg border border-slate-800 text-xs font-mono-code">
                      <button
                        onClick={() => setDevicePreviewMode('desktop')}
                        className={`px-2.5 py-1 rounded flex items-center gap-1 cursor-pointer ${
                          devicePreviewMode === 'desktop' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <Monitor className="w-3.5 h-3.5" />
                        <span>Desktop</span>
                      </button>
                      <button
                        onClick={() => setDevicePreviewMode('mobile')}
                        className={`px-2.5 py-1 rounded flex items-center gap-1 cursor-pointer ${
                          devicePreviewMode === 'mobile' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        <span>Mobile</span>
                      </button>
                    </div>
                  </div>

                  {/* Wireframe Canvas Mock */}
                  <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 relative min-h-[320px] flex flex-col justify-between overflow-hidden shadow-inner">
                    {/* Simulated Wireframe Blocks */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 opacity-80 pointer-events-none">
                      <div className="h-28 rounded-xl bg-slate-900/90 border border-dashed border-slate-700 flex items-center justify-center text-slate-500 font-mono-code text-xs">
                        Hero Video & Value Proposition
                      </div>
                      <div className="h-28 rounded-xl bg-slate-900/90 border border-dashed border-slate-700 flex items-center justify-center text-slate-500 font-mono-code text-xs">
                        Interactive Property Selector
                      </div>
                      <div className="h-28 rounded-xl bg-slate-900/90 border border-dashed border-slate-700 flex items-center justify-center text-slate-500 font-mono-code text-xs">
                        VIP WhatsApp Conversion Gate
                      </div>
                    </div>

                    {/* Interactive Hotspots */}
                    {asset.previewContent.interactiveHotspots && (
                      <div className="mt-6 space-y-3 font-mono-code">
                        <span className="text-[10px] text-amber-400 uppercase tracking-wider font-bold block">
                          Conversion Engineered Touchpoints:
                        </span>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {asset.previewContent.interactiveHotspots.map((hs, i) => (
                            <div 
                              key={i}
                              className="p-3 rounded-xl bg-slate-900/90 border border-amber-600/40 text-xs space-y-1 hover:bg-slate-850 transition-colors"
                            >
                              <div className="flex items-center gap-2">
                                <span className="w-5 h-5 rounded-full bg-amber-500/20 border border-amber-400 text-amber-300 font-bold flex items-center justify-center text-[10px]">
                                  {i + 1}
                                </span>
                                <span className="font-bold text-white text-xs">{hs.label}</span>
                              </div>
                              <p className="text-slate-300 text-[11px] leading-relaxed">{hs.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* 4. DOCUMENT & CONTRACT VIEWER */}
              {asset.format === 'pdf' && asset.previewContent.docSections && (
                <div className="space-y-4">
                  <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800 space-y-5">
                    {/* Document Header with Dubai DED Verification */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                      <div>
                        <span className="text-[10px] font-mono-code text-blue-400 uppercase tracking-wider font-bold block">
                          Official UAE Commercial Document
                        </span>
                        <h4 className="font-display font-bold text-white text-base">
                          {asset.title}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2 font-mono-code text-[11px] bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-700 text-emerald-300">
                        <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>DED Entity Licence #1646775 Verified</span>
                      </div>
                    </div>

                    {/* Clauses */}
                    <div className="space-y-4 text-xs font-mono-code">
                      {asset.previewContent.docSections.map((sec, sIdx) => (
                        <div key={sIdx} className="space-y-2">
                          <h5 className="text-slate-200 font-bold text-sm">
                            {sec.title}
                          </h5>
                          {sec.paragraphs.map((p, pIdx) => (
                            <p key={pIdx} className="text-slate-300 leading-relaxed">
                              {p}
                            </p>
                          ))}
                          {sec.callout && (
                            <div className="p-3 rounded-xl bg-blue-950/50 border border-blue-800 text-blue-200 font-semibold">
                              ✓ {sec.callout}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Signature Seal Block */}
                    <div className="pt-4 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono-code text-xs">
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">EXECUTED BY STUDIO:</span>
                        <span className="text-white font-bold block mt-0.5">AIGAINX Web-Design Studio Dubai</span>
                        <span className="text-[10px] text-emerald-400">Digital Seal & TRN Authenticated</span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">CLIENT ASSIGNEE:</span>
                        <span className="text-white font-bold block mt-0.5">{asset.projectTitle}</span>
                        <span className="text-[10px] text-blue-400">Full IP Ownership Rights Granted</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: METADATA & SPECS */}
          {activeViewMode === 'specs' && (
            <div className="space-y-4 animate-in fade-in duration-200 font-mono-code text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <h4 className="font-display font-bold text-white text-sm">Asset Technical Metadata</h4>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between py-1.5 border-b border-slate-850">
                      <span className="text-slate-400">Asset Identifier:</span>
                      <span className="text-blue-400 font-bold">{asset.id}</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-850">
                      <span className="text-slate-400">Project:</span>
                      <span className="text-white">{asset.projectTitle} ({asset.projectId})</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-850">
                      <span className="text-slate-400">Category / Type:</span>
                      <span className="text-slate-200 capitalize">{asset.category} ({asset.format.toUpperCase()})</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-850">
                      <span className="text-slate-400">Version:</span>
                      <span className="text-emerald-400 font-bold">{asset.version}</span>
                    </div>
                    <div className="flex justify-between py-1.5 border-b border-slate-850">
                      <span className="text-slate-400">Package Size:</span>
                      <span className="text-white">{asset.fileSize}</span>
                    </div>
                    <div className="flex justify-between py-1.5">
                      <span className="text-slate-400">Author / Architect:</span>
                      <span className="text-slate-200">{asset.author}</span>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <h4 className="font-display font-bold text-white text-sm">Project Specifications</h4>
                  
                  {asset.previewContent.metaDetails ? (
                    <div className="space-y-2">
                      {asset.previewContent.metaDetails.map((meta, mIdx) => (
                        <div key={mIdx} className="flex justify-between py-1.5 border-b border-slate-850">
                          <span className="text-slate-400">{meta.label}:</span>
                          <span className="text-slate-200 font-semibold text-right max-w-xs">{meta.value}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-400">Standard Dubai Studio production specifications apply.</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB: CODE SNIPPETS */}
          {activeViewMode === 'code' && asset.previewContent.codeSnippets && (
            <div className="space-y-4 animate-in fade-in duration-200 font-mono-code text-xs">
              {/* File Selector Tabs */}
              <div className="flex items-center justify-between bg-slate-900 p-1 rounded-xl border border-slate-800">
                <div className="flex items-center gap-1 overflow-x-auto">
                  {asset.previewContent.codeSnippets.map((snippet: CodeSnippetItem, idx: number) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedSnippetIdx(idx)}
                      className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer text-xs font-semibold ${
                        selectedSnippetIdx === idx
                          ? 'bg-blue-600 text-white'
                          : 'text-slate-400 hover:text-white hover:bg-slate-800'
                      }`}
                    >
                      {snippet.filename}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => handleCopyCodeSnippet(asset.previewContent.codeSnippets![selectedSnippetIdx].code)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1.5 cursor-pointer text-xs shrink-0"
                >
                  {copiedCode ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>

              {/* Code Box */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 overflow-x-auto text-slate-200 leading-relaxed font-mono">
                <pre>{asset.previewContent.codeSnippets[selectedSnippetIdx].code}</pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer Bar with Download & Status */}
        <div className="px-5 py-3.5 bg-slate-900/90 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 font-mono-code text-xs shrink-0">
          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>100% Unconditional IP Handover · Direct Client License Granted</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadAsset}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/30 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Full Asset Package</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
