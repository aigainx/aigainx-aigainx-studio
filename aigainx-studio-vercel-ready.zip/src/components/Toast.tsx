import React, { useEffect } from 'react';
import { CheckCircle2, ShieldCheck, X, Clock, Sparkles, TrendingUp, Info } from 'lucide-react';

export interface ToastMessage {
  id: string;
  title: string;
  description: string;
  type?: 'success' | 'info' | 'milestone';
  timestamp?: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div 
      aria-live="polite" 
      aria-atomic="true"
      className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-md w-[calc(100vw-3rem)] pointer-events-none"
    >
      {toasts.map((toast) => (
        <ToastItem key={toast.id} toast={toast} onDismiss={onDismiss} />
      ))}
    </div>
  );
};

const ToastItem: React.FC<{ toast: ToastMessage; onDismiss: (id: string) => void }> = ({ toast, onDismiss }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 6500);
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const isMilestone = toast.title.toLowerCase().includes('milestone');

  return (
    <div 
      className={`pointer-events-auto rounded-2xl bg-[#0b0f17]/95 backdrop-blur-md border p-4 sm:p-5 shadow-2xl text-white animate-in slide-in-from-bottom-5 duration-300 relative overflow-hidden ${
        isMilestone
          ? 'border-blue-500/60 shadow-blue-900/30'
          : 'border-emerald-500/40 shadow-black/80'
      }`}
      role="status"
    >
      {/* Accent top gradient line */}
      <div 
        className={`absolute top-0 left-0 right-0 h-1 ${
          isMilestone
            ? 'bg-gradient-to-r from-blue-500 via-indigo-400 to-cyan-400'
            : 'bg-gradient-to-r from-emerald-500 via-teal-400 to-blue-500'
        }`} 
      />

      <div className="flex items-start gap-3.5">
        <div 
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 border ${
            isMilestone
              ? 'bg-blue-950/90 border-blue-600/70 text-blue-400 shadow-md shadow-blue-500/20'
              : 'bg-emerald-950/80 border-emerald-600/60 text-emerald-400'
          }`}
        >
          {isMilestone ? (
            <TrendingUp className="w-5 h-5 animate-pulse" />
          ) : (
            <CheckCircle2 className="w-5 h-5" />
          )}
        </div>

        <div className="flex-1 space-y-1">
          <div className="flex items-center justify-between gap-2">
            <h4 className="font-display text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
              <span>{toast.title}</span>
            </h4>
            <button
              onClick={() => onDismiss(toast.id)}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Dismiss notification"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed font-mono-code">
            {toast.description}
          </p>

          <div className="pt-2 flex items-center justify-between text-[10px] font-mono-code text-slate-400 border-t border-slate-800/80 mt-2">
            <span className={`flex items-center gap-1 font-bold ${isMilestone ? 'text-blue-400' : 'text-emerald-400'}`}>
              <Sparkles className="w-3 h-3" />
              <span>AIGAINX Dubai Dispatch</span>
            </span>
            <span className="flex items-center gap-1 text-slate-400">
              <Clock className="w-3 h-3 text-blue-400" />
              <span>Real-time Sync</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
