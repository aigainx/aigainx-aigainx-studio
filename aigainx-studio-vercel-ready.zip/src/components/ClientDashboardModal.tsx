import React, { useState, useMemo, useEffect } from 'react';
import { 
  X, 
  Layers, 
  FileText, 
  CreditCard, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Download, 
  ExternalLink, 
  Building2, 
  MessageSquare, 
  ShieldCheck, 
  ArrowRight,
  FolderGit2,
  Lock,
  Search,
  Eye,
  Filter,
  Sparkles,
  RefreshCw,
  BarChart3,
  TrendingUp,
  HelpCircle,
  BellRing,
  Radio,
  Figma,
  Code2,
  Compass,
  Layout,
  Palette,
  FolderArchive,
  FileCode,
  Check
} from 'lucide-react';
import { 
  ClientProject, 
  QuoteRecord, 
  InvoiceRecord, 
  PaymentRecord,
  ProjectAsset,
  ProjectAssetCategory
} from '../types';
import { 
  getStoredProjects, 
  getStoredQuotes, 
  getStoredInvoices, 
  getStoredPayments,
  updateProjectMilestoneInStore,
  MILESTONE_UPDATE_EVENT,
  MilestoneUpdateDetail,
  PAYMENT_OPTIONS_CATALOG,
  UAE_BANK_DETAILS 
} from '../data/paymentData';
import { 
  getStoredProjectAssets, 
  saveProjectAsset, 
  createDefaultAssetsForProject 
} from '../data/projectAssetsData';
import { BRAND_CONFIG, PROCESS_STEPS } from '../data/portalData';
import { ClientAnalyticsChart } from './ClientAnalyticsChart';
import { ClientSupportHelp } from './ClientSupportHelp';
import { ProjectProgressTracker } from './ProjectProgressTracker';
import { ProjectAssetPreviewModal } from './ProjectAssetPreviewModal';

interface ClientDashboardModalProps {
  onClose: () => void;
  onOpenCheckout: (packageId?: string) => void;
  onViewInvoice: (invoice: InvoiceRecord) => void;
  onShowToast?: (title: string, desc: string, type?: 'success' | 'info') => void;
}

export const ClientDashboardModal: React.FC<ClientDashboardModalProps> = ({
  onClose,
  onOpenCheckout,
  onViewInvoice,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'projects' | 'assets' | 'quotes' | 'invoices' | 'payments' | 'methods' | 'support'>('projects');
  const [showChartInProjectsTab, setShowChartInProjectsTab] = useState(true);
  
  // Search query state
  const [searchQuery, setSearchQuery] = useState('');
  
  // Data from hydrated local storage
  const [projects, setProjects] = useState<ClientProject[]>(() => getStoredProjects());
  const [quotes] = useState<QuoteRecord[]>(() => getStoredQuotes());
  const [invoices] = useState<InvoiceRecord[]>(() => getStoredInvoices());
  const [payments] = useState<PaymentRecord[]>(() => getStoredPayments());
  
  // Project Assets state
  const [assets, setAssets] = useState<ProjectAsset[]>(() => {
    const loaded = getStoredProjectAssets();
    return loaded;
  });
  const [selectedAssetForPreview, setSelectedAssetForPreview] = useState<ProjectAsset | null>(null);
  const [selectedProjectAssetFilter, setSelectedProjectAssetFilter] = useState<string>('all');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<'all' | ProjectAssetCategory>('all');

  // Real-time notification badge state
  const [recentNotification, setRecentNotification] = useState<MilestoneUpdateDetail | null>(null);
  const [updatedProjectId, setUpdatedProjectId] = useState<string | null>(null);

  // Real-time Event Listener for Admin Milestone Updates
  useEffect(() => {
    const handleMilestoneUpdate = (event: Event) => {
      const customEvt = event as CustomEvent<MilestoneUpdateDetail>;
      if (!customEvt.detail) return;

      const detail = customEvt.detail;
      // 1. Refresh Projects State Immediately
      const latestProjects = getStoredProjects();
      setProjects(latestProjects);

      // Refresh Assets if needed
      const latestAssets = getStoredProjectAssets();
      setAssets(latestAssets);

      // 2. Set recent notification alert & trigger pulsing highlight
      setRecentNotification(detail);
      setUpdatedProjectId(detail.project.id);

      // 3. Fire real-time Toast Notification
      if (onShowToast) {
        onShowToast(
          `⚡ Project Milestone Updated: Step ${detail.newStep} (${detail.milestoneName})`,
          `"${detail.project.title}" (${detail.project.id}) has been advanced by AIGAINX Studio Engineering. Velocity is now ${detail.project.progressPercent}%.`,
          'success'
        );
      }

      // Auto-clear pulsing highlight after 6 seconds
      setTimeout(() => {
        setUpdatedProjectId(null);
      }, 6000);
    };

    // Cross-tab storage change handler
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'aigainx_projects_store') {
        const refreshed = getStoredProjects();
        setProjects(refreshed);
      }
      if (e.key === 'aigainx_project_assets_store') {
        const refreshedAssets = getStoredProjectAssets();
        setAssets(refreshedAssets);
      }
    };

    window.addEventListener(MILESTONE_UPDATE_EVENT, handleMilestoneUpdate);
    window.addEventListener('storage', handleStorageChange);

    return () => {
      window.removeEventListener(MILESTONE_UPDATE_EVENT, handleMilestoneUpdate);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [onShowToast]);

  // Client Simulation Trigger (Allows test user / client to simulate an admin updating milestone)
  const handleSimulateAdminAdvance = (projectId: string) => {
    const targetPrj = projects.find(p => p.id === projectId);
    if (!targetPrj) return;
    const nextStep = targetPrj.currentStep >= 8 ? 1 : targetPrj.currentStep + 1;
    
    // Calls store function which will dispatch MILESTONE_UPDATE_EVENT and trigger real-time toast
    updateProjectMilestoneInStore(
      projectId, 
      nextStep, 
      undefined, 
      `Live verification completed by Dubai Studio Lead. Advanced to Step ${nextStep}.`
    );
  };
  
  const [paymentFilter, setPaymentFilter] = useState<'all' | 'paid' | 'manual_verification' | 'pending'>('all');

  const normalizedQuery = searchQuery.trim().toLowerCase();

  // Filtered Projects
  const filteredProjects = useMemo(() => {
    if (!normalizedQuery) return projects;
    return projects.filter((p) => 
      p.title.toLowerCase().includes(normalizedQuery) ||
      p.id.toLowerCase().includes(normalizedQuery) ||
      p.orderId.toLowerCase().includes(normalizedQuery) ||
      p.companyName.toLowerCase().includes(normalizedQuery) ||
      p.clientName.toLowerCase().includes(normalizedQuery) ||
      p.packageName.toLowerCase().includes(normalizedQuery) ||
      p.assignedLead.toLowerCase().includes(normalizedQuery)
    );
  }, [projects, normalizedQuery]);

  // Filtered Project Assets
  const filteredAssets = useMemo(() => {
    let list = assets;
    if (selectedProjectAssetFilter !== 'all') {
      list = list.filter((a) => a.projectId === selectedProjectAssetFilter);
    }
    if (selectedCategoryFilter !== 'all') {
      list = list.filter((a) => a.category === selectedCategoryFilter);
    }
    if (!normalizedQuery) return list;
    return list.filter((a) => 
      a.title.toLowerCase().includes(normalizedQuery) ||
      a.id.toLowerCase().includes(normalizedQuery) ||
      a.projectId.toLowerCase().includes(normalizedQuery) ||
      a.projectTitle.toLowerCase().includes(normalizedQuery) ||
      a.format.toLowerCase().includes(normalizedQuery) ||
      a.category.toLowerCase().includes(normalizedQuery) ||
      a.author.toLowerCase().includes(normalizedQuery) ||
      a.description.toLowerCase().includes(normalizedQuery) ||
      a.tags.some(t => t.toLowerCase().includes(normalizedQuery))
    );
  }, [assets, selectedProjectAssetFilter, selectedCategoryFilter, normalizedQuery]);

  // Filtered Quotes
  const filteredQuotes = useMemo(() => {
    if (!normalizedQuery) return quotes;
    return quotes.filter((q) => 
      q.quoteNumber.toLowerCase().includes(normalizedQuery) ||
      q.id.toLowerCase().includes(normalizedQuery) ||
      q.projectType.toLowerCase().includes(normalizedQuery) ||
      q.companyName.toLowerCase().includes(normalizedQuery) ||
      q.clientName.toLowerCase().includes(normalizedQuery) ||
      q.packageName.toLowerCase().includes(normalizedQuery)
    );
  }, [quotes, normalizedQuery]);

  // Filtered Invoices
  const filteredInvoices = useMemo(() => {
    if (!normalizedQuery) return invoices;
    return invoices.filter((inv) => 
      inv.invoiceNumber.toLowerCase().includes(normalizedQuery) ||
      inv.orderId.toLowerCase().includes(normalizedQuery) ||
      (inv.paymentReference && inv.paymentReference.toLowerCase().includes(normalizedQuery)) ||
      (inv.quoteNumber && inv.quoteNumber.toLowerCase().includes(normalizedQuery)) ||
      inv.clientName.toLowerCase().includes(normalizedQuery) ||
      inv.companyName.toLowerCase().includes(normalizedQuery) ||
      inv.items.some(item => item.description.toLowerCase().includes(normalizedQuery))
    );
  }, [invoices, normalizedQuery]);

  // Filtered Payments
  const filteredPayments = useMemo(() => {
    let list = payments;
    if (paymentFilter !== 'all') {
      list = list.filter((p) => p.status === paymentFilter);
    }
    if (!normalizedQuery) return list;
    return list.filter((pay) => 
      pay.id.toLowerCase().includes(normalizedQuery) ||
      pay.referenceId.toLowerCase().includes(normalizedQuery) ||
      pay.orderId.toLowerCase().includes(normalizedQuery) ||
      pay.invoiceNumber.toLowerCase().includes(normalizedQuery) ||
      pay.projectName.toLowerCase().includes(normalizedQuery) ||
      pay.companyName.toLowerCase().includes(normalizedQuery) ||
      pay.clientName.toLowerCase().includes(normalizedQuery) ||
      pay.provider.toLowerCase().includes(normalizedQuery) ||
      (pay.transactionHash && pay.transactionHash.toLowerCase().includes(normalizedQuery))
    );
  }, [payments, paymentFilter, normalizedQuery]);

  // Total matching count across all searchable categories
  const totalMatches = useMemo(() => {
    if (!normalizedQuery) return 0;
    return filteredProjects.length + filteredAssets.length + filteredInvoices.length + filteredPayments.length + filteredQuotes.length;
  }, [normalizedQuery, filteredProjects.length, filteredAssets.length, filteredInvoices.length, filteredPayments.length, filteredQuotes.length]);

  const quickSearchSuggestions = [
    'ORD-8491',
    'AIGX-REF-8491',
    'INV-2026-001',
    'Real Estate',
    'PRJ-4821',
    'Stripe'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl my-6 bg-[#0c1018] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-200 flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="p-5 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-base font-bold text-white tracking-wide">
                  AIGAINX CLIENT AREA
                </h2>
                <span className="text-[10px] font-mono-code px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-300">
                  Dubai Studio Portal
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono-code">
                Repository Deliverables · Invoices · Milestone Tracking
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Global Search Bar Section */}
        <div className="px-6 py-3.5 bg-slate-950/90 border-b border-slate-800/80 shrink-0 space-y-2.5">
          <div className="relative flex items-center">
            <Search className="w-4 h-4 text-blue-400 absolute left-3.5 pointer-events-none" />
            <input
              id="client-dashboard-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Reference ID (e.g. AIGX-REF-8491), Project name, Invoice # (e.g. AIGX-INV-2026-001), or Order ID..."
              className="w-full pl-10 pr-10 py-2 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-xs text-white placeholder:text-slate-500 transition-all font-mono-code outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Quick Search Chips & Search Status */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono-code">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-slate-500 text-[10px]">Quick search:</span>
              {quickSearchSuggestions.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSearchQuery(tag)}
                  className={`px-2 py-0.5 rounded-md border text-[10px] transition-all cursor-pointer ${
                    normalizedQuery === tag.toLowerCase()
                      ? 'bg-blue-900/80 border-blue-500 text-blue-200 font-semibold'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>

            {searchQuery && (
              <div className="flex items-center gap-1 text-emerald-400 bg-emerald-950/40 border border-emerald-800/60 px-2 py-0.5 rounded-md text-[10px]">
                <span>{totalMatches} {totalMatches === 1 ? 'match' : 'matches'} found</span>
              </div>
            )}
          </div>

          {/* Live Multi-Category Match Summary Bar when searching */}
          {searchQuery && (
            <div className="p-2.5 rounded-xl bg-slate-900/90 border border-blue-900/50 flex flex-wrap items-center justify-between gap-2 text-xs font-mono-code">
              <div className="flex items-center gap-2">
                <Filter className="w-3.5 h-3.5 text-blue-400" />
                <span className="text-slate-300 text-[11px]">
                  Filtered results for: <strong className="text-white">"{searchQuery}"</strong>
                </span>
              </div>

              <div className="flex items-center gap-2 flex-wrap text-[11px]">
                <button
                  onClick={() => setActiveTab('projects')}
                  className={`px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    activeTab === 'projects'
                      ? 'bg-blue-600 border-blue-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Projects ({filteredProjects.length})
                </button>

                <button
                  onClick={() => setActiveTab('projects')}
                  className={`px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    activeTab === 'projects'
                      ? 'bg-blue-600 border-blue-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Projects ({filteredProjects.length})
                </button>

                <button
                  onClick={() => setActiveTab('assets')}
                  className={`px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    activeTab === 'assets'
                      ? 'bg-blue-600 border-blue-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Assets ({filteredAssets.length})
                </button>

                <button
                  onClick={() => setActiveTab('invoices')}
                  className={`px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    activeTab === 'invoices'
                      ? 'bg-blue-600 border-blue-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Invoices ({filteredInvoices.length})
                </button>

                <button
                  onClick={() => setActiveTab('payments')}
                  className={`px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    activeTab === 'payments'
                      ? 'bg-blue-600 border-blue-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Payments ({filteredPayments.length})
                </button>

                <button
                  onClick={() => setActiveTab('quotes')}
                  className={`px-2 py-0.5 rounded-md border transition-all cursor-pointer ${
                    activeTab === 'quotes'
                      ? 'bg-blue-600 border-blue-400 text-white font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Quotes ({filteredQuotes.length})
                </button>

                <button
                  onClick={() => setSearchQuery('')}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] cursor-pointer"
                >
                  Reset
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Tab Navigation */}
        <div className="px-6 py-2 bg-[#090d14] border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0 text-xs font-mono-code">
          <button
            onClick={() => setActiveTab('analytics')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'analytics'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Milestones & Spend</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800">
              Live Chart
            </span>
          </button>

          <button
            onClick={() => setActiveTab('projects')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'projects'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>My Projects</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'projects' ? 'bg-blue-800 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              {filteredProjects.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('assets')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'assets'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <FolderGit2 className="w-3.5 h-3.5 text-blue-400" />
            <span>Project Assets</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'assets' ? 'bg-blue-800 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              {filteredAssets.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('quotes')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'quotes'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>Quotes</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'quotes' ? 'bg-blue-800 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              {filteredQuotes.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('invoices')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'invoices'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>Invoices & Receipts</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'invoices' ? 'bg-blue-800 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              {filteredInvoices.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'payments'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>Payments History</span>
            <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              activeTab === 'payments' ? 'bg-blue-800 text-white' : 'bg-slate-800 text-slate-400'
            }`}>
              {filteredPayments.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('methods')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'methods'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Payment Methods
          </button>

          <button
            onClick={() => setActiveTab('support')}
            className={`px-3 py-1.5 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'support'
                ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
            <span>Support & Help</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-blue-950 text-blue-300 border border-blue-800">
              FAQ
            </span>
          </button>
        </div>

        {/* Scrollable Main Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* TAB 0: MILESTONES & SPEND ANALYTICS DASHBOARD */}
          {activeTab === 'analytics' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-blue-400" />
                    <span>Project Milestones & Financial Analytics</span>
                  </h3>
                  <p className="text-xs text-slate-400 font-mono-code">
                    Real-time visualization of milestone progress, contract budget allocations, and settled payments.
                  </p>
                </div>

                <button
                  onClick={() => onOpenCheckout()}
                  className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/20 cursor-pointer self-start"
                >
                  <span>Start New Project</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Recharts Analytics Component */}
              <ClientAnalyticsChart 
                projects={filteredProjects}
                invoices={filteredInvoices}
                onSelectProject={(id) => {
                  setActiveTab('projects');
                }}
              />
            </div>
          )}

          {/* TAB 1: MY PROJECTS */}
          {activeTab === 'projects' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Real-time Event Stream Indicator & Live Sync Banner */}
              <div className="p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900/80 to-slate-950 border border-blue-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono-code shadow-lg shadow-blue-950/20">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-blue-900/60 border border-blue-700 flex items-center justify-center text-blue-400 shrink-0">
                    <Radio className="w-4 h-4 animate-pulse" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">Live Milestone Event Stream</span>
                      <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-bold bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                        <span>Connected (Dubai Studio Node)</span>
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-0.5">
                      Client portal actively synchronized with Admin Engineering Dispatch for zero-latency milestone updates.
                    </p>
                  </div>
                </div>

                {recentNotification && (
                  <div className="flex items-center gap-2 bg-blue-900/40 border border-blue-600/60 px-3 py-1.5 rounded-xl text-blue-200 text-[11px] animate-in fade-in slide-in-from-right-3">
                    <BellRing className="w-3.5 h-3.5 text-blue-400 shrink-0 animate-bounce" />
                    <span className="truncate max-w-xs">
                      Latest: <strong>Step {recentNotification.newStep} ({recentNotification.milestoneName})</strong>
                    </span>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                    <span>Active Client Projects & Milestone Tracking</span>
                    {searchQuery && (
                      <span className="text-xs font-mono-code font-normal text-blue-400">
                        ({filteredProjects.length} matches)
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Live delivery monitoring adhering strictly to our 8-step engineering architecture.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowChartInProjectsTab(!showChartInProjectsTab)}
                    className="py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-mono-code text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
                  >
                    <BarChart3 className="w-3.5 h-3.5 text-blue-400" />
                    <span>{showChartInProjectsTab ? 'Hide Analytics Chart' : 'Show Analytics Chart'}</span>
                  </button>

                  <button
                    onClick={() => onOpenCheckout()}
                    className="py-2 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/20 cursor-pointer self-start"
                  >
                    <span>Start New Project</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Embedded Visual Analytics Chart inside Projects Tab */}
              {showChartInProjectsTab && filteredProjects.length > 0 && (
                <div className="pb-2">
                  <ClientAnalyticsChart 
                    projects={filteredProjects}
                    invoices={filteredInvoices}
                  />
                </div>
              )}

              {filteredProjects.length === 0 ? (
                <div className="p-10 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-3">
                  <FolderGit2 className="w-8 h-8 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Projects Match "{searchQuery}"</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    We couldn't find any projects matching your search term across project titles, reference IDs, or order numbers.
                  </p>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono-code text-slate-200 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Clear Search Filter</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredProjects.map((project) => {
                    const isRecentlyUpdated = updatedProjectId === project.id;

                    return (
                      <div
                        key={project.id}
                        className={`p-5 rounded-2xl bg-gradient-to-b from-slate-900/90 to-[#0c1017] border space-y-4 transition-all duration-300 ${
                          isRecentlyUpdated
                            ? 'border-emerald-500 shadow-xl shadow-emerald-500/20 ring-2 ring-emerald-500/30'
                            : 'border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {/* Top Project Bar */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800 text-xs font-mono-code">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-white text-sm">{project.title}</span>
                            <span className="px-2 py-0.5 rounded bg-blue-950 border border-blue-800 text-blue-300 text-[10px]">
                              {project.id}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono-code">
                              · {project.companyName}
                            </span>

                            {isRecentlyUpdated && (
                              <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500 text-emerald-300 text-[10px] font-bold animate-pulse flex items-center gap-1">
                                <Sparkles className="w-3 h-3" />
                                <span>Live Milestone Update Just Received</span>
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-3 text-slate-400">
                            <span>Order: <strong className="text-white">{project.orderId}</strong></span>
                            <span>·</span>
                            <span>Lead: <strong className="text-slate-200">{project.assignedLead}</strong></span>
                          </div>
                        </div>

                        {/* 8-Step Project Progress Tracker Visual Indicator */}
                        <ProjectProgressTracker project={project} />

                        {/* Interactive Admin Advancement Simulation Control */}
                        <div className="p-3 rounded-xl bg-slate-950/90 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono-code">
                          <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                            <TrendingUp className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                            <span>
                              Test Real-Time Event System:
                            </span>
                          </div>

                          <button
                            onClick={() => handleSimulateAdminAdvance(project.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-900/60 hover:bg-blue-800 border border-blue-700/80 text-blue-200 hover:text-white font-semibold text-[11px] transition-all cursor-pointer shadow-sm active:scale-95"
                            title="Simulate Admin advancing this project's milestone to trigger real-time toast and progress update"
                          >
                            <Sparkles className="w-3 h-3 text-amber-400" />
                            <span>Simulate Admin Advance (Next Step)</span>
                          </button>
                        </div>

                        {/* Meta Row */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs font-mono-code">
                          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                            <span className="text-[10px] text-slate-500 block">Package Tier:</span>
                            <span className="text-slate-200 font-semibold">{project.packageName}</span>
                          </div>

                          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                            <span className="text-[10px] text-slate-500 block">Target Go-Live:</span>
                            <span className="text-white font-semibold">{project.targetDeliveryDate}</span>
                          </div>

                          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                            <span className="text-[10px] text-slate-500 block">Payment State:</span>
                            <span className={`font-semibold capitalize ${project.paymentStatus === 'paid' ? 'text-emerald-400' : 'text-amber-400'}`}>
                              {project.paymentStatus.replace('_', ' ')}
                            </span>
                          </div>

                          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80">
                            <span className="text-[10px] text-slate-500 block">Code Handover:</span>
                            <span className="text-blue-400 font-semibold">
                              {project.repositoryAccessGranted ? '✓ Repo Transferred' : 'Scheduled on QA'}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB: PROJECT ASSETS (DOCUMENTS, DESIGNS & CODE DELIVERABLES) */}
          {activeTab === 'assets' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Header & Global Export Action */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                    <FolderGit2 className="w-5 h-5 text-blue-400" />
                    <span>Project Assets, Design Systems & Handover Docs</span>
                    {searchQuery && (
                      <span className="text-xs font-mono-code font-normal text-blue-400">
                        ({filteredAssets.length} matches)
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono-code">
                    Centralized hub for Figma tokens, interactive sitemaps, executed contracts, and production source code.
                  </p>
                </div>

                <button
                  onClick={() => {
                    if (onShowToast) {
                      onShowToast(
                        'Full Asset Archive Generated',
                        `Compiled ${filteredAssets.length} project documents and design kits into encrypted .ZIP with Dubai DED IP certificate.`,
                        'success'
                      );
                    }
                  }}
                  className="py-2 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/20 cursor-pointer self-start transition-all"
                >
                  <FolderArchive className="w-4 h-4" />
                  <span>Download All Assets (.ZIP)</span>
                </button>
              </div>

              {/* High-Level Overview Metrics Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono-code">
                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-950 border border-blue-800 flex items-center justify-center text-blue-400 shrink-0">
                    <FolderGit2 className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Total Deliverables</span>
                    <strong className="text-white text-sm">{assets.length} Active Files</strong>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-950 border border-purple-800 flex items-center justify-center text-purple-400 shrink-0">
                    <Figma className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Figma & Design Tokens</span>
                    <strong className="text-purple-300 text-sm">
                      {assets.filter(a => a.category === 'design' || a.category === 'brand').length} Systems
                    </strong>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400 shrink-0">
                    <Compass className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Architecture & Sitemaps</span>
                    <strong className="text-cyan-300 text-sm">
                      {assets.filter(a => a.category === 'architecture' || a.category === 'wireframe').length} Blueprints
                    </strong>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400 shrink-0">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">Legal IP Transfer</span>
                    <strong className="text-emerald-300 text-sm">100% Client Owned</strong>
                  </div>
                </div>
              </div>

              {/* Filtering Controls: Project Selector & Category Pills */}
              <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3 font-mono-code text-xs">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  
                  {/* Project Selector */}
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-xs shrink-0 flex items-center gap-1.5">
                      <Building2 className="w-3.5 h-3.5 text-blue-400" />
                      <span>Project:</span>
                    </span>
                    <select
                      value={selectedProjectAssetFilter}
                      onChange={(e) => setSelectedProjectAssetFilter(e.target.value)}
                      aria-label="Filter assets by project"
                      className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-1.5 focus:outline-none focus:border-blue-500 cursor-pointer"
                    >
                      <option value="all">All Projects ({projects.length})</option>
                      {projects.map((prj) => (
                        <option key={prj.id} value={prj.id}>
                          {prj.title} ({prj.id})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Active Match Count indicator */}
                  <div className="flex items-center gap-2 text-slate-400 text-xs">
                    <span>Showing <strong className="text-white">{filteredAssets.length}</strong> of {assets.length} assets</span>
                    {(selectedProjectAssetFilter !== 'all' || selectedCategoryFilter !== 'all' || searchQuery) && (
                      <button
                        onClick={() => {
                          setSelectedProjectAssetFilter('all');
                          setSelectedCategoryFilter('all');
                          setSearchQuery('');
                        }}
                        className="text-blue-400 hover:text-blue-300 underline cursor-pointer"
                      >
                        Clear Filters
                      </button>
                    )}
                  </div>
                </div>

                {/* Category Pills */}
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
                  {[
                    { id: 'all', label: 'All Assets', icon: Layers },
                    { id: 'architecture', label: 'Architecture & Sitemaps', icon: Compass },
                    { id: 'design', label: 'UI Design & Figma', icon: Figma },
                    { id: 'wireframe', label: 'Wireframes & UX', icon: Layout },
                    { id: 'document', label: 'Contracts & Charters', icon: FileText },
                    { id: 'code', label: 'Source Code & CDN', icon: Code2 },
                    { id: 'brand', label: 'Brand & Vector Kits', icon: Palette }
                  ].map((cat) => {
                    const IconComponent = cat.icon;
                    const isSelected = selectedCategoryFilter === cat.id;

                    return (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategoryFilter(cat.id as any)}
                        className={`px-2.5 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all text-xs cursor-pointer whitespace-nowrap ${
                          isSelected
                            ? 'bg-blue-600 border-blue-500 text-white font-bold shadow-md shadow-blue-600/20'
                            : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                        }`}
                      >
                        <IconComponent className="w-3.5 h-3.5" />
                        <span>{cat.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Dynamic Assets Cards Grid */}
              {filteredAssets.length === 0 ? (
                <div className="p-12 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-3">
                  <FolderGit2 className="w-10 h-10 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Project Assets Match Your Filter</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto font-mono-code">
                    No documents, Figma kits, or source repositories match the selected project, category, or search term.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedProjectAssetFilter('all');
                      setSelectedCategoryFilter('all');
                      setSearchQuery('');
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-mono-code text-slate-200 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Reset All Asset Filters</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredAssets.map((asset) => {
                    const getIcon = () => {
                      switch (asset.format) {
                        case 'figma':
                          return <Figma className="w-4 h-4 text-purple-400" />;
                        case 'sitemap':
                          return <Compass className="w-4 h-4 text-cyan-400" />;
                        case 'wireframe':
                          return <Layout className="w-4 h-4 text-amber-400" />;
                        case 'typescript':
                          return <Code2 className="w-4 h-4 text-emerald-400" />;
                        case 'pdf':
                          return <FileText className="w-4 h-4 text-rose-400" />;
                        case 'svg':
                          return <Palette className="w-4 h-4 text-yellow-400" />;
                        default:
                          return <FileCode className="w-4 h-4 text-blue-400" />;
                      }
                    };

                    return (
                      <div
                        key={asset.id}
                        className="rounded-2xl bg-gradient-to-b from-slate-900/90 to-[#0b0e14] border border-slate-800 hover:border-blue-500/50 transition-all duration-300 flex flex-col justify-between overflow-hidden shadow-lg group"
                      >
                        {/* Top Gradient Visual Banner */}
                        <div className={`p-4 bg-gradient-to-r ${asset.thumbnailGradient} relative overflow-hidden flex items-center justify-between`}>
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-lg bg-slate-950/80 backdrop-blur flex items-center justify-center shadow-inner">
                              {getIcon()}
                            </div>
                            <span className="text-[11px] font-mono-code font-bold uppercase tracking-wider text-white bg-slate-950/60 px-2 py-0.5 rounded backdrop-blur">
                              {asset.format}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <span className="px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase bg-slate-950/70 text-slate-200 backdrop-blur border border-white/10">
                              {asset.version}
                            </span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-mono-code font-bold uppercase backdrop-blur ${
                              asset.status === 'approved' 
                                ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-600/60' 
                                : asset.status === 'ready' 
                                ? 'bg-blue-950/80 text-blue-300 border border-blue-600/60'
                                : 'bg-amber-950/80 text-amber-300 border border-amber-600/60'
                            }`}>
                              {asset.status.replace('_', ' ')}
                            </span>
                          </div>
                        </div>

                        {/* Card Body */}
                        <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                          <div className="space-y-2">
                            <div>
                              <div className="flex items-center justify-between gap-1 text-[11px] font-mono-code text-slate-400 mb-1">
                                <span className="text-blue-400 font-semibold truncate max-w-[180px]">{asset.projectTitle}</span>
                                <span className="shrink-0">{asset.projectId}</span>
                              </div>

                              <h4 className="font-display font-bold text-white text-sm leading-snug group-hover:text-blue-300 transition-colors">
                                {asset.title}
                              </h4>
                            </div>

                            <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                              {asset.description}
                            </p>

                            {/* Tag Badges */}
                            <div className="flex flex-wrap gap-1 pt-1 font-mono-code text-[10px]">
                              {asset.tags.slice(0, 3).map((tag, tIdx) => (
                                <span key={tIdx} className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-400">
                                  #{tag}
                                </span>
                              ))}
                              {asset.tags.length > 3 && (
                                <span className="px-1.5 py-0.5 rounded bg-slate-950 text-slate-500">
                                  +{asset.tags.length - 3}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Meta & Footnotes */}
                          <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono-code text-slate-400">
                            <span>Size: <strong className="text-slate-200">{asset.fileSize}</strong></span>
                            <span className="flex items-center gap-1 text-emerald-400 text-[10px]">
                              <ShieldCheck className="w-3 h-3" />
                              <span>100% IP Client Owned</span>
                            </span>
                          </div>
                        </div>

                        {/* Card Action Buttons */}
                        <div className="p-3 bg-slate-950/90 border-t border-slate-800 flex items-center gap-2">
                          <button
                            onClick={() => setSelectedAssetForPreview(asset)}
                            className="flex-1 py-2 px-3 rounded-xl bg-blue-600/90 hover:bg-blue-600 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-md shadow-blue-600/20"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Preview Asset</span>
                          </button>

                          <button
                            onClick={() => {
                              if (onShowToast) {
                                onShowToast(
                                  'Asset Package Ready',
                                  `Downloaded "${asset.title}" (${asset.fileSize}) with client copyright assignment certificate.`,
                                  'success'
                                );
                              }
                            }}
                            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
                            title={`Download ${asset.title}`}
                          >
                            <Download className="w-3.5 h-3.5 text-blue-400" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: QUOTES */}
          {activeTab === 'quotes' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                  <span>Formal Commercial Quotes & Project Proposals</span>
                  {searchQuery && (
                    <span className="text-xs font-mono-code font-normal text-blue-400">
                      ({filteredQuotes.length} matches)
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-400">
                  Itemized architectural scopes compliant with UAE commercial standards.
                </p>
              </div>

              {filteredQuotes.length === 0 ? (
                <div className="p-10 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-3">
                  <FileText className="w-8 h-8 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Quotes Match "{searchQuery}"</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    No commercial quotes found for your query. Try searching by quote number or client company.
                  </p>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono-code text-slate-200 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Clear Search Filter</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredQuotes.map((quote) => (
                    <div
                      key={quote.id}
                      className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-slate-700 transition-colors"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-white text-sm">{quote.projectType}</span>
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono-code text-slate-300">
                            {quote.quoteNumber}
                          </span>
                          <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded uppercase ${
                            quote.status === 'paid' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-blue-950 text-blue-300 border border-blue-800'
                          }`}>
                            {quote.status}
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 font-mono-code">
                          Entity: <span className="text-slate-200">{quote.companyName}</span> · Valid Until: {quote.validUntil}
                        </p>

                        <div className="text-[11px] text-slate-300">
                          {quote.deliverables.slice(0, 2).join(' · ')}...
                        </div>
                      </div>

                      <div className="flex items-center gap-4 shrink-0 font-mono-code">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-500 block">Total Investment</span>
                          <span className="text-base font-bold text-emerald-400">
                            AED {quote.totalAed.toLocaleString()}
                          </span>
                        </div>

                        {quote.status !== 'paid' && (
                          <button
                            onClick={() => onOpenCheckout(quote.packageName.toLowerCase().includes('starter') ? 'starter' : quote.packageName.toLowerCase().includes('bespoke') ? 'bespoke' : 'business')}
                            className="py-2 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors cursor-pointer"
                          >
                            Lock & Pay
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: INVOICES & RECEIPTS */}
          {activeTab === 'invoices' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                  <span>Tax Invoices & Official Payment Receipts</span>
                  {searchQuery && (
                    <span className="text-xs font-mono-code font-normal text-blue-400">
                      ({filteredInvoices.length} matches)
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-400">
                  Emitac Building Dubai corporate invoices with FTA TRN validation and PDF export.
                </p>
              </div>

              {filteredInvoices.length === 0 ? (
                <div className="p-10 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-3">
                  <FileText className="w-8 h-8 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Invoices Match "{searchQuery}"</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    No matching tax invoices or receipts found for reference ID or invoice number "{searchQuery}".
                  </p>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono-code text-slate-200 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Clear Search Filter</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredInvoices.map((inv) => (
                    <div
                      key={inv.id}
                      className="p-4 sm:p-5 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-slate-700 transition-colors"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <FileText className="w-4 h-4 text-blue-400" />
                          <span className="font-bold text-white text-sm">{inv.invoiceNumber}</span>
                          <span className="px-2 py-0.5 rounded bg-slate-800 text-[10px] font-mono-code text-slate-300">
                            Order: {inv.orderId}
                          </span>
                          {inv.paymentReference && (
                            <span className="px-2 py-0.5 rounded bg-blue-950 border border-blue-800 text-[10px] font-mono-code text-blue-300">
                              Ref: {inv.paymentReference}
                            </span>
                          )}
                          <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded uppercase ${
                            inv.status === 'paid' 
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' 
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}>
                            {inv.status.replace('_', ' ')}
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 font-mono-code">
                          Billed To: <span className="text-slate-200">{inv.clientName} ({inv.companyName})</span> · Issue Date: {inv.issueDate}
                        </p>
                      </div>

                      <div className="flex items-center gap-4 shrink-0 font-mono-code">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-500 block">Amount Incl. VAT</span>
                          <span className="text-sm font-bold text-white">
                            AED {inv.totalAed.toLocaleString()}
                          </span>
                        </div>

                        <button
                          onClick={() => onViewInvoice(inv)}
                          className="py-2 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-mono-code flex items-center gap-1.5 transition-colors cursor-pointer border border-slate-700 shadow-sm"
                        >
                          <Eye className="w-3.5 h-3.5 text-blue-400" />
                          <span>View / Print PDF</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: PAYMENTS HISTORY */}
          {activeTab === 'payments' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                    <span>Payments & Settlement History</span>
                    {searchQuery && (
                      <span className="text-xs font-mono-code font-normal text-blue-400">
                        ({filteredPayments.length} matches)
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Track all processed gateway transactions and manual bank wire submissions.
                  </p>
                </div>

                {/* Filter Pills */}
                <div className="flex items-center gap-1.5 font-mono-code text-xs">
                  <button
                    onClick={() => setPaymentFilter('all')}
                    className={`px-2.5 py-1 rounded-lg cursor-pointer ${paymentFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                  >
                    All
                  </button>
                  <button
                    onClick={() => setPaymentFilter('paid')}
                    className={`px-2.5 py-1 rounded-lg cursor-pointer ${paymentFilter === 'paid' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                  >
                    Paid
                  </button>
                  <button
                    onClick={() => setPaymentFilter('manual_verification')}
                    className={`px-2.5 py-1 rounded-lg cursor-pointer ${paymentFilter === 'manual_verification' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-slate-400'}`}
                  >
                    Under Review
                  </button>
                </div>
              </div>

              {filteredPayments.length === 0 ? (
                <div className="p-10 rounded-2xl bg-slate-900/50 border border-slate-800 text-center space-y-3">
                  <CreditCard className="w-8 h-8 text-slate-600 mx-auto" />
                  <h4 className="text-sm font-bold text-white">No Payments Match "{searchQuery}"</h4>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    We couldn't find any transactions matching reference ID, payment ID, or project name.
                  </p>
                  <button
                    onClick={() => setSearchQuery('')}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono-code text-slate-200 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Clear Search Filter</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3 font-mono-code text-xs">
                  {filteredPayments.map((pay) => (
                    <div
                      key={pay.id}
                      className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-white font-bold">{pay.id}</span>
                          <span className="text-slate-400">· {pay.projectName}</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded capitalize ${
                            pay.status === 'paid' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-300'
                          }`}>
                            {pay.status.replace('_', ' ')}
                          </span>
                        </div>

                        <div className="text-emerald-400 font-bold text-sm">
                          AED {pay.amountAed.toLocaleString()}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-2 text-slate-400 text-[11px] pt-1 border-t border-slate-800/80">
                        <span>Provider: <strong className="text-slate-200">{pay.provider}</strong></span>
                        <span>Ref: <strong className="text-blue-400">{pay.referenceId}</strong></span>
                        <span>Order: <strong className="text-slate-300">{pay.orderId}</strong></span>
                        <span>Date: {new Date(pay.createdAt).toLocaleDateString()}</span>
                      </div>

                      {pay.verificationNotes && (
                        <p className="text-[10px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800/60">
                          {pay.verificationNotes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: PAYMENT METHODS ARCHITECTURE */}
          {activeTab === 'methods' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  Payment Channels & Gateway Connection Status
                </h3>
                <p className="text-xs text-slate-400">
                  Overview of our online merchant gateways and direct UAE corporate banking channels.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {PAYMENT_OPTIONS_CATALOG.map((opt) => (
                  <div
                    key={opt.id}
                    className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">
                        {opt.name}
                      </span>
                      <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded ${
                        opt.status === 'connected' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-blue-950 text-blue-300 border border-blue-800'
                      }`}>
                        {opt.statusLabel}
                      </span>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {opt.description}
                    </p>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono-code text-slate-400">
                      <span>{opt.processor}</span>
                      <span className="text-emerald-400">{opt.settlementTime}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: SUPPORT & HELP (SEARCHABLE FAQ & DISPATCH) */}
          {activeTab === 'support' && (
            <ClientSupportHelp 
              onOpenCheckout={onOpenCheckout} 
              onSelectTab={(tab) => setActiveTab(tab as any)} 
            />
          )}

        </div>

      </div>

      {/* Interactive Project Asset Preview Modal */}
      {selectedAssetForPreview && (
        <ProjectAssetPreviewModal
          asset={selectedAssetForPreview}
          onClose={() => setSelectedAssetForPreview(null)}
          onShowToast={onShowToast}
        />
      )}
    </div>
  );
};
