import React, { useState } from 'react';
import { 
  MessageSquare, 
  Mail, 
  Send, 
  Phone, 
  MapPin, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Building,
  Code2
} from 'lucide-react';
import { BRAND_CONFIG } from '../data/portalData';

interface ContactSectionProps {
  prefilledScope?: string;
  onShowToast?: (title: string, description: string) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ prefilledScope, onShowToast }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');
  const [projectType, setProjectType] = useState('Corporate Website (5-10 pages)');
  const [details, setDetails] = useState(prefilledScope || '');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    if (onShowToast) {
      onShowToast(
        'Inquiry Logged Successfully',
        `Thank you, ${name || 'Valued Client'}. Your project brief for ${company || 'your business'} has been received by our Dubai team. A project lead will respond within 4 business hours.`
      );
    }
  };

  const handleWhatsApp = () => {
    const text = encodeURIComponent(
      `Hello AIGAINX Portal! I would like to schedule a project discovery consultation for ${company || 'my business'}. Name: ${name || 'Prospective Client'}.`
    );
    window.open(`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
  };

  return (
    <section 
      id="contact"
      className="py-24 bg-[#090b10] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Left Column: Direct Studio Contact & Dubai Hub Details */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/60 border border-blue-800/60 text-blue-400 text-xs font-mono-code font-semibold mb-3">
                <Send className="w-3.5 h-3.5" />
                <span>START YOUR PROJECT</span>
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                Let's Build Your Website on a Proven System.
              </h2>
              <p className="text-slate-300 text-base mt-2 leading-relaxed">
                Connect directly with our Dubai project team to discuss your sitemap, timeline, and conversion goals.
              </p>
            </div>

            {/* Studio Info Cards */}
            <div className="space-y-3 font-mono-code text-xs">
              
              <div className="p-4 rounded-xl bg-[#0e131d] border border-slate-800 flex items-start gap-3">
                <MapPin className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 font-semibold">Studio Location</span>
                  <p className="text-slate-200 mt-0.5">{BRAND_CONFIG.addressDetailed}</p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0e131d] border border-slate-800 flex items-start gap-3">
                <Mail className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 font-semibold">Direct Email</span>
                  <a 
                    href={`mailto:${BRAND_CONFIG.email}`} 
                    className="block text-white hover:text-blue-400 font-medium transition-colors mt-0.5"
                  >
                    {BRAND_CONFIG.email}
                  </a>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0e131d] border border-slate-800 flex items-start gap-3">
                <Phone className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 font-semibold">WhatsApp & Phone</span>
                  <a 
                    href={`https://wa.me/${BRAND_CONFIG.whatsappNumber.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer" 
                    className="block text-emerald-400 hover:text-emerald-300 font-medium transition-colors mt-0.5"
                  >
                    {BRAND_CONFIG.whatsappDisplay}
                  </a>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0e131d] border border-slate-800 flex items-start gap-3">
                <Code2 className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 font-semibold">Studio Delivery Model</span>
                  <p className="text-slate-200 mt-0.5">
                    {BRAND_CONFIG.deliveryModel} · {BRAND_CONFIG.studioType}
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#0e131d] border border-slate-800 flex items-start gap-3">
                <Clock className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 font-semibold">Response Guarantee</span>
                  <p className="text-slate-200 mt-0.5">
                    Within 4 business hours (GST, UTC+4)
                  </p>
                </div>
              </div>

            </div>

            {/* Direct WhatsApp Callout */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-800/80 space-y-3">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-400" />
                <h4 className="text-sm font-bold text-white">Prefer Instant WhatsApp Chat?</h4>
              </div>
              <p className="text-xs text-slate-300">
                Connect directly with our Dubai web design lead for quick questions, availability checks, or immediate proposal reviews.
              </p>
              <button
                type="button"
                onClick={handleWhatsApp}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open WhatsApp ({BRAND_CONFIG.whatsappDisplay})</span>
              </button>
            </div>

          </div>

          {/* Right Column: Project Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-[#0e131d] border border-slate-800 shadow-2xl p-6 sm:p-10">
              
              {!submitted ? (
                <form onSubmit={handleSubmit} className="space-y-6">
                  
                  <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                    <h3 className="font-display text-xl font-bold text-white">
                      Project Inquiry & Kickoff Form
                    </h3>
                    <span className="text-xs font-mono-code text-blue-400">Step 01: Discovery</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">Full Name *</label>
                      <input 
                        type="text" 
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Tariq Al Mansoor"
                        className="w-full px-4 py-2.5 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">Business / Brand Name *</label>
                      <input 
                        type="text" 
                        required
                        value={company}
                        onChange={(e) => setCompany(e.target.value)}
                        placeholder="e.g. Apex Luxury Properties"
                        className="w-full px-4 py-2.5 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">Work Email *</label>
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="tariq@apex.ae"
                        className="w-full px-4 py-2.5 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-slate-300">Phone / WhatsApp Number</label>
                      <input 
                        type="tel" 
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+971 50 123 4567"
                        className="w-full px-4 py-2.5 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300">Project Type / Architecture</label>
                    <select 
                      value={projectType}
                      onChange={(e) => setProjectType(e.target.value)}
                      className="w-full px-4 py-2.5 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                    >
                      <option value="Corporate Website (5-10 pages)">Corporate & Business Website (5-10 Pages)</option>
                      <option value="High-Converting Campaign Landing Page">High-Converting Campaign Landing Page (Single Page)</option>
                      <option value="E-Commerce / Product Catalogue">E-Commerce & Digital Product Catalogue</option>
                      <option value="Website Replatforming & Performance Redesign">Website Replatforming & Performance Redesign</option>
                      <option value="Bespoke Digital System">Bespoke Digital Platform / Custom Scope</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-slate-300">Project Objectives & Target Launch Date</label>
                    <textarea 
                      rows={4}
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      placeholder="Describe your target audience, current website URL (if any), and desired timeline..."
                      className="w-full px-4 py-2.5 text-xs rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-blue-500"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    <span>Submit Project Brief to AIGAINX Team</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <p className="text-center text-[11px] text-slate-400">
                    🔒 Non-Disclosure Guarantee: All project details are kept strictly confidential. 100% Code & Asset Handover at launch.
                  </p>

                </form>
              ) : (
                <div className="py-12 text-center space-y-4">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-950 border border-emerald-700 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-white">
                    Thank You, {name || 'Valued Client'}!
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto">
                    Your project brief has been logged in the AIGAINX system. A senior project lead will review your requirements and send a structured proposal within 4 business hours.
                  </p>
                  <div className="pt-4">
                    <button
                      onClick={() => setSubmitted(false)}
                      className="px-4 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs hover:bg-slate-800"
                    >
                      Submit Another Inquiry
                    </button>
                  </div>
                </div>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
