import React from 'react';
import { 
  X, 
  Printer, 
  Download, 
  CheckCircle2, 
  Clock, 
  Building2, 
  ShieldCheck, 
  FileText, 
  MapPin, 
  Mail, 
  Phone,
  QrCode
} from 'lucide-react';
import { InvoiceRecord, PaymentRecord } from '../types';
import { BRAND_CONFIG } from '../data/portalData';
import { UAE_BANK_DETAILS } from '../data/paymentData';

interface InvoiceReceiptModalProps {
  invoice: InvoiceRecord | null;
  payment?: PaymentRecord | null;
  onClose: () => void;
  onPrint?: () => void;
}

export const InvoiceReceiptModal: React.FC<InvoiceReceiptModalProps> = ({
  invoice,
  payment,
  onClose
}) => {
  if (!invoice) return null;

  const isPaid = invoice.status === 'paid' || payment?.status === 'paid';
  const isUnderReview = invoice.status === 'under_review' || payment?.status === 'manual_verification';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl my-8 bg-[#0b0f17] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-200 print:bg-white print:text-black print:border-none print:shadow-none">
        
        {/* Header Action Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900/90 border-b border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-400" />
            <span className="text-sm font-display font-bold text-white tracking-wide">
              Official Tax Invoice & Receipt
            </span>
            <span className="text-xs font-mono-code px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              {invoice.invoiceNumber}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-mono-code flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-blue-400" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-6 sm:p-10 space-y-8 bg-[#0c1018] print:p-0 print:bg-white">
          
          {/* Top Brand & Invoice Metadata */}
          <div className="flex flex-col sm:flex-row items-start justify-between gap-6 pb-6 border-b border-slate-800 print:border-black">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl overflow-hidden bg-slate-900 border border-slate-700 shrink-0">
                  <img 
                    src={BRAND_CONFIG.monogramUrl} 
                    alt="AIGAINX Monogram" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div>
                  <h1 className="text-xl font-display font-black text-white print:text-black">
                    AIGAINX DIGITAL ARCHITECTURE
                  </h1>
                  <p className="text-[11px] font-mono-code text-slate-400 uppercase tracking-wider print:text-gray-600">
                    Bespoke Web Engineering & Digital Systems
                  </p>
                </div>
              </div>

              <div className="text-xs text-slate-400 print:text-gray-600 space-y-0.5 pt-2">
                <p className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-blue-400" />
                  <span>Emitac Building, Dubai, United Arab Emirates</span>
                </p>
                <p className="flex items-center gap-1">
                  <Mail className="w-3 h-3 text-indigo-400" />
                  <span>projects@aigainx.tech</span>
                  <span className="text-slate-600">·</span>
                  <span>+971 58 573 5099</span>
                </p>
                <p className="font-mono-code text-[11px] text-slate-400">
                  UAE TRN (Tax Registration): <span className="text-slate-200 font-semibold print:text-black">100984729100003</span>
                </p>
              </div>
            </div>

            {/* Right Status Badge & Numbers */}
            <div className="sm:text-right space-y-2">
              <div className="inline-block">
                {isPaid ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-400 font-mono-code font-bold text-xs shadow-md">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>TAX INVOICE — PAID</span>
                  </span>
                ) : isUnderReview ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/80 border border-amber-500/50 text-amber-300 font-mono-code font-bold text-xs shadow-md">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>MANUAL BANK VERIFICATION</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-950/80 border border-blue-500/50 text-blue-300 font-mono-code font-bold text-xs shadow-md">
                    <span>PAYMENT DUE</span>
                  </span>
                )}
              </div>

              <div className="text-xs font-mono-code space-y-1 text-slate-300 print:text-black">
                <p>Invoice No: <span className="text-white font-bold print:text-black">{invoice.invoiceNumber}</span></p>
                <p>Order ID: <span className="text-blue-400">{invoice.orderId}</span></p>
                <p>Issue Date: <span>{invoice.issueDate}</span></p>
                <p>Due Date: <span>{invoice.dueDate}</span></p>
                {invoice.paidDate && (
                  <p className="text-emerald-400">Paid Date: <span>{invoice.paidDate}</span></p>
                )}
              </div>
            </div>
          </div>

          {/* Billed To Information */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 p-4 rounded-xl bg-slate-900/50 border border-slate-800 print:bg-gray-100 print:border-gray-300">
            <div>
              <span className="text-[10px] font-mono-code uppercase tracking-wider text-slate-400 print:text-gray-600 block">
                Billed To (Client / Entity)
              </span>
              <h2 className="text-sm font-bold text-white mt-1 print:text-black">
                {invoice.clientName}
              </h2>
              <p className="text-xs text-slate-300 print:text-gray-700">
                {invoice.companyName}
              </p>
              <p className="text-xs text-slate-400 print:text-gray-600">
                {invoice.clientEmail}
              </p>
              {invoice.clientAddress && (
                <p className="text-xs text-slate-400 print:text-gray-600 mt-1">
                  {invoice.clientAddress}
                </p>
              )}
            </div>

            <div className="space-y-1 text-xs font-mono-code">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 print:text-gray-600 block">
                Payment Channel & Reference
              </span>
              <p className="text-slate-300 print:text-black">
                Method: <span className="text-white font-bold capitalize print:text-black">{invoice.paymentMethod?.replace('_', ' ') || 'Direct Electronic Channel'}</span>
              </p>
              <p className="text-slate-300 print:text-black">
                Ref ID: <span className="text-blue-400 font-bold">{invoice.paymentReference || 'AIGX-AUTO-REF'}</span>
              </p>
              <p className="text-slate-400 print:text-gray-600">
                Currency: <span className="text-slate-200 print:text-black">AED (United Arab Emirates Dirham)</span>
              </p>
            </div>
          </div>

          {/* Itemized Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-mono-code uppercase tracking-wider print:border-gray-300 print:text-gray-700">
                  <th className="py-3 px-2">Scope Description</th>
                  <th className="py-3 px-2 text-center">Qty</th>
                  <th className="py-3 px-2 text-right">Unit Rate (AED)</th>
                  <th className="py-3 px-2 text-right">Amount (AED)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 print:divide-gray-200">
                {invoice.items.map((item, idx) => (
                  <tr key={idx} className="text-slate-200 print:text-black">
                    <td className="py-4 px-2 font-medium">
                      <div className="font-semibold text-white print:text-black">{item.description}</div>
                      <div className="text-[11px] text-slate-400 print:text-gray-600">
                        8-Step Engineering Delivery Model · 100% Repository Transfer
                      </div>
                    </td>
                    <td className="py-4 px-2 text-center font-mono-code">{item.qty}</td>
                    <td className="py-4 px-2 text-right font-mono-code">
                      AED {item.rateAed.toLocaleString()}
                    </td>
                    <td className="py-4 px-2 text-right font-mono-code font-bold text-white print:text-black">
                      AED {item.amountAed.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Financial Calculation Breakdown */}
          <div className="flex flex-col sm:flex-row justify-between items-start gap-6 pt-4 border-t border-slate-800 print:border-gray-300">
            <div className="space-y-2 text-xs text-slate-400 max-w-sm print:text-gray-600">
              <div className="flex items-center gap-1.5 text-blue-400 font-mono-code font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>Verified Commercial Digital Architecture</span>
              </div>
              <p className="text-[11px] leading-relaxed">
                This document serves as an official commercial tax invoice and receipt for bespoke digital engineering services rendered by AIGAINX Portal in accordance with UAE Federal Tax Authority (FTA) regulations.
              </p>
            </div>

            <div className="w-full sm:w-72 space-y-2 font-mono-code text-xs">
              <div className="flex justify-between py-1 border-b border-slate-800/80 text-slate-300 print:border-gray-200 print:text-black">
                <span>Subtotal:</span>
                <span>AED {invoice.subtotalAed.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800/80 text-slate-300 print:border-gray-200 print:text-black">
                <span>UAE VAT (5%):</span>
                <span>AED {invoice.vatAed.toLocaleString()}</span>
              </div>
              <div className="flex justify-between py-2 text-base font-bold text-white print:text-black border-b-2 border-blue-500">
                <span>Total Amount:</span>
                <span className="text-emerald-400 print:text-black">
                  AED {invoice.totalAed.toLocaleString()}
                </span>
              </div>
              {isPaid && (
                <div className="flex justify-between py-1 text-emerald-400 font-semibold text-xs">
                  <span>Balance Due:</span>
                  <span>AED 0.00 (PAID IN FULL)</span>
                </div>
              )}
            </div>
          </div>

          {/* Bank Transfer Instructions if Pending / Bank Wire */}
          {invoice.paymentMethod === 'bank_transfer' && (
            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-mono-code space-y-2 print:bg-gray-100 print:border-gray-300">
              <div className="flex items-center gap-2 text-blue-300 font-bold">
                <Building2 className="w-4 h-4 text-blue-400" />
                <span>Beneficiary Bank Account Details (UAE Central Bank Network)</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 print:text-black">
                <p>Bank: <span className="text-white font-semibold">{UAE_BANK_DETAILS.bankName}</span></p>
                <p>Account: <span className="text-white font-semibold">{UAE_BANK_DETAILS.accountName}</span></p>
                <p>IBAN: <span className="text-blue-400 font-bold">{UAE_BANK_DETAILS.iban}</span></p>
                <p>SWIFT / BIC: <span className="text-white font-semibold">{UAE_BANK_DETAILS.swift}</span></p>
              </div>
              <p className="text-[11px] text-slate-400 pt-1">
                Ref Code: <span className="text-emerald-400 font-bold">{invoice.paymentReference}</span> (Must be quoted on wire instruction).
              </p>
            </div>
          )}

          {/* Verification Seal & Footer */}
          <div className="flex items-center justify-between pt-6 border-t border-slate-800 text-xs font-mono-code text-slate-500 print:border-gray-300 print:text-gray-500">
            <div className="flex items-center gap-2">
              <QrCode className="w-8 h-8 text-slate-600 print:text-black" />
              <div>
                <p className="text-[10px] text-slate-400">Cryptographically Signed Invoice</p>
                <p className="text-[9px]">Hash: {invoice.id}-{invoice.orderId}-VERIFIED</p>
              </div>
            </div>
            <div className="text-right text-[10px]">
              <p>AIGAINX Portal · Emitac Building, Dubai, UAE</p>
              <p>www.aigainx.tech</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
