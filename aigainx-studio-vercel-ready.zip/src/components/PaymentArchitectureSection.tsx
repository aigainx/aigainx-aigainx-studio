import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CreditCard, 
  Building2, 
  Smartphone, 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Lock, 
  Layers, 
  FileText, 
  Workflow, 
  Zap, 
  ExternalLink,
  Shield,
  QrCode,
  UserCheck
} from 'lucide-react';
import { PAYMENT_OPTIONS_CATALOG, UAE_BANK_DETAILS, DEFAULT_MERCHANT_CONFIG } from '../data/paymentData';

interface PaymentArchitectureSectionProps {
  onOpenCheckout: (packageId?: string) => void;
  onOpenClientDashboard: () => void;
  onOpenAdminPortal: () => void;
}

export const PaymentArchitectureSection: React.FC<PaymentArchitectureSectionProps> = ({
  onOpenCheckout,
  onOpenClientDashboard,
  onOpenAdminPortal
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'online' | 'provider' | 'bank'>('all');

  const filteredOptions = activeCategory === 'all'
    ? PAYMENT_OPTIONS_CATALOG
    : PAYMENT_OPTIONS_CATALOG.filter((item) => item.category === activeCategory);

  return (
    <section id="payments" className="relative py-24 bg-[#080b11] border-t border-slate-800/80 overflow-hidden">
      {/* Background Architectural Grid Accent */}
      <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:28px_28px] opacity-25 pointer-events-none" />
      <div className="absolute top-1/4 -right-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 -left-40 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-950/80 border border-blue-800/60 text-blue-400 text-xs font-mono-code">
              <Lock className="w-3.5 h-3.5" />
              <span>AIGAINX High-Level Payment Architecture</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-display font-black text-white tracking-tight">
              Enterprise Commercial <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-indigo-300 to-emerald-400">Payment Engine</span>
            </h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              Fully compliant UAE transaction infrastructure with verified merchant gateway integration, instant biometric tokenization, and manual wire verification at Emitac Building, Dubai.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onOpenCheckout()}
              className="py-3 px-5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
            >
              <span>Launch Secure Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onOpenClientDashboard}
              className="py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-mono-code flex items-center gap-2 transition-all cursor-pointer"
            >
              <UserCheck className="w-4 h-4 text-blue-400" />
              <span>Client Area</span>
            </button>
            <button
              type="button"
              onClick={onOpenAdminPortal}
              className="py-3 px-4 rounded-xl bg-purple-950/70 hover:bg-purple-900 text-purple-300 border border-purple-800/80 text-xs font-mono-code flex items-center gap-2 transition-all cursor-pointer"
            >
              <Shield className="w-4 h-4 text-purple-400" />
              <span>Admin Queue</span>
            </button>
          </div>
        </div>

        {/* High-Level Architecture Hierarchy Tree */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-slate-900/90 to-[#0a0e16] border border-slate-800 shadow-2xl space-y-8">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <span className="text-xs font-mono-code uppercase tracking-wider text-blue-400 font-bold block">
                SYSTEM STRUCTURE MAP
              </span>
              <h3 className="text-lg font-display font-bold text-white mt-0.5">
                AIGAINX Multi-Channel Payment Framework
              </h3>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono-code">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300">
                Stripe UAE: CONNECTED
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300">
                Ziina: LICENSED
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-blue-950/80 border border-blue-800 text-blue-300">
                Emirates NBD: ACTIVE
              </span>
            </div>
          </div>

          {/* 3 Pillar Columns (Online Payment, Payment Providers, Bank Payment) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            {/* Pillar 1: Online Payment */}
            <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90 space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="w-9 h-9 rounded-xl bg-blue-950 border border-blue-800 text-blue-400 flex items-center justify-center">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Online Payment</h4>
                  <p className="text-[11px] font-mono-code text-slate-400">Instant Customer Channels</p>
                </div>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-300 font-mono-code">
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">🍏 Apple Pay</span>
                  <span className="text-[10px] text-slate-400 ml-auto">(Processed via Stripe)</span>
                </li>
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">💳 Debit Card</span>
                  <span className="text-[10px] text-slate-400 ml-auto">UAE & Global Rails</span>
                </li>
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">💳 Credit Card</span>
                  <span className="text-[10px] text-slate-400 ml-auto">Visa / MC / AMEX</span>
                </li>
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">🔒 Secure Checkout</span>
                  <span className="text-[10px] text-emerald-400 ml-auto">3DS 2.0 Tokenized</span>
                </li>
              </ul>
            </div>

            {/* Pillar 2: Payment Providers */}
            <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90 space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="w-9 h-9 rounded-xl bg-purple-950 border border-purple-800 text-purple-400 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Payment Providers</h4>
                  <p className="text-[11px] font-mono-code text-slate-400">Approved Merchant Gateways</p>
                </div>
              </div>

              <div className="space-y-3 text-xs font-mono-code">
                {/* Stripe Branch */}
                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-white font-bold">
                    <span>🟣 Stripe Payments</span>
                    <span className="text-[10px] text-emerald-400">Active ME Gateway</span>
                  </div>
                  <div className="text-[11px] text-slate-400 space-y-0.5 pl-2 border-l border-slate-700">
                    <p>├─ Card Processing</p>
                    <p>├─ Apple Pay Integration</p>
                    <p>└─ Payment Links / Checkout</p>
                  </div>
                </div>

                {/* Ziina Branch */}
                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800/80 space-y-1.5">
                  <div className="flex items-center justify-between text-white font-bold">
                    <span>🟢 Ziina Gateway</span>
                    <span className="text-[10px] text-emerald-400">CBUAE Licensed</span>
                  </div>
                  <div className="text-[11px] text-slate-400 space-y-0.5 pl-2 border-l border-slate-700">
                    <p>├─ UAE Payment Links</p>
                    <p>└─ Fast Local QR Checkout</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pillar 3: Bank Payment */}
            <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800/90 space-y-4">
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Bank Payment</h4>
                  <p className="text-[11px] font-mono-code text-slate-400">Direct Corporate Wire</p>
                </div>
              </div>

              <ul className="space-y-2.5 text-xs text-slate-300 font-mono-code">
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">🏦 Bank Transfer</span>
                  <span className="text-[10px] text-slate-400 ml-auto">0% Gateway Fee</span>
                </li>
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">🇦🇪 UAE Bank Account</span>
                  <span className="text-[10px] text-blue-400 ml-auto">Emirates NBD</span>
                </li>
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">🏷️ Payment Reference</span>
                  <span className="text-[10px] text-emerald-400 ml-auto">AIGX-REF-[ORDER]</span>
                </li>
                <li className="flex items-center gap-2 p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                  <span className="text-white font-bold">📤 Upload Payment Proof</span>
                  <span className="text-[10px] text-amber-400 ml-auto">Manual Verification</span>
                </li>
              </ul>
            </div>

          </div>

          {/* Payment Flow Sequential Pipeline */}
          <div className="pt-6 border-t border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-xs font-mono-code text-slate-300">
              <Workflow className="w-4 h-4 text-blue-400" />
              <span className="font-bold text-white uppercase tracking-wider">
                Standard Project & Payment Flow Pipeline
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-2 text-center text-xs font-mono-code">
              {[
                { step: '1', title: 'Select Service' },
                { step: '2', title: 'Select Package' },
                { step: '3', title: 'Project Details' },
                { step: '4', title: 'Generate Quote' },
                { step: '5', title: 'Choose Method' },
                { step: '6', title: 'Secure Payment' },
                { step: '7', title: 'Confirmation' },
                { step: '8', title: 'Tax Invoice' },
                { step: '9', title: 'Project Starts' }
              ].map((pipe, idx) => (
                <div 
                  key={idx} 
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex flex-col items-center justify-center space-y-1 hover:border-blue-500/50 transition-colors"
                >
                  <span className="w-5 h-5 rounded-full bg-blue-950 border border-blue-800 text-blue-400 text-[10px] font-bold flex items-center justify-center">
                    {pipe.step}
                  </span>
                  <span className="text-[11px] text-slate-200 font-semibold leading-tight">
                    {pipe.title}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Regulatory Clarification Callout */}
          <div className="p-4 rounded-2xl bg-blue-950/30 border border-blue-800/50 flex items-start gap-3 text-xs leading-relaxed text-slate-300">
            <ShieldCheck className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-display text-xs mb-0.5">
                Merchant Gateway Policy & Verification Protocol
              </strong>
              Apple Pay and card payments are processed securely through payment processor gateway infrastructure (Stripe/Ziina) rather than direct individual bank accounts. Online merchant buttons are active for connected gateways, while Direct Bank Transfer operates with safe manual verification through our Dubai studio finance desk.
            </div>
          </div>

        </div>

        {/* Interactive Payment Methods Catalog Cards */}
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-xl font-display font-bold text-white">
                Available Payment Options & Gateway Specifications
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Filter by category to explore processing speed, gateway fees, and compliance notes.
              </p>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono-code">
              <button
                type="button"
                onClick={() => setActiveCategory('all')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'all' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All Methods
              </button>
              <button
                type="button"
                onClick={() => setActiveCategory('online')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'online' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Online
              </button>
              <button
                type="button"
                onClick={() => setActiveCategory('provider')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'provider' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Providers
              </button>
              <button
                type="button"
                onClick={() => setActiveCategory('bank')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  activeCategory === 'bank' ? 'bg-blue-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                UAE Bank
              </button>
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {filteredOptions.map((opt) => (
              <div
                key={opt.id}
                className="p-5 rounded-2xl bg-gradient-to-b from-slate-900/80 to-[#0b0f17] border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">
                        {opt.id === 'apple_pay' && '🍏 Apple Pay'}
                        {opt.id === 'credit_card' && '💳 Credit Card'}
                        {opt.id === 'debit_card' && '💳 Debit Card'}
                        {opt.id === 'stripe' && '🟣 Stripe'}
                        {opt.id === 'ziina' && '🟢 Ziina'}
                        {opt.id === 'bank_transfer' && '🏦 Direct UAE Bank'}
                      </span>
                    </div>
                    <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded font-bold ${
                      opt.status === 'connected' 
                        ? 'bg-emerald-950/90 text-emerald-400 border border-emerald-800' 
                        : 'bg-blue-950/90 text-blue-300 border border-blue-800'
                    }`}>
                      {opt.statusLabel}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {opt.description}
                  </p>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] font-mono-code text-slate-400">
                    <span>Processor: </span>
                    <span className="text-slate-200 font-semibold">{opt.processor}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono-code">
                  <div className="text-[11px] text-slate-400">
                    <span>Fee: </span>
                    <strong className="text-emerald-400">{opt.processingFee}</strong>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenCheckout()}
                    className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <span>Use Channel</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
