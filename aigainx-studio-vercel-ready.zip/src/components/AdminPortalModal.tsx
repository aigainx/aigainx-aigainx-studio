import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  ShieldCheck, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  CreditCard, 
  Building2, 
  FileText, 
  Users, 
  TrendingUp, 
  Settings, 
  Eye, 
  RotateCcw,
  Check,
  RefreshCw,
  Search,
  Filter,
  DollarSign
} from 'lucide-react';
import { 
  PaymentRecord, 
  InvoiceRecord, 
  QuoteRecord, 
  ClientProject, 
  MerchantGatewayConfig 
} from '../types';
import { 
  getStoredPayments, 
  updatePaymentStatusInStore, 
  getStoredInvoices, 
  saveInvoiceRecord, 
  getStoredProjects, 
  saveProjectRecord, 
  updateProjectMilestoneInStore,
  getStoredQuotes,
  getStoredMerchantConfig,
  saveMerchantConfig,
  UAE_BANK_DETAILS 
} from '../data/paymentData';
import { PROCESS_STEPS } from '../data/portalData';

interface AdminPortalModalProps {
  onClose: () => void;
  onViewInvoice: (invoice: InvoiceRecord) => void;
  onShowToast: (title: string, desc: string, type?: 'success' | 'info') => void;
}

export const AdminPortalModal: React.FC<AdminPortalModalProps> = ({
  onClose,
  onViewInvoice,
  onShowToast
}) => {
  const [activeTab, setActiveTab] = useState<'verification' | 'payments' | 'orders' | 'invoices' | 'gateways' | 'reports'>('verification');
  
  // Stored state
  const [payments, setPayments] = useState<PaymentRecord[]>(() => getStoredPayments());
  const [invoices, setInvoices] = useState<InvoiceRecord[]>(() => getStoredInvoices());
  const [projects, setProjects] = useState<ClientProject[]>(() => getStoredProjects());
  const [quotes, setQuotes] = useState<QuoteRecord[]>(() => getStoredQuotes());
  const [merchantConfig, setMerchantConfig] = useState<MerchantGatewayConfig>(() => getStoredMerchantConfig());

  // Provider Filter
  const [providerFilter, setProviderFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Pending verification queue
  const pendingVerifications = payments.filter((p) => p.status === 'manual_verification');

  // Handle Approve Bank Transfer
  const handleApproveTransfer = (payment: PaymentRecord) => {
    // 1. Update Payment Status to 'paid'
    const updatedPayments = updatePaymentStatusInStore(
      payment.id, 
      'paid', 
      'Verified & Approved by Admin at Emitac Building Dubai Studio.'
    );
    setPayments(updatedPayments);

    // 2. Update Invoice to 'paid'
    const matchingInvoice = invoices.find((inv) => inv.orderId === payment.orderId || inv.invoiceNumber === payment.invoiceNumber);
    if (matchingInvoice) {
      const updatedInv: InvoiceRecord = {
        ...matchingInvoice,
        status: 'paid',
        paidDate: new Date().toISOString().split('T')[0]
      };
      saveInvoiceRecord(updatedInv);
      setInvoices(getStoredInvoices());
    }

    // 3. Update Client Project payment status
    const matchingProject = projects.find((prj) => prj.orderId === payment.orderId);
    if (matchingProject) {
      const updatedPrj: ClientProject = {
        ...matchingProject,
        paymentStatus: 'paid'
      };
      saveProjectRecord(updatedPrj);
      setProjects(getStoredProjects());
    }

    onShowToast(
      'Bank Transfer Approved', 
      `Order ${payment.orderId} (${payment.companyName}) marked as PAID in full. Project kickoff authorized.`
    );
  };

  // Handle Reject Bank Transfer
  const handleRejectTransfer = (payment: PaymentRecord) => {
    const updatedPayments = updatePaymentStatusInStore(
      payment.id, 
      'failed', 
      'Rejected by Admin: Slip unreadable or funds not reflected in Emirates NBD account.'
    );
    setPayments(updatedPayments);

    onShowToast(
      'Transfer Slip Rejected', 
      `Payment record ${payment.id} marked as failed. Client will be requested to re-upload receipt.`,
      'info'
    );
  };

  // Toggle Mode (Sandbox vs Live)
  const handleToggleMode = () => {
    const newMode = merchantConfig.activeMode === 'live' ? 'sandbox' : 'live';
    const updated: MerchantGatewayConfig = {
      ...merchantConfig,
      activeMode: newMode
    };
    saveMerchantConfig(updated);
    setMerchantConfig(updated);
    onShowToast('Gateway Mode Switched', `Active Merchant Gateway mode is now set to ${newMode.toUpperCase()}.`);
  };

  // Handle Admin Project Milestone Step Update
  const handleUpdateMilestone = (projectId: string, newStep: number) => {
    const { updatedProjects, updatedProject, detail } = updateProjectMilestoneInStore(projectId, newStep);
    setProjects(updatedProjects);

    if (updatedProject && detail) {
      onShowToast(
        `⚡ Milestone Broadcast: Step ${newStep} Active`,
        `Project "${updatedProject.title}" advanced to Step ${newStep} (${detail.milestoneName}). Live update dispatched to client portal.`,
        'success'
      );
    }
  };

  // Financial Stats
  const totalRevenueAed = payments
    .filter((p) => p.status === 'paid')
    .reduce((acc, curr) => acc + curr.amountAed, 0);

  const totalVatAed = payments
    .filter((p) => p.status === 'paid')
    .reduce((acc, curr) => acc + curr.vatAed, 0);

  const totalPendingAed = payments
    .filter((p) => p.status === 'manual_verification')
    .reduce((acc, curr) => acc + curr.amountAed, 0);

  const filteredPayments = payments.filter((p) => {
    const matchesProvider = providerFilter === 'all' || p.method === providerFilter;
    const matchesSearch = searchQuery === '' || 
      p.clientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.referenceId.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesProvider && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl my-6 bg-[#0a0d14] border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-slate-200 flex flex-col max-h-[90vh]">
        
        {/* Top Header */}
        <div className="p-5 bg-slate-900/95 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-800 flex items-center justify-center text-purple-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-base font-bold text-white tracking-wide">
                  AIGAINX ADMIN MANAGEMENT WORKSPACE
                </h2>
                <span className={`text-[10px] font-mono-code px-2 py-0.5 rounded font-bold ${
                  merchantConfig.activeMode === 'live' 
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' 
                    : 'bg-amber-950 text-amber-300 border border-amber-800'
                }`}>
                  MODE: {merchantConfig.activeMode.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono-code">
                Payment Verification Queue · Orders · Merchant Gateway Governance
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="px-6 py-2.5 bg-[#080b11] border-b border-slate-800 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0 text-xs font-mono-code">
          <button
            onClick={() => setActiveTab('verification')}
            className={`px-3.5 py-1.5 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'verification'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <span>Verification Queue</span>
            {pendingVerifications.length > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500 text-black font-bold text-[9px] flex items-center justify-center">
                {pendingVerifications.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'payments'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Payments by Gateway ({payments.length})
          </button>

          <button
            onClick={() => setActiveTab('orders')}
            className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'orders'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Orders & Projects ({projects.length})
          </button>

          <button
            onClick={() => setActiveTab('invoices')}
            className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'invoices'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Tax Invoices ({invoices.length})
          </button>

          <button
            onClick={() => setActiveTab('gateways')}
            className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'gateways'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Gateways & Merchant Config
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3.5 py-1.5 rounded-xl transition-all cursor-pointer ${
              activeTab === 'reports'
                ? 'bg-purple-600 text-white font-semibold shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            Financial Reports
          </button>
        </div>

        {/* Scrollable Main Area */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* TAB 1: BANK PAYMENT VERIFICATION QUEUE */}
          {activeTab === 'verification' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                    <span>Manual Bank Wire Slip Verification Queue</span>
                    <span className="text-xs font-mono-code px-2 py-0.5 rounded bg-amber-950 text-amber-400 border border-amber-800">
                      {pendingVerifications.length} Awaiting Studio Review
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Safe verification workflow for Emirates NBD corporate wire transfers submitted by clients.
                  </p>
                </div>
              </div>

              {pendingVerifications.length === 0 ? (
                <div className="p-10 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-3">
                  <div className="w-12 h-12 rounded-full bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-white">All Bank Wires are Verified</h4>
                  <p className="text-xs text-slate-400">
                    There are no pending bank transfer slips awaiting review in the Dubai Studio queue.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingVerifications.map((item) => (
                    <div
                      key={item.id}
                      className="p-5 rounded-2xl bg-gradient-to-b from-slate-900 to-[#0e121a] border border-amber-500/40 shadow-xl space-y-4"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800 text-xs font-mono-code">
                        <div className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-blue-400" />
                          <span className="text-white font-bold">{item.companyName}</span>
                          <span className="text-slate-400">({item.clientName})</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-slate-400">Order: <strong className="text-white">{item.orderId}</strong></span>
                          <span>·</span>
                          <span className="text-blue-400 font-bold">{item.referenceId}</span>
                        </div>
                      </div>

                      {/* Slip Details & Deliverables */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono-code">
                        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                          <span className="text-[10px] text-slate-500 block">Package Tier</span>
                          <span className="text-slate-200 font-bold">{item.packageName}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                          <span className="text-[10px] text-slate-500 block">Wire Amount Expected</span>
                          <span className="text-emerald-400 font-bold text-sm">AED {item.amountAed.toLocaleString()}</span>
                        </div>
                        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                          <span className="text-[10px] text-slate-500 block">Attached Receipt File</span>
                          <span className="text-blue-400 font-semibold truncate block">
                            📄 {item.paymentProofName || 'EmiratesNBD_Wire_Receipt.pdf'}
                          </span>
                        </div>
                      </div>

                      {item.verificationNotes && (
                        <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-800/50 text-[11px] font-mono-code text-amber-200">
                          <strong>Note:</strong> {item.verificationNotes}
                        </div>
                      )}

                      {/* Action Triggers */}
                      <div className="flex items-center justify-end gap-3 pt-2">
                        <button
                          type="button"
                          onClick={() => handleRejectTransfer(item)}
                          className="py-2 px-4 rounded-xl bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-800/60 text-xs font-mono-code transition-colors cursor-pointer"
                        >
                          Reject / Request Re-upload
                        </button>

                        <button
                          type="button"
                          onClick={() => handleApproveTransfer(item)}
                          className="py-2 px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs font-mono-code flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
                        >
                          <Check className="w-4 h-4" />
                          <span>Approve & Authorize Project Kickoff</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: PAYMENTS BY GATEWAY */}
          {activeTab === 'payments' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-display text-base font-bold text-white">
                    Processed & Pending Payments by Provider
                  </h3>
                  <p className="text-xs text-slate-400">
                    Live breakdown of Stripe, Ziina, Apple Pay, Card, and Bank Transfer flows.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={providerFilter}
                    onChange={(e) => setProviderFilter(e.target.value)}
                    className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono-code text-slate-200 focus:outline-none"
                  >
                    <option value="all">All Gateways</option>
                    <option value="stripe">Stripe</option>
                    <option value="apple_pay">Apple Pay</option>
                    <option value="credit_card">Credit Card</option>
                    <option value="ziina">Ziina</option>
                    <option value="bank_transfer">Bank Transfer</option>
                  </select>
                </div>
              </div>

              {/* Payments Table */}
              <div className="space-y-2.5 font-mono-code text-xs">
                {filteredPayments.map((p) => (
                  <div
                    key={p.id}
                    className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-bold">{p.id}</span>
                        <span className="text-slate-400">· {p.companyName}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded capitalize ${
                          p.status === 'paid' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-300'
                        }`}>
                          {p.status.replace('_', ' ')}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Provider: <span className="text-slate-200">{p.provider}</span> · Ref: <span className="text-blue-400">{p.referenceId}</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-emerald-400 font-bold text-sm">
                        AED {p.amountAed.toLocaleString()}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {new Date(p.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: ORDERS & CLIENTS */}
          {activeTab === 'orders' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
                    <span>Active Client Accounts & Milestone Engineering</span>
                    <span className="text-xs font-mono-code px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                      Real-time Milestone Broadcaster
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Advance milestones across the 8-step delivery system. Updates instantly broadcast live to client dashboards.
                  </p>
                </div>
              </div>

              <div className="space-y-4 font-mono-code text-xs">
                {projects.map((prj) => {
                  const currentStepData = PROCESS_STEPS.find(s => s.number === prj.currentStep) || PROCESS_STEPS[0];
                  const canAdvance = prj.currentStep < 8;
                  const canRollback = prj.currentStep > 1;

                  return (
                    <div
                      key={prj.id}
                      className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4"
                    >
                      {/* Top Project Summary */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-white text-sm">{prj.title}</span>
                            <span className="text-blue-400 text-[11px] bg-blue-950/80 px-2 py-0.5 rounded border border-blue-800/80">
                              {prj.id}
                            </span>
                            <span className="text-slate-400 text-[11px]">
                              · {prj.companyName} ({prj.orderId})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400">
                            Client: <strong className="text-slate-200">{prj.clientName}</strong> ({prj.clientEmail}) · Lead: <span className="text-slate-300">{prj.assignedLead}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 self-end sm:self-auto">
                          <div className="text-right">
                            <span className="text-[10px] text-slate-500 block uppercase">Contract Value</span>
                            <span className="text-emerald-400 font-bold text-sm">AED {prj.amountAed.toLocaleString()}</span>
                          </div>
                          <span className={`text-[10px] px-2.5 py-1 rounded font-bold uppercase ${
                            prj.paymentStatus === 'paid' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}>
                            {prj.paymentStatus.replace('_', ' ')}
                          </span>
                        </div>
                      </div>

                      {/* Milestone Status & Real-time Step Controls */}
                      <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-slate-400 text-[11px]">Active Milestone:</span>
                            <span className="px-2.5 py-1 rounded-md bg-blue-900/60 border border-blue-700 text-blue-200 font-bold text-xs flex items-center gap-1.5">
                              <span>Step {prj.currentStep} of 8: {currentStepData.title}</span>
                            </span>
                            <span className="text-emerald-400 font-bold text-xs">
                              ({prj.progressPercent}% Velocity)
                            </span>
                          </div>

                          {/* Quick Advance / Rollback Buttons */}
                          <div className="flex items-center gap-2">
                            {canRollback && (
                              <button
                                onClick={() => handleUpdateMilestone(prj.id, prj.currentStep - 1)}
                                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs transition-colors cursor-pointer"
                                title="Revert to previous step"
                              >
                                ← Step {prj.currentStep - 1}
                              </button>
                            )}

                            {canAdvance ? (
                              <button
                                onClick={() => handleUpdateMilestone(prj.id, prj.currentStep + 1)}
                                className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-blue-600/30 transition-all cursor-pointer"
                              >
                                <span>Advance to Step {prj.currentStep + 1}</span>
                                <TrendingUp className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <span className="px-3 py-1.5 rounded-lg bg-emerald-950 border border-emerald-800 text-emerald-300 font-bold text-xs flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>100% Handover Complete</span>
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Interactive 8-Step Direct Jump Selector */}
                        <div className="pt-2 border-t border-slate-900">
                          <span className="text-[10px] uppercase text-slate-500 tracking-wider block mb-1.5 font-bold">
                            Direct Milestone Phase Switcher (Broadcasts Live Notification):
                          </span>
                          <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5">
                            {PROCESS_STEPS.map((step) => {
                              const isCurrent = step.number === prj.currentStep;
                              const isCompleted = step.number < prj.currentStep;

                              return (
                                <button
                                  key={step.number}
                                  onClick={() => handleUpdateMilestone(prj.id, step.number)}
                                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                                    isCurrent
                                      ? 'bg-blue-600 border-blue-400 text-white font-bold shadow-md shadow-blue-600/30 ring-1 ring-blue-400'
                                      : isCompleted
                                      ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300 hover:bg-emerald-900/40'
                                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                                  }`}
                                  title={`Switch project to Step ${step.number}: ${step.title}`}
                                >
                                  <span className="block font-bold text-xs">{step.number}</span>
                                  <span className="block text-[9px] truncate">{step.title.split(' ')[0]}</span>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 4: TAX INVOICES */}
          {activeTab === 'invoices' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  Official Commercial Tax Invoices
                </h3>
                <p className="text-xs text-slate-400">
                  Emitac Building Dubai tax registration records and VAT archives.
                </p>
              </div>

              <div className="space-y-3 font-mono-code text-xs">
                {invoices.map((inv) => (
                  <div
                    key={inv.id}
                    className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{inv.invoiceNumber}</span>
                        <span className={`text-[10px] px-2 py-0.5 rounded uppercase ${
                          inv.status === 'paid' ? 'bg-emerald-950 text-emerald-400' : 'bg-amber-950 text-amber-300'
                        }`}>
                          {inv.status.replace('_', ' ')}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {inv.clientName} ({inv.companyName}) · Issued: {inv.issueDate}
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-emerald-400 font-bold">AED {inv.totalAed.toLocaleString()}</span>
                      <button
                        onClick={() => onViewInvoice(inv)}
                        className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs flex items-center gap-1 cursor-pointer"
                      >
                        <Eye className="w-3.5 h-3.5 text-blue-400" />
                        <span>View</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: GATEWAYS & MERCHANT CONFIG */}
          {activeTab === 'gateways' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-display text-base font-bold text-white">
                    Merchant Gateways & Processor Connection Settings
                  </h3>
                  <p className="text-xs text-slate-400">
                    Manage Stripe, Ziina, Apple Pay routing, and UAE corporate banking parameters.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleToggleMode}
                  className="py-2 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs font-mono-code flex items-center gap-1.5 transition-colors cursor-pointer self-start"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Toggle to {merchantConfig.activeMode === 'live' ? 'SANDBOX' : 'LIVE'}</span>
                </button>
              </div>

              {/* Gateway Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono-code text-xs">
                
                {/* Stripe */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">🟣 Stripe Connect (UAE)</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px]">
                      CONNECTED
                    </span>
                  </div>
                  <div className="space-y-1 text-slate-300 text-[11px]">
                    <p>Account: <strong className="text-white">{merchantConfig.stripe.accountName}</strong></p>
                    <p>Key Prefix: <strong className="text-slate-400">{merchantConfig.stripe.publicKeyPrefix}</strong></p>
                    <p>Apple Pay Routing: <strong className="text-emerald-400">Active via Stripe</strong></p>
                    <p>Card Processing: <strong className="text-emerald-400">3DS 2.0 Enabled</strong></p>
                  </div>
                </div>

                {/* Ziina */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">🟢 Ziina UAE Gateway</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px]">
                      CONNECTED
                    </span>
                  </div>
                  <div className="space-y-1 text-slate-300 text-[11px]">
                    <p>Merchant ID: <strong className="text-white">{merchantConfig.ziina.merchantId}</strong></p>
                    <p>Payment Link: <strong className="text-blue-400">{merchantConfig.ziina.paymentLinkUrl}</strong></p>
                    <p>CBUAE Compliance: <strong className="text-emerald-400">Verified</strong></p>
                  </div>
                </div>

                {/* UAE Direct Bank */}
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 md:col-span-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">🏦 Emirates NBD Corporate Bank Channel</span>
                    <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800 text-[10px]">
                      MANUAL VERIFICATION ACTIVE
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 text-[11px]">
                    <p>Bank: <strong className="text-white">{UAE_BANK_DETAILS.bankName}</strong></p>
                    <p>Account: <strong className="text-white">{UAE_BANK_DETAILS.accountName}</strong></p>
                    <p>IBAN: <strong className="text-blue-400">{UAE_BANK_DETAILS.iban}</strong></p>
                    <p>SWIFT: <strong className="text-white">{UAE_BANK_DETAILS.swift}</strong></p>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 6: FINANCIAL REPORTS */}
          {activeTab === 'reports' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <h3 className="font-display text-base font-bold text-white">
                  Studio Revenue & Settlement Reports
                </h3>
                <p className="text-xs text-slate-400">
                  Consolidated financial health across all digital architecture contracts.
                </p>
              </div>

              {/* Metric Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-xs font-mono-code text-slate-400">Total Settled Revenue</span>
                  <div className="text-2xl font-display font-extrabold text-emerald-400 font-mono-code">
                    AED {totalRevenueAed.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono-code">Net settled via Stripe & Verified Wire</span>
                </div>

                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-xs font-mono-code text-slate-400">Pending Wire Verification</span>
                  <div className="text-2xl font-display font-extrabold text-amber-400 font-mono-code">
                    AED {totalPendingAed.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono-code">In verification queue</span>
                </div>

                <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                  <span className="text-xs font-mono-code text-slate-400">UAE Federal VAT (5%)</span>
                  <div className="text-2xl font-display font-extrabold text-blue-400 font-mono-code">
                    AED {totalVatAed.toLocaleString()}
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono-code">TRN: 100984729100003</span>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
