import React from 'react';
import { 
  MapPin, 
  CheckCircle2, 
  Sparkles,
  Users,
  Compass,
  Code2,
  Cpu,
  Layers,
  ShieldCheck,
  Zap,
  ArrowRight
} from 'lucide-react';
import { BRAND_CONFIG } from '../data/portalData';

interface AboutLicenceSectionProps {
  onOpenScopeBuilder?: () => void;
}

export const AboutLicenceSection: React.FC<AboutLicenceSectionProps> = ({ onOpenScopeBuilder }) => {
  return (
    <section 
      id="about"
      className="py-24 bg-[#090b10] border-t border-slate-800/80 relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: About & Mission */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono-code font-semibold">
              <Compass className="w-3.5 h-3.5 text-blue-400" />
              <span>ABOUT STUDIO & PHILOSOPHY</span>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
              A Web Design Studio Built on Structure — Not Shortcuts.
            </h2>

            {/* Official Mission Snippet */}
            <div className="p-6 rounded-2xl bg-[#0e131d] border border-slate-800 space-y-4">
              <p className="text-base text-slate-200 leading-relaxed font-normal">
                <span className="font-bold text-white">AIGAINX Portal</span> is a Dubai-based digital design studio built for modern businesses that need more than a generic template. We treat every website as a performance system: analyzing business goals first, engineering structural sitemaps, crafting bespoke UI/UX, and handing over clean code that you 100% own.
              </p>
              
              <p className="text-sm text-slate-300 leading-relaxed">
                Our portfolio spans corporate authorities, e-commerce showcases, and high-conversion landing page funnels across real estate, hospitality, luxury retail, professional advisory, and emerging tech.
              </p>
            </div>

            {/* Senior Project Lead Guarantee */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-mono-code text-blue-400 font-semibold uppercase">
                  <Users className="w-4 h-4" />
                  <span>Senior Lead Direct Access</span>
                </div>
                <p className="text-xs text-slate-300">
                  You communicate directly with experienced design leads who know your code and architecture.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-1">
                <div className="flex items-center gap-2 text-xs font-mono-code text-emerald-400 font-semibold uppercase">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Zero Fluff & Honest Scopes</span>
                </div>
                <p className="text-xs text-slate-300">
                  Clear deliverables, realistic milestone schedules, and full code transfer at every stage.
                </p>
              </div>
            </div>

          </div>

          {/* Right Column: Studio Tech Stack & Quality Standards Card */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-gradient-to-b from-slate-900 to-[#0b0e14] border border-slate-800 shadow-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
              
              {/* Top Verified Shield / Brand Monogram */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-950 border border-slate-700 shadow-md shrink-0">
                    <img 
                      src={BRAND_CONFIG.monogramUrl} 
                      alt="AIGAINX Official Monogram" 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h3 className="font-display text-base font-bold text-white flex items-center gap-1.5">
                      <span>AIGAINX</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-950 border border-blue-800 text-blue-300 font-mono-code">STUDIO</span>
                    </h3>
                    <p className="text-[10px] text-slate-400 font-mono-code uppercase tracking-wider">{BRAND_CONFIG.brandMeaning}</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-md bg-blue-950/80 border border-blue-700/80 text-blue-400 font-mono-code text-xs font-semibold">
                  DUBAI STUDIO
                </span>
              </div>

              {/* Standards List */}
              <div className="space-y-3 font-mono-code text-xs">
                <div className="flex justify-between py-2 border-b border-slate-800/80">
                  <span className="text-slate-400">HQ Location:</span>
                  <span className="text-white font-semibold flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                    <span>Emitac Building, Dubai, UAE</span>
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Core Performance:</span>
                  <span className="text-emerald-400 font-bold">&lt; 1.0s Web Vitals</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Front-End Stack:</span>
                  <span className="text-white font-semibold">React 18 · TypeScript · Tailwind</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800/80">
                  <span className="text-slate-400">UI/UX Design:</span>
                  <span className="text-slate-200">Bespoke Figma Design Tokens</span>
                </div>
                <div className="flex justify-between py-2 border-b border-slate-800/80">
                  <span className="text-slate-400">Code Handover:</span>
                  <span className="text-blue-400 font-bold">100% Repository Transfer</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-slate-400">Direct Inquiries:</span>
                  <span className="text-blue-400 font-semibold">{BRAND_CONFIG.email}</span>
                </div>
              </div>

              {/* Action Trigger */}
              {onOpenScopeBuilder && (
                <button
                  onClick={onOpenScopeBuilder}
                  className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-blue-600/30"
                >
                  <span>Configure Your Project Scope</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
