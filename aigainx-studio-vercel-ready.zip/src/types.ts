export interface ProcessStep {
  number: number;
  title: string;
  subtitle: string;
  description: string;
  deliverables: string[];
  duration: string;
  iconName: string;
  clientRole: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  tagline: string;
  category: string;
  targetAudience: string;
  problem: string;
  solution: string;
  features: string[];
  processSummary: string[];
  deliverableSnippet: string;
  faqs: { question: string; answer: string }[];
}

export interface ConceptProject {
  id: string;
  title: string;
  industry: string;
  tagline: string;
  description: string;
  isConcept: true; // Strictly labeled Concept / Demo Project per brand guideline
  keyFeatures: string[];
  colorTheme: {
    primary: string;
    accent: string;
    bg: string;
  };
  metrics: {
    pageLoad: string;
    mobileScore: string;
    conversionFocus: string;
  };
  wireframeHighlight: string;
  screens: {
    heroTitle: string;
    heroSubtitle: string;
    ctaText: string;
    sampleElements: string[];
  };
}

export interface PackageTier {
  id: string;
  name: string;
  badge?: string;
  tagline: string;
  idealFor: string;
  deliverables: string[];
  processHighlights: string[];
  timeline: string;
  popular?: boolean;
}

export interface TestimonialItem {
  id: string;
  clientName: string;
  role: string;
  company: string;
  industry: string;
  location: string;
  projectType: string;
  quote: string;
  keyOutcome: {
    metric: string;
    label: string;
  };
  deliveryTimeframe: string;
  tags: string[];
  rating: number;
}

export interface ScopeOption {
  id: string;
  name: string;
  description: string;
  category: 'industry' | 'scope' | 'feature' | 'timeline';
}

export interface ProjectInquiry {
  clientName: string;
  companyName: string;
  email: string;
  phone: string;
  industry: string;
  projectType: string;
  pageCount: string;
  selectedFeatures: string[];
  timeline: string;
  budgetExpectation: string;
  additionalNotes: string;
}

export type PaymentMethodId = 
  | 'apple_pay'
  | 'credit_card'
  | 'debit_card'
  | 'stripe'
  | 'ziina'
  | 'bank_transfer';

export type PaymentStatus = 
  | 'paid'
  | 'pending'
  | 'manual_verification'
  | 'failed'
  | 'refunded';

export type ProviderConnectionStatus = 
  | 'connected'
  | 'pending_approval'
  | 'sandbox'
  | 'manual_active';

export interface PaymentOptionInfo {
  id: PaymentMethodId;
  name: string;
  category: 'online' | 'provider' | 'bank';
  iconType: string;
  processor: string;
  status: ProviderConnectionStatus;
  statusLabel: string;
  description: string;
  processingFee: string;
  settlementTime: string;
  requiresMerchantAccount: boolean;
  isAvailable: boolean;
}

export interface PaymentRecord {
  id: string;
  orderId: string;
  invoiceNumber: string;
  quoteId?: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  companyName: string;
  projectName: string;
  packageId: string;
  packageName: string;
  subtotalAed: number;
  vatAed: number;
  amountAed: number;
  currency: 'AED' | 'USD';
  method: PaymentMethodId;
  provider: 'Stripe' | 'Ziina' | 'Direct UAE Bank' | 'Apple Pay via Stripe';
  status: PaymentStatus;
  referenceId: string;
  paymentProofUrl?: string;
  paymentProofName?: string;
  transactionHash?: string;
  paidAt?: string;
  createdAt: string;
  verificationNotes?: string;
  verifiedBy?: string;
}

export interface QuoteRecord {
  id: string;
  quoteNumber: string;
  clientName: string;
  companyName: string;
  email: string;
  phone: string;
  projectType: string;
  packageName: string;
  deliverables: string[];
  items: {
    description: string;
    qty: number;
    unitPriceAed: number;
    totalAed: number;
  }[];
  subtotalAed: number;
  vatRate: number; // 0.05 (5% UAE VAT)
  vatAed: number;
  totalAed: number;
  status: 'draft' | 'sent' | 'accepted' | 'paid' | 'expired';
  validUntil: string;
  createdAt: string;
  paymentTerms: string;
  timelineEstimate: string;
}

export interface InvoiceRecord {
  id: string;
  invoiceNumber: string;
  orderId: string;
  quoteNumber?: string;
  paymentId?: string;
  clientName: string;
  companyName: string;
  clientEmail: string;
  clientAddress?: string;
  clientTrn?: string; // Tax Registration Number
  issueDate: string;
  dueDate: string;
  paidDate?: string;
  items: {
    description: string;
    qty: number;
    rateAed: number;
    amountAed: number;
  }[];
  subtotalAed: number;
  vatAed: number;
  totalAed: number;
  status: 'paid' | 'pending' | 'under_review' | 'cancelled';
  paymentMethod?: PaymentMethodId;
  paymentReference?: string;
}

export interface ClientProject {
  id: string;
  title: string;
  clientName: string;
  companyName: string;
  clientEmail: string;
  packageName: string;
  orderId: string;
  status: 'discovery' | 'sitemap_wireframing' | 'ui_design' | 'development' | 'qa_testing' | 'launch_prep' | 'delivered';
  currentStep: number;
  totalSteps: number;
  progressPercent: number;
  kickoffDate: string;
  targetDeliveryDate: string;
  repositoryAccessGranted: boolean;
  assignedLead: string;
  amountAed: number;
  paymentStatus: PaymentStatus;
}

export interface MerchantGatewayConfig {
  activeMode: 'sandbox' | 'live';
  stripe: {
    enabled: boolean;
    status: ProviderConnectionStatus;
    accountName: string;
    publicKeyPrefix: string;
    applePayEnabled: boolean;
    cardsEnabled: boolean;
  };
  ziina: {
    enabled: boolean;
    status: ProviderConnectionStatus;
    merchantId: string;
    paymentLinkUrl: string;
  };
  uaeBank: {
    enabled: boolean;
    status: ProviderConnectionStatus;
    bankName: string;
    accountName: string;
    iban: string;
    swift: string;
    branch: string;
    currency: string;
    address: string;
    manualVerificationRequired: boolean;
  };
}

export type ProjectAssetCategory = 
  | 'design' 
  | 'document' 
  | 'wireframe' 
  | 'architecture' 
  | 'code' 
  | 'brand';

export type ProjectAssetFormat = 
  | 'figma' 
  | 'pdf' 
  | 'sitemap' 
  | 'wireframe' 
  | 'typescript' 
  | 'svg' 
  | 'markdown' 
  | 'zip';

export interface SitemapNode {
  id: string;
  page: string;
  route: string;
  status: 'approved' | 'in_progress' | 'planned';
  description: string;
  componentsCount: number;
  children?: { page: string; route: string; description: string }[];
}

export interface DesignTokenItem {
  name: string;
  category: 'color' | 'typography' | 'spacing' | 'radius' | 'shadow';
  value: string;
  description?: string;
}

export interface CodeSnippetItem {
  filename: string;
  language: string;
  description: string;
  code: string;
}

export interface ProjectAssetPreviewContent {
  summary: string;
  docSections?: { title: string; paragraphs: string[]; callout?: string }[];
  sitemapNodes?: SitemapNode[];
  designTokens?: DesignTokenItem[];
  codeSnippets?: CodeSnippetItem[];
  interactiveHotspots?: { label: string; x: number; y: number; description: string }[];
  metaDetails?: { label: string; value: string }[];
  figmaFrames?: { name: string; type: string; dimensions: string; description: string }[];
}

export interface ProjectAsset {
  id: string;
  projectId: string;
  projectTitle: string;
  title: string;
  category: ProjectAssetCategory;
  format: ProjectAssetFormat;
  version: string;
  fileSize: string;
  updatedAt: string;
  author: string;
  status: 'ready' | 'approved' | 'in_review' | 'archived';
  description: string;
  tags: string[];
  thumbnailGradient: string;
  previewContent: ProjectAssetPreviewContent;
  downloadUrl?: string;
  externalLink?: string;
}

