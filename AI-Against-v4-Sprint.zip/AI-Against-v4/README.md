# AI Against v4 Enterprise — Sprint 1: Foundation

This is the first working deliverable of the v4 Enterprise rebuild we scoped out.
It takes your existing, already-audited v3 backend (`backend_main_v3_FINAL.py`,
9.5/10 security score) and restructures it into a modular, multi-tenant CRM
foundation that the rest of the roadmap (AI Engine, Automation, Billing) will
plug into.

## What's in this delivery

- **`backend/`** — FastAPI app, split into `auth`, `organizations`, `crm`, `dashboard`
  modules (see `docs/ARCHITECTURE.md` for why, and a map of where every v3 audit
  fix now lives).
- **`database/schema_v4.sql`** — extends your `supabase_schema_v3.sql` with
  Companies, Contacts, Pipelines/Stages, Tasks, Notes, Calendar, Notifications,
  and a fine-grained permissions table.
- **`docker/`** — `Dockerfile` + `docker-compose.yml` (Redis service reserved
  for Sprint 4 automation).
- **`.env.example`** — every variable the app needs, documented.
- **`docs/ARCHITECTURE.md`** — module map, multi-tenancy model, roadmap.

## Quick start

```bash
# 1. Environment
cp .env.example .env
nano .env   # fill JWT_SECRET, REFRESH_SECRET, SUPABASE_KEY (service_role), ANTHROPIC_API_KEY

# 2. Database — in Supabase SQL editor, run in order:
#    supabase_schema_v3.sql   (if not already applied)
#    database/schema_v4.sql

# 3. Run
docker compose -f docker/docker-compose.yml up --build
# or without Docker:
cd backend && pip install -r requirements.txt && uvicorn main:app --reload --port 8000

# 4. Verify
curl http://localhost:8000/api/health
```

Expected `/api/health` response includes `"modules": ["auth","organizations","crm","dashboard"]`
and `"security": {"jwt_configured": true, "refresh_configured": true}` once your `.env` is filled in.

## Frontend

Your existing `ai-sales-agent.html` dashboard already speaks this API shape
(same `/api/leads`, `/api/health` etc. contracts as v3) — point its `API_BASE`
at wherever you deploy this backend and it keeps working while we build the
Next.js enterprise frontend in a later sprint.

## What's next (per the roadmap you approved)

- **Sprint 2** — AI Engine (sales/research/proposal/objection agents, reusing
  your v3 `claude_call`/`claude_json_call` error-handling pattern).
- **Sprint 3** — Automation (workflow builder, email/WhatsApp automation).
- **Sprint 4** — Redis/Celery background jobs.
- **Sprint 5** — Billing, client portal, white-label, analytics.

Each sprint adds a new sibling package under `backend/` (`ai/`, `automation/`, etc.)
without touching what's already working here.
