import html, re
from typing import Optional
from pydantic import BaseModel, model_validator


def _clean(val: str, maxlen: int = 200) -> str:
    return html.escape(re.sub(r"<[^>]+>", "", val))[:maxlen]


class LeadIn(BaseModel):
    company_name: str
    contact_name: str
    email: Optional[str] = ""
    phone: Optional[str] = ""
    website: Optional[str] = ""
    industry: Optional[str] = ""
    source: Optional[str] = "manual"
    estimated_value: Optional[str] = ""

    @model_validator(mode="after")
    def sanitize_fields(self):
        for field in ["company_name", "contact_name", "industry"]:
            val = getattr(self, field, "")
            if val:
                setattr(self, field, _clean(val))
        return self


class LeadCreate(LeadIn):
    pass


class LeadUpdateRequest(BaseModel):
    status: Optional[str] = None
    stage: Optional[str] = None
    score: Optional[int] = None
    notes: Optional[str] = None
    estimated_value: Optional[str] = None
    company_id: Optional[str] = None
    contact_id: Optional[str] = None


class CompanyIn(BaseModel):
    name: str
    domain: Optional[str] = ""
    industry: Optional[str] = ""
    size: Optional[str] = ""
    address: Optional[str] = ""
    notes: Optional[str] = ""

    @model_validator(mode="after")
    def sanitize(self):
        self.name = _clean(self.name)
        return self


class ContactIn(BaseModel):
    first_name: str
    last_name: Optional[str] = ""
    email: Optional[str] = ""
    phone: Optional[str] = ""
    title: Optional[str] = ""
    company_id: Optional[str] = None


class TaskIn(BaseModel):
    title: str
    description: Optional[str] = ""
    due_date: Optional[str] = None
    priority: Optional[str] = "normal"
    lead_id: Optional[str] = None
    assigned_to: Optional[str] = None


class NoteIn(BaseModel):
    lead_id: str
    body: str

    @model_validator(mode="after")
    def sanitize(self):
        self.body = html.escape(self.body[:2000])
        return self
