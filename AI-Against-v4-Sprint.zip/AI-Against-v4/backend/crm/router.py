from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends

from common.db import db_select, db_insert, db_update, db_delete, log_activity
from common.dependencies import get_current_user, require_sales_or_above, require_admin
from common.errors import safe_endpoint
from .models import LeadCreate, LeadUpdateRequest, CompanyIn, ContactIn, TaskIn, NoteIn

router = APIRouter(prefix="/api", tags=["crm"])


# ── LEADS ──────────────────────────────────────────────────────
@router.get("/leads")
async def get_leads(user: dict = Depends(get_current_user)):
    leads = db_select("leads", {"org_id": user["org_id"]})
    return {"success": True, "data": leads, "count": len(leads)}


@router.post("/leads", status_code=201)
@safe_endpoint
async def create_lead(req: LeadCreate, user: dict = Depends(require_sales_or_above)):
    lead = db_insert("leads", {
        "org_id": user["org_id"], "company_name": req.company_name, "contact_name": req.contact_name,
        "email": req.email, "phone": req.phone, "website": req.website, "industry": req.industry,
        "source": req.source, "estimated_value": req.estimated_value,
        "status": "new", "stage": "Lead Found", "score": 0,
        "assigned_to": user["id"], "created_at": datetime.utcnow().isoformat(),
    })
    if not lead:
        raise HTTPException(status_code=500, detail="Failed to create lead")
    log_activity(user["org_id"], lead.get("id"), "lead_created", f"Lead added: {req.company_name}", user["id"])
    return {"success": True, "data": lead}


@router.patch("/leads/{lead_id}")
@safe_endpoint
async def update_lead(lead_id: str, req: LeadUpdateRequest, user: dict = Depends(require_sales_or_above)):
    updates = {k: v for k, v in req.model_dump().items() if v is not None}
    updates["updated_at"] = datetime.utcnow().isoformat()
    result = db_update("leads", lead_id, updates, org_id=user["org_id"])  # tenant-safe
    if result is None:
        raise HTTPException(status_code=404, detail="Lead not found or access denied")
    return {"success": True, "data": result}


@router.delete("/leads/{lead_id}")
async def delete_lead(lead_id: str, user: dict = Depends(require_admin)):
    ok = db_delete("leads", lead_id, user["org_id"])
    if not ok:
        raise HTTPException(status_code=404, detail="Lead not found")
    return {"success": True}


@router.get("/leads/{lead_id}/activities")
async def get_lead_activities(lead_id: str, user: dict = Depends(get_current_user)):
    activities = db_select("activities", {"lead_id": lead_id})
    return {"success": True, "data": activities}


# ── COMPANIES ──────────────────────────────────────────────────
@router.get("/companies")
async def list_companies(user: dict = Depends(get_current_user)):
    return {"success": True, "data": db_select("companies", {"org_id": user["org_id"]})}


@router.post("/companies", status_code=201)
@safe_endpoint
async def create_company(req: CompanyIn, user: dict = Depends(require_sales_or_above)):
    company = db_insert("companies", {
        **req.model_dump(), "org_id": user["org_id"], "owner_id": user["id"],
        "created_at": datetime.utcnow().isoformat(),
    })
    if not company:
        raise HTTPException(status_code=500, detail="Failed to create company")
    return {"success": True, "data": company}


# ── CONTACTS ───────────────────────────────────────────────────
@router.get("/contacts")
async def list_contacts(user: dict = Depends(get_current_user)):
    return {"success": True, "data": db_select("contacts", {"org_id": user["org_id"]})}


@router.post("/contacts", status_code=201)
@safe_endpoint
async def create_contact(req: ContactIn, user: dict = Depends(require_sales_or_above)):
    contact = db_insert("contacts", {
        **req.model_dump(), "org_id": user["org_id"], "owner_id": user["id"],
        "created_at": datetime.utcnow().isoformat(),
    })
    if not contact:
        raise HTTPException(status_code=500, detail="Failed to create contact")
    return {"success": True, "data": contact}


# ── TASKS ──────────────────────────────────────────────────────
@router.get("/tasks")
async def list_tasks(user: dict = Depends(get_current_user)):
    return {"success": True, "data": db_select("tasks", {"org_id": user["org_id"]})}


@router.post("/tasks", status_code=201)
@safe_endpoint
async def create_task(req: TaskIn, user: dict = Depends(require_sales_or_above)):
    task = db_insert("tasks", {
        **req.model_dump(), "org_id": user["org_id"],
        "assigned_to": req.assigned_to or user["id"],
        "status": "open", "created_at": datetime.utcnow().isoformat(),
    })
    if not task:
        raise HTTPException(status_code=500, detail="Failed to create task")
    return {"success": True, "data": task}


@router.patch("/tasks/{task_id}/complete")
async def complete_task(task_id: str, user: dict = Depends(get_current_user)):
    result = db_update("tasks", task_id, {"status": "done"}, org_id=user["org_id"])
    if result is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return {"success": True, "data": result}


# ── NOTES ──────────────────────────────────────────────────────
@router.post("/notes", status_code=201)
@safe_endpoint
async def create_note(req: NoteIn, user: dict = Depends(get_current_user)):
    note = db_insert("notes", {
        "org_id": user["org_id"], "lead_id": req.lead_id, "author_id": user["id"],
        "body": req.body, "created_at": datetime.utcnow().isoformat(),
    })
    if not note:
        raise HTTPException(status_code=500, detail="Failed to create note")
    return {"success": True, "data": note}
