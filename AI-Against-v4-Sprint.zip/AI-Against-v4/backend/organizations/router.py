import secrets
from datetime import datetime
from fastapi import APIRouter, HTTPException, Depends

from common.db import db_select, db_insert, log_activity
from common.dependencies import hash_password, get_current_user, require_admin
from common.errors import safe_endpoint
from auth.models import InviteRequest

router = APIRouter(prefix="/api", tags=["organizations"])


@router.post("/team/invite", status_code=201)
@safe_endpoint
async def invite_member(req: InviteRequest, user: dict = Depends(require_admin)):
    existing = db_select("users", {"email": req.email.lower()})
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    temp_password = secrets.token_urlsafe(12)
    new_user = db_insert("users", {
        "name": req.name, "email": req.email.lower(),
        "password_hash": hash_password(temp_password),
        "org_id": user["org_id"], "role": req.role,
        "created_at": datetime.utcnow().isoformat(),
    })
    if not new_user:
        raise HTTPException(status_code=500, detail="Failed to create team member")

    log_activity(user["org_id"], None, "invite", f"Invited {req.email} as {req.role}", user["id"])
    return {
        "success": True,
        "message": f"Team member invited. Temporary password: {temp_password}",
        "note": "Send this password to the invitee. They should change it on first login.",
        "user": {"id": new_user.get("id"), "name": req.name, "email": req.email, "role": req.role},
    }


@router.get("/team")
async def list_team(user: dict = Depends(require_admin)):
    members = db_select("users", {"org_id": user["org_id"]})
    safe = [{k: v for k, v in m.items() if k != "password_hash"} for m in members]
    return {"success": True, "data": safe}


@router.get("/organizations/me")
async def get_my_org(user: dict = Depends(get_current_user)):
    orgs = db_select("organizations", {"id": user["org_id"]})
    if not orgs:
        raise HTTPException(status_code=404, detail="Organization not found")
    return {"success": True, "data": orgs[0]}
