from fastapi import APIRouter, Depends
from common.db import db_select
from common.dependencies import get_current_user

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary")
async def dashboard_summary(user: dict = Depends(get_current_user)):
    org_id = user["org_id"]
    leads      = db_select("leads", {"org_id": org_id})
    activities = db_select("activities", {"org_id": org_id})
    proposals  = db_select("proposals", {"org_id": org_id})
    tasks      = db_select("tasks", {"org_id": org_id})

    total  = len(leads)
    hot    = sum(1 for l in leads if l.get("status") == "hot")
    closed = sum(1 for l in leads if l.get("status") == "closed")
    open_tasks = sum(1 for t in tasks if t.get("status") == "open")

    by_status, by_source = {}, {}
    for l in leads:
        by_status[l.get("status", "unknown")] = by_status.get(l.get("status", "unknown"), 0) + 1
        by_source[l.get("source", "unknown")] = by_source.get(l.get("source", "unknown"), 0) + 1

    return {
        "success": True,
        "data": {
            "total_leads": total, "hot_leads": hot, "closed_leads": closed,
            "conversion_rate": f"{round(closed/total*100,1) if total else 0}%",
            "total_proposals": len(proposals), "total_activities": len(activities),
            "open_tasks": open_tasks,
            "by_status": by_status, "by_source": by_source,
        },
    }


@router.get("/activity-feed")
async def activity_feed(user: dict = Depends(get_current_user)):
    activities = db_select("activities", {"org_id": user["org_id"]}, order_by="created_at", limit=25)
    return {"success": True, "data": activities}
