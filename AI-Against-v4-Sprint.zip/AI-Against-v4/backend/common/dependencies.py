"""
Auth dependencies: JWT decode, get_current_user, role guards.
Carries forward v3 audit fixes:
  - org_id + role embedded in access token (no per-request DB lookup)
  - constant-time password verification (passlib)
  - clean 401/403 on bad/expired/wrong-role tokens
"""
import os, json
from datetime import datetime, timedelta
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

try:
    from jose import jwt as jose_jwt
    from passlib.context import CryptContext
    AUTH_AVAILABLE = True
    pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
except ImportError:
    AUTH_AVAILABLE = False
    print("⚠ WARNING: python-jose / passlib not installed.")

JWT_SECRET       = os.getenv("JWT_SECRET",     "CHANGE_ME_dev_only_secret_abc123")
REFRESH_SECRET   = os.getenv("REFRESH_SECRET", "CHANGE_ME_refresh_secret_xyz789")
JWT_ALGORITHM    = "HS256"
ACCESS_TTL_MIN   = 60
REFRESH_TTL_DAYS = 7

security = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    if not AUTH_AVAILABLE:
        return f"PLAIN:{password}"
    return pwd_ctx.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    if not AUTH_AVAILABLE:
        return hashed == f"PLAIN:{plain}"
    return pwd_ctx.verify(plain, hashed)


def _make_token(payload: dict, secret: str, expire_delta: timedelta) -> str:
    data = {**payload, "exp": datetime.utcnow() + expire_delta, "iat": datetime.utcnow()}
    if not AUTH_AVAILABLE:
        return f"devtoken:{json.dumps(data, default=str)}"
    return jose_jwt.encode(data, secret, algorithm=JWT_ALGORITHM)


def create_access_token(user_id: str, email: str, org_id: str, role: str) -> str:
    return _make_token(
        {"sub": user_id, "email": email, "org_id": org_id, "role": role, "type": "access"},
        JWT_SECRET, timedelta(minutes=ACCESS_TTL_MIN),
    )


def create_refresh_token(user_id: str) -> str:
    return _make_token({"sub": user_id, "type": "refresh"}, REFRESH_SECRET, timedelta(days=REFRESH_TTL_DAYS))


def decode_token(token: str, secret: str) -> dict:
    if not AUTH_AVAILABLE:
        return json.loads(token.replace("devtoken:", ""))
    return jose_jwt.decode(token, secret, algorithms=[JWT_ALGORITHM])


def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    if credentials is None:
        raise HTTPException(status_code=401, detail="Authorization header missing")
    try:
        payload = decode_token(credentials.credentials, JWT_SECRET)
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Wrong token type")
        return {
            "id": payload["sub"], "email": payload["email"],
            "org_id": payload["org_id"], "role": payload.get("role", "sales"),
        }
    except HTTPException:
        raise
    except (KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid token structure")
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired token")


def require_role(*allowed_roles: str):
    def _check(user: dict = Depends(get_current_user)) -> dict:
        if user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=403,
                detail=f"Role '{user['role']}' cannot access this endpoint. Required: {allowed_roles}",
            )
        return user
    return _check


# Shortcuts — extended role set for v4 (adds manager/support)
require_admin           = require_role("admin")
require_manager_or_above = require_role("admin", "manager")
require_sales_or_above  = require_role("admin", "manager", "sales")
require_any_role        = require_role("admin", "manager", "sales", "support", "viewer")
