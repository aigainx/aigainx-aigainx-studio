"""
Shared Supabase client + generic CRUD helpers.
Same battle-tested pattern from v3 (mutable-default bug fixed, org_id-safe updates).
"""
import os
from datetime import datetime
from typing import Optional

try:
    from supabase import create_client, Client as SupabaseClient
    _sb_url = os.getenv("SUPABASE_URL", "")
    _sb_key = os.getenv("SUPABASE_KEY", "")
    _sb: Optional[SupabaseClient] = create_client(_sb_url, _sb_key) if _sb_url and _sb_key else None
    DB_AVAILABLE = _sb is not None
except Exception as _e:
    _sb = None
    DB_AVAILABLE = False
    print(f"⚠ DB unavailable: {_e}")


def db_insert(table: str, data: dict) -> Optional[dict]:
    if not DB_AVAILABLE:
        return {"id": f"mock-{table}-{datetime.utcnow().timestamp()}", **data}
    try:
        res = _sb.table(table).insert(data).execute()
        return res.data[0] if res.data else None
    except Exception as e:
        print(f"DB insert error ({table}): {e}")
        return None


def db_select(table: str, filters: Optional[dict] = None, order_by: Optional[str] = None, limit: Optional[int] = None) -> list:
    if filters is None:
        filters = {}
    if not DB_AVAILABLE:
        return []
    try:
        q = _sb.table(table).select("*")
        for k, v in filters.items():
            q = q.eq(k, v)
        if order_by:
            q = q.order(order_by, desc=True)
        if limit:
            q = q.limit(limit)
        return q.execute().data or []
    except Exception as e:
        print(f"DB select error ({table}): {e}")
        return []


def db_update(table: str, record_id: str, data: dict, org_id: Optional[str] = None) -> Optional[dict]:
    if not DB_AVAILABLE:
        return data
    try:
        q = _sb.table(table).update(data).eq("id", record_id)
        if org_id:
            q = q.eq("org_id", org_id)  # tenant isolation — prevents IDOR
        res = q.execute()
        return res.data[0] if res.data else None
    except Exception as e:
        print(f"DB update error ({table}): {e}")
        return None


def db_delete(table: str, record_id: str, org_id: str) -> bool:
    if not DB_AVAILABLE:
        return True
    try:
        _sb.table(table).delete().eq("id", record_id).eq("org_id", org_id).execute()
        return True
    except Exception as e:
        print(f"DB delete error ({table}): {e}")
        return False


def log_activity(org_id: str, lead_id: Optional[str], action_type: str,
                  description: str, user_id: Optional[str] = None, metadata: Optional[dict] = None):
    import json
    db_insert("activities", {
        "org_id": org_id, "user_id": user_id, "lead_id": lead_id,
        "type": action_type, "description": description,
        "metadata": json.dumps(metadata or {}),
        "created_at": datetime.utcnow().isoformat(),
    })
