"""Shared error types + endpoint decorator (v3's clean-error pattern)."""
import functools
from fastapi import HTTPException


class AIServiceError(Exception):
    """Raised when an AI provider call fails."""
    pass


def safe_endpoint(func):
    """Wraps endpoints: AIServiceError -> 503, HTTPException passthrough, anything else -> clean 500."""
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except AIServiceError as e:
            raise HTTPException(status_code=503, detail=str(e))
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Internal error: {str(e)[:100]}")
    return wrapper
