from datetime import datetime, timedelta
from fastapi import APIRouter, HTTPException, Depends, Request

from common.db import db_select, db_insert, db_update, log_activity, DB_AVAILABLE, _sb
from common.dependencies import (
    hash_password, verify_password, create_access_token, create_refresh_token,
    decode_token, get_current_user, REFRESH_SECRET, ACCESS_TTL_MIN, REFRESH_TTL_DAYS,
)
from common.errors import safe_endpoint
from .models import RegisterRequest, LoginRequest, RefreshRequest

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/register", status_code=201)
@safe_endpoint
async def register(req: RegisterRequest, request: Request):
    existing = db_select("users", {"email": req.email})
    if existing:
        raise HTTPException(status_code=409, detail="Email already registered")

    org = db_insert("organizations", {
        "name": req.company or f"{req.name}'s Organization",
        "plan": "trial", "plan_leads_limit": 50,
        "created_at": datetime.utcnow().isoformat(),
    })
    org_id = org.get("id", "mock-org") if org else "mock-org"

    user_rec = db_insert("users", {
        "name": req.name, "email": req.email,
        "password_hash": hash_password(req.password),
        "org_id": org_id, "role": "admin",
        "created_at": datetime.utcnow().isoformat(),
    })
    if not user_rec:
        raise HTTPException(status_code=500, detail="Failed to create account. Please try again.")

    user_id = user_rec.get("id", "mock-user")
    access_token = create_access_token(user_id, req.email, org_id, "admin")
    refresh_token = create_refresh_token(user_id)

    db_insert("refresh_tokens", {
        "user_id": user_id, "token_hash": hash_password(refresh_token),
        "expires_at": (datetime.utcnow() + timedelta(days=REFRESH_TTL_DAYS)).isoformat(),
    })
    log_activity(org_id, None, "register", f"New account created: {req.email}", user_id)

    return {
        "success": True, "access_token": access_token, "refresh_token": refresh_token,
        "expires_in": ACCESS_TTL_MIN * 60,
        "user": {"id": user_id, "name": req.name, "email": req.email, "org_id": org_id, "role": "admin"},
    }


@router.post("/login")
@safe_endpoint
async def login(req: LoginRequest, request: Request):
    users = db_select("users", {"email": req.email})
    # timing-attack safe: always run verify, even if user doesn't exist
    dummy_hash = "$2b$12$dummy.hash.to.prevent.timing.attacks.xxxxxxxxxxxxxxxxxx"
    stored_hash = users[0].get("password_hash", dummy_hash) if users else dummy_hash
    password_ok = verify_password(req.password, stored_hash)
    if not users or not password_ok:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    user = users[0]
    user_id, org_id, role = user["id"], user.get("org_id", ""), user.get("role", "sales")

    access_token = create_access_token(user_id, user["email"], org_id, role)
    refresh_token = create_refresh_token(user_id)
    db_update("users", user_id, {"last_login": datetime.utcnow().isoformat()})
    db_insert("refresh_tokens", {
        "user_id": user_id, "token_hash": hash_password(refresh_token),
        "expires_at": (datetime.utcnow() + timedelta(days=REFRESH_TTL_DAYS)).isoformat(),
    })
    log_activity(org_id, None, "login", f"Login: {req.email}", user_id)

    return {
        "success": True, "access_token": access_token, "refresh_token": refresh_token,
        "expires_in": ACCESS_TTL_MIN * 60,
        "user": {"id": user_id, "name": user.get("name"), "email": user["email"], "org_id": org_id, "role": role},
    }


@router.post("/refresh")
@safe_endpoint
async def refresh_token_endpoint(req: RefreshRequest):
    try:
        payload = decode_token(req.refresh_token, REFRESH_SECRET)
        if payload.get("type") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid token type")
        user_id = payload["sub"]
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")

    users = db_select("users", {"id": user_id})
    if not users:
        raise HTTPException(status_code=401, detail="User not found")
    user = users[0]
    new_access = create_access_token(user["id"], user["email"], user.get("org_id", ""), user.get("role", "sales"))
    return {"success": True, "access_token": new_access, "expires_in": ACCESS_TTL_MIN * 60}


@router.post("/logout")
async def logout(user: dict = Depends(get_current_user)):
    if DB_AVAILABLE:
        _sb.table("refresh_tokens").delete().eq("user_id", user["id"]).execute()
    log_activity(user["org_id"], None, "logout", f"Logout: {user['email']}", user["id"])
    return {"success": True}


@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    return {"success": True, "user": user}
