"""
AI Against v4 Enterprise — Backend Entrypoint
================================================
Sprint 1: Foundation (Auth, Organizations, CRM, Dashboard)

This file assembles the modular routers. Business logic lives in each
module's router.py — this file only wires the app together.

Run (dev):
  cd backend
  uvicorn main:app --reload --port 8000

Run (prod):
  uvicorn main:app --host 0.0.0.0 --port 8000 --workers 2
"""
import os
from datetime import datetime
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

from common.db import DB_AVAILABLE
from common.dependencies import AUTH_AVAILABLE, JWT_SECRET, REFRESH_SECRET

from auth.router import router as auth_router
from organizations.router import router as org_router
from crm.router import router as crm_router
from dashboard.router import router as dashboard_router

_ENV = os.getenv("APP_ENV", "development")

app = FastAPI(
    title="AI Against v4 Enterprise API",
    version="4.0.0-sprint1",
    docs_url="/docs" if _ENV != "production" else None,
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in os.getenv("ALLOWED_ORIGIN", "http://localhost:3000").split(",")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Mount modules ────────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(org_router)
app.include_router(crm_router)
app.include_router(dashboard_router)


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "version": "4.0.0-sprint1",
        "timestamp": datetime.utcnow().isoformat(),
        "modules": ["auth", "organizations", "crm", "dashboard"],
        "features": {
            "auth": AUTH_AVAILABLE,
            "database": DB_AVAILABLE,
        },
        "security": {
            "jwt_configured": JWT_SECRET != "CHANGE_ME_dev_only_secret_abc123",
            "refresh_configured": REFRESH_SECRET != "CHANGE_ME_refresh_secret_xyz789",
        },
    }


@app.get("/")
async def root():
    return {"message": "AI Against v4 Enterprise API — see /docs"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
