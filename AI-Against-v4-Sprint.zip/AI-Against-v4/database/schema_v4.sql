-- ============================================================
-- AI Against v4 Enterprise — Database Schema
-- Sprint 1: Foundation
--
-- This EXTENDS your existing supabase_schema_v3.sql.
-- Run v3 first (if not already applied), then run this file.
-- Idempotent-ish: uses IF NOT EXISTS where sensible.
-- ============================================================

-- ── 0. EXTENSIONS ────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ── 1. ORG SUBSCRIPTION / PLAN DETAIL (extends organizations) ─
ALTER TABLE organizations
  ADD COLUMN IF NOT EXISTS slug            VARCHAR(120) UNIQUE,
  ADD COLUMN IF NOT EXISTS logo_url        TEXT,
  ADD COLUMN IF NOT EXISTS industry        VARCHAR(100),
  ADD COLUMN IF NOT EXISTS timezone        VARCHAR(50) DEFAULT 'Asia/Dubai',
  ADD COLUMN IF NOT EXISTS is_active       BOOLEAN DEFAULT TRUE,
  ADD COLUMN IF NOT EXISTS white_label     JSONB DEFAULT '{}';

-- ── 2. PERMISSIONS (fine-grained, on top of role) ─────────────
CREATE TABLE IF NOT EXISTS permissions (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  code        VARCHAR(100) UNIQUE NOT NULL,   -- e.g. 'leads.delete'
  description TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role           VARCHAR(50) NOT NULL,        -- admin | sales | viewer | manager | support
  permission_id  UUID REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role, permission_id)
);

-- ── 3. COMPANIES (distinct from leads — an account can outlive a lead) ─
CREATE TABLE IF NOT EXISTS companies (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id       UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  name         VARCHAR(255) NOT NULL,
  domain       VARCHAR(255),
  industry     VARCHAR(100),
  size         VARCHAR(50),          -- '1-10' | '11-50' | ...
  address      TEXT,
  notes        TEXT,
  owner_id     UUID REFERENCES users(id),
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_companies_org ON companies(org_id);

-- ── 4. CONTACTS (people — can belong to a company, independent of leads) ─
CREATE TABLE IF NOT EXISTS contacts (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id       UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  company_id   UUID REFERENCES companies(id) ON DELETE SET NULL,
  first_name   VARCHAR(120),
  last_name    VARCHAR(120),
  email        VARCHAR(255),
  phone        VARCHAR(50),
  title        VARCHAR(120),
  owner_id     UUID REFERENCES users(id),
  tags         TEXT[] DEFAULT '{}',
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_contacts_org      ON contacts(org_id);
CREATE INDEX IF NOT EXISTS idx_contacts_company  ON contacts(company_id);

-- link leads (from v3) to a company/contact once qualified
ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS company_id UUID REFERENCES companies(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS contact_id UUID REFERENCES contacts(id) ON DELETE SET NULL;

-- ── 5. PIPELINES & STAGES (configurable per org, replaces hardcoded stage text) ─
CREATE TABLE IF NOT EXISTS pipelines (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id      UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  name        VARCHAR(120) NOT NULL DEFAULT 'Default Pipeline',
  is_default  BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS pipeline_stages (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  pipeline_id  UUID REFERENCES pipelines(id) ON DELETE CASCADE NOT NULL,
  name         VARCHAR(120) NOT NULL,
  position     INT NOT NULL DEFAULT 0,
  color        VARCHAR(20) DEFAULT '#00D4FF'
);
CREATE INDEX IF NOT EXISTS idx_stage_pipeline ON pipeline_stages(pipeline_id);

ALTER TABLE leads
  ADD COLUMN IF NOT EXISTS pipeline_id       UUID REFERENCES pipelines(id),
  ADD COLUMN IF NOT EXISTS pipeline_stage_id UUID REFERENCES pipeline_stages(id);

-- ── 6. TASKS ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id       UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  lead_id      UUID REFERENCES leads(id) ON DELETE CASCADE,
  assigned_to  UUID REFERENCES users(id),
  title        VARCHAR(255) NOT NULL,
  description  TEXT,
  due_date     TIMESTAMPTZ,
  status       VARCHAR(30) DEFAULT 'open',   -- open | done | cancelled
  priority     VARCHAR(20) DEFAULT 'normal', -- low | normal | high
  created_at   TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_tasks_org ON tasks(org_id);
CREATE INDEX IF NOT EXISTS idx_tasks_assignee ON tasks(assigned_to);

-- ── 7. NOTES ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notes (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id      UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  lead_id     UUID REFERENCES leads(id) ON DELETE CASCADE,
  author_id   UUID REFERENCES users(id),
  body        TEXT NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notes_lead ON notes(lead_id);

-- ── 8. CALENDAR EVENTS ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS calendar_events (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id      UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  lead_id     UUID REFERENCES leads(id) ON DELETE SET NULL,
  owner_id    UUID REFERENCES users(id),
  title       VARCHAR(255) NOT NULL,
  starts_at   TIMESTAMPTZ NOT NULL,
  ends_at     TIMESTAMPTZ,
  location    VARCHAR(255),
  notes       TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_events_org ON calendar_events(org_id);

-- ── 9. NOTIFICATIONS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  org_id      UUID REFERENCES organizations(id) ON DELETE CASCADE NOT NULL,
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE NOT NULL,
  type        VARCHAR(60) NOT NULL,
  title       VARCHAR(255) NOT NULL,
  body        TEXT,
  read        BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, read);

-- ── 10. RLS for new tables (service_role only — same pattern as v3) ─
ALTER TABLE companies         ENABLE ROW LEVEL SECURITY;
ALTER TABLE contacts          ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipelines         ENABLE ROW LEVEL SECURITY;
ALTER TABLE pipeline_stages   ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks             ENABLE ROW LEVEL SECURITY;
ALTER TABLE notes             ENABLE ROW LEVEL SECURITY;
ALTER TABLE calendar_events   ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications     ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['companies','contacts','pipelines','pipeline_stages','tasks','notes','calendar_events','notifications']
  LOOP
    EXECUTE format('CREATE POLICY IF NOT EXISTS service_role_only ON %I FOR ALL TO service_role USING (true)', t);
  END LOOP;
END $$;

-- ── 11. TRIGGERS for updated_at ─────────────────────────────────
CREATE TRIGGER companies_updated_at BEFORE UPDATE ON companies
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER contacts_updated_at BEFORE UPDATE ON contacts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ── 12. SEED: default pipeline + stages for every existing org ──
INSERT INTO pipelines (org_id, name, is_default)
SELECT id, 'Default Pipeline', TRUE FROM organizations
ON CONFLICT DO NOTHING;

INSERT INTO pipeline_stages (pipeline_id, name, position, color)
SELECT p.id, s.name, s.position, s.color
FROM pipelines p
CROSS JOIN (VALUES
  ('Lead Found',    0, '#00D4FF'),
  ('Contacted',     1, '#7B61FF'),
  ('Replied',       2, '#00FF94'),
  ('Proposal Sent', 3, '#FF6B35'),
  ('Closed Won',    4, '#00FF94'),
  ('Closed Lost',   5, '#5A7A96')
) AS s(name, position, color)
ON CONFLICT DO NOTHING;

-- ── 13. SEED: base permission codes ─────────────────────────────
INSERT INTO permissions (code, description) VALUES
  ('leads.view',    'View leads'),
  ('leads.create',  'Create leads'),
  ('leads.edit',    'Edit leads'),
  ('leads.delete',  'Delete leads'),
  ('team.invite',   'Invite team members'),
  ('team.manage',   'Manage team roles'),
  ('billing.manage','Manage billing'),
  ('ai.run',        'Run AI modules')
ON CONFLICT (code) DO NOTHING;
