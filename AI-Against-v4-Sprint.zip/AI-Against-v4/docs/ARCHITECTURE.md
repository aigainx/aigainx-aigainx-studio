# AI Against v4 Enterprise — Architecture (Sprint 1)

## Design principles carried over from your v3 audit (9.5/10 security score)

Every fix from `AUDIT_REPORT_v3.md` is preserved and now lives in a dedicated module
instead of one 900-line file:

| v3 Fix | Where it lives now |
|---|---|
| org_id + role embedded in JWT | `common/dependencies.py::create_access_token` |
| No mutable-default-arg bug | `common/db.py::db_select` |
| IDOR-safe updates (org_id enforced) | `common/db.py::db_update`, used by every router |
| AI error handling → clean 503 | `common/errors.py::safe_endpoint` |
| Password strength + phone validation | `auth/models.py`, `crm/models.py` |
| RBAC (admin/sales/viewer) | `common/dependencies.py::require_role` — **extended** to admin/manager/sales/support/viewer |
| Refresh token system | `auth/router.py` |
| Input sanitization before AI prompts | `crm/models.py::_clean` |

## Module layout

```
backend/
├── main.py              # assembles routers, health check, CORS
├── common/
│   ├── db.py             # Supabase client + generic CRUD (tenant-safe)
│   ├── dependencies.py   # JWT, RBAC, password hashing
│   └── errors.py         # AIServiceError + safe_endpoint decorator
├── auth/
│   ├── models.py         # Register/Login/Refresh/Invite request models
│   └── router.py         # /api/auth/*
├── organizations/
│   └── router.py         # /api/team/*, /api/organizations/me
├── crm/
│   ├── models.py         # Lead/Company/Contact/Task/Note models
│   └── router.py         # /api/leads/*, /api/companies/*, /api/contacts/*, /api/tasks/*, /api/notes/*
└── dashboard/
    └── router.py         # /api/dashboard/summary, /api/dashboard/activity-feed
```

Why split this way: each module owns its own Pydantic models + router, so
Sprint 2 (AI Engine) and Sprint 3 (Automation) can be added as new sibling
packages (`ai/`, `automation/`) without touching existing code — same pattern
FastAPI recommends for larger APIs.

## Multi-tenancy model

Every table has `org_id`. Every write/update goes through `db_update(..., org_id=user["org_id"])`,
which appends `.eq("org_id", org_id)` to the Supabase query — this is the IDOR fix from
v3, now enforced structurally (you'd have to *opt out* of it, not opt in).

RLS policies in `database/schema_v4.sql` restrict all direct table access to the
`service_role` key — meaning the only way into the data is through this API, which is
the safest posture for a backend-owned dataset.

## What's new in v4 vs v3

- **Companies & Contacts** as first-class entities (v3 only had `leads`, which conflated
  "prospect" and "account" — a closed lead couldn't cleanly become a long-term account).
- **Configurable pipelines/stages** instead of a hardcoded stage string.
- **Tasks, Notes, Calendar events, Notifications** — the CRM primitives every sales team needs.
- **Fine-grained permissions table** (`permissions` / `role_permissions`) — ready for
  Sprint 5's custom-role feature, without breaking the simple 5-role RBAC that works today.
- **5 roles instead of 3**: admin, manager, sales, support, viewer.

## Roadmap (unchanged from the plan you approved)

- **Sprint 2** — AI Engine: sales/research/proposal/objection agents (your v3 `claude_call`
  / `claude_json_call` pattern moves into `ai/service.py`, reused by every AI router).
- **Sprint 3** — Automation: workflow builder, email/WhatsApp automation, scheduler.
- **Sprint 4** — Redis + Celery for background jobs (docker-compose already reserves a
  `redis` service for this).
- **Sprint 5** — Billing (Stripe/PayTabs), client portal, white-label, analytics.

## Running Sprint 1 locally

```bash
cp .env.example .env          # fill in JWT_SECRET, SUPABASE_KEY, ANTHROPIC_API_KEY
docker compose -f docker/docker-compose.yml up --build
curl http://localhost:8000/api/health
```

Or without Docker:
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Then run `database/schema_v4.sql` in the Supabase SQL editor (after `supabase_schema_v3.sql`,
if you haven't already applied it).
